#!/bin/bash
#################################
#Install Program -- touchrec    #
#Created by Thomas Adam         #
#################################

#Since this is being run from the directory that
#it was untarred from, assume that the files are in
#the PWD

curr_dir=$(pwd)

#clear the screen
clear

echo "Copying touchrec..."
cp $curr_dir/touchrec /usr/local/bin

echo "Copying manpage..."
cp -p $curr_dir/touchrec.1  /usr/local/man/man1

echo "Setting permissions: /usr/local/bin/touchrec..."
chmod 755 /usr/local/bin/touchrec

#!/bin/sh
#	paced_cat.sh - paced cat ie cat but not at full speed

#	displays a line then waits for keyboard input (which is not
#	echoed). Return means display next line. Number means display
#	n lines.

trap 'echo Trapped; stty echo; exit' EXIT KILL INT

PaceDisplay () {

	stty -echo
	j=1
	line=`line`
	while [ $? -ne 1 ]
	do
		echo $line
		j=`expr $j - 1`
		if [ $j -le 0 ]
		then
			read ans </dev/tty
			if [ `expr length "$ans"` -eq 0 ]
			then
				ans=0
			fi
			j=`expr $ans + 0`
			if [ $j -eq 0 ]
			then
				j=1
			fi
		fi
		line=`line`
	done


}

	p1=$1
	if [ "$p1" = "" ]
	then
		echo "filename: \c"
		read p1
		if [ "$p1" = "" ]; then exit; fi
	fi

	PaceDisplay < $p1

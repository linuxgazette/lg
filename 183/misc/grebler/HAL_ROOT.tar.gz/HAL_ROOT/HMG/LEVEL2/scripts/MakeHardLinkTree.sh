#! /bin/sh
#	MakeHardLinkTree.sh - duplicate a directry using hard links

	myname=`basename $0`

	cat <<EOF
Usage: $myname fromdir todir

fromdir must exist of course, and must be a directory.

If todir exists and is a directory, the default is to assume you want a
subdirectory of todir with the same name as fromdir (like 'cp
sourcefile(s) target_dir').

	$myname /a/b/c /d/e/f	# Create /d/e/f/c if /d/e/f exists
				# or /d/e/f if /d/e exists

If todir does not exist, but its parent does and is a directory,
then the assumption is that you want to have a new name for the todir.

So a reasonable command to issue is:

	$myname a b	# Make a copy of a called b in the current dir

Any other combinations are either wrong, or I haven't considered them.

EOF

#----------------------------------------------------------------------#

Die () {
        echo $myname: "$*"
        exit 1
}

#----------------------------------------------------------------------#
# Here when todir exists
#----------------------------------------------------------------------#
DestExists () {
	[ -d "$todir" ] || Die "todir '$todir' exists but is not a dir"
	tgt=$todir/`basename "$fromdir"`
}

#----------------------------------------------------------------------#
# Here when todir does not exist
#----------------------------------------------------------------------#
NoDest () {
	to_parent=`dirname "$todir"`
	[ -d "$to_parent" ] || Die "todir '$todir' does not exist and its
parent '$to_parent' either does not exist or is not a directory."

	tgt="$todir"
}

#----------------------------------------------------------------------#

	[ $# -lt 2 ] && Die Insufficient args
	[ $# -ne 2 ] && Die Not coded for more than one source

# This is a world where PCs exist. Try to accommodate spaces in filenames
# or dirnames.

	here=`pwd`
	cd "$1"
	fromdir=`pwd`
	cd $here	# In case $todir is a relative path

	todir=`echo "$2" | sed 's./$..'`	# In case of trailing /

	[ -d "$fromdir" ] || \
		Die "fromdir '$fromdir' does not exist or is not a dir"

	if [ -e "$todir" ]
	then
		DestExists
	else
		NoDest
	fi

	echo "Creating target directory '$tgt'"

	mkdir "$tgt"
	set -e
	cd "$tgt"
	tgt_dir=`pwd`

	cd "$fromdir"
	pax -rwl . "$tgt_dir"
	echo done.


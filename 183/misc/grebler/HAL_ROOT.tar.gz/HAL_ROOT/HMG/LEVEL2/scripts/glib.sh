#!/bin/sh
#	glib.sh - run programs that need GLIBC_2.2

Usage () {
	cat <<EOF
Usage:	`basename $0` prog [args]
EOF

}
	Usage

	prog=`type -p $1`
	if [ "$prog" = "" ]
	then
		cat <<EOF
Sorry, the first arg must be a prog in your path. Check 'type prog'.
EOF
		exit 1
	fi

	shift

########################################################################

# Warning! Danger, Will Robinson!

#	Below this line, only run the special program.

########################################################################


	GLIBC23=/usr/i386-glibc23-linux/lib

	LD_LIBRARY_PATH=$GLIBC23:$LD_LIBRARY_PATH
	echo $LD_LIBRARY_PATH
	export LD_LIBRARY_PATH

	$GLIBC23/ld-linux.so.2 $prog "$@"

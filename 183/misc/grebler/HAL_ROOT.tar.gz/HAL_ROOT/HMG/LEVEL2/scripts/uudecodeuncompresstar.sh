#!/bin/sh
#	uudecodeuncompresstar.sh - Packaged uudecode-uncompress-untar.

#  Henry Grebler     3 Nov 97  Use gzip -d rather than gcat.
#  Henry Grebler     3 Nov 97  Fix answer. Use gcat rather than zcat.
#				Only delete input file if requested.
#  Henry Grebler    28 Apr 93  First cut.
#=============================================================================#



        PATH=/usr/5bin:$PATH

#       =======================================================================
#       Functions
#       =======================================================================

GetAnswer(){
        read ans
        ans=`echo $ans | cut -c1 | tr Y y`
	ans=${ans:-$1}
        if [ "$ans" != y ]
	then
                exit
        fi
	return
}        		#       Only returns on satisfactory answer

#       =======================================================================
#       Main line of script
#       =======================================================================

	F=x
	if [ $1 = -t ]
	then
		F=t
		shift
	fi
	p1=$1
	uudecode -p $p1 | gzip -vdc $file | tar -${F}vf - 

	if [ $F = t ]; then exit; fi

	echo 'Delete input file ('$file') [n]? \c'
	GetAnswer n
	rm $p1
	exit

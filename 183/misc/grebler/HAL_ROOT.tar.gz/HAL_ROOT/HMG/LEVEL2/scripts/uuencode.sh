#!/bin/sh
#	uuencode.sh - perform uuencode $1 $1 > $1.uu

#  Henry Grebler    24 Feb 98  Generalise.
#  Henry Grebler    25 Sep 92  First cut.
#=============================================================================#

        PATH=/usr/5bin:$PATH

        p1=$1
        if [ "$p1" = "" ]
        then
                echo 'file to uuencode: \c'
                read p1
                if [ "$p1" = "" ]; then exit; fi
        fi

	if [ "$2" != "" ]
	then
		x2=$2/
	fi
	x1=`basename $p1`
	uuencode $p1 $x1 > $x2$x1.uu

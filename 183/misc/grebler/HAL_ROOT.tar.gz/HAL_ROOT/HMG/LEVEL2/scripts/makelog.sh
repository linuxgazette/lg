#!/bin/sh
#	makelog.sh - do a make with log (to make.log)

	PATH=/usr/5bin:$PATH

	(echo '--------------------------------------';date) >> make.log
	(echo "$0 $*"
	uname -a) >> make.log

	{
	nice make $* >>make.log 2>&1
	if [ $? -ne 0 ]
	then
		echo "\007\c"
		sleep 1
	fi
	echo "\007\c"
	} &

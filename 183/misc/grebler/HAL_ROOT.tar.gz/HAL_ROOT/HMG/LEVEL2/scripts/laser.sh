#!/bin/sh
#	laser.sh - prepare a text file for the laser

#	20Dec98	Modify echo for Linux.
#	21Sep98	Use lp rather than lpr becasue HP-UX has a stupid lpr.
#	16Jul98	Set some things here so that landscape.sh can share 
#		laserpipe.sh.
#	22Nov93	Use laserpipe.sh
#		   HMG 19 December 1991

#	Usage:	laser [filename... ]

#		sends a text file to the laser (adds CR before LF).

	printer=`basename $0 .sh`

	if [ `uname` = Linux ]
	then
		enable -n echo
		lpcmd=lpr
	else
		PATH=/usr/5bin:$PATH
		lpcmd="lp -d$printer"
	fi
esc=`printf '\033'`


	{
# ESC E		Resets the printer
# ESC &k4S	Pitch = Elite 12
	printf "${esc}E${esc}&k4S"
	$HOME/scripts/laserpipe.sh $*
	} | $lpcmd

#!/bin/sh
#	ssh.sh - run ssh which needs GLIBC_2.2


# adapted from 
#	glib.sh - run programs that need GLIBC_2.2
# because it needs so much special

Usage () {
	cat <<EOF
Usage:	`basename $0` [args]
EOF

}
	Usage
	myname=`basename $0 .sh`
	prog=/glibc/bin/$myname
	if [ ! -f $prog ]
	then
		cat <<EOF
Sorry, '$prog' does not exist.
EOF
		exit 1
	fi


########################################################################

# Warning! Danger, Will Robinson!

#	Below this line, only run the special program.

########################################################################


	GLIBC22=/usr/i386-glibc22-linux/lib
	CRYPTO=/glibc/lib:/glibc/usr/kerberos/lib

	LD_LIBRARY_PATH=$GLIBC22:$LD_LIBRARY_PATH:$CRYPTO
	echo $LD_LIBRARY_PATH
	export LD_LIBRARY_PATH

	$GLIBC22/ld-linux.so.2 $prog "$@"

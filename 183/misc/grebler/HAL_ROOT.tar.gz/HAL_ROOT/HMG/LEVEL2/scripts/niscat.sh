#!/bin/sh
#	niscat.sh - do a niscat on known entities

	PATH=/usr/5bin:/bin:$PATH

tables='
passwd.org_dir
auto_master.org_dir
group.org_dir
mail_aliases.org_dir
auto_home.org_dir
bootparams.org_dir
cred.org_dir
ethers.org_dir
hosts.org_dir
sendmailvars.org_dir
netmasks.org_dir
netgroup.org_dir
networks.org_dir
protocols.org_dir
rpc.org_dir
services.org_dir
timezone.org_dir
'

	p1=$1
	if [ "$p1" = "" ]
	then
		displayed=true
		echo "$tables"
		echo "table: \c"
		read p1
		if [ "$p1" = "" ]; then exit; fi
	fi

	table=`echo "$tables" | fgrep $p1`
	n=`echo "$table" | wc -l`
#	if [ $n -eq 0 ]
	if [ "$table" = "" ]
	then
		echo Table "$table" not found
		if [ "$displayed" != true ]
		then
			echo "$tables"
		fi
		exit 1
	fi
	if [ $n -eq 1 ]
	then
		niscat $table
		exit
	fi
	echo Ambiguous table
	echo "$table"
	niscat $table
	echo Ambiguous table
	echo "$table"
	exit 1

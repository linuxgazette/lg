#! /bin/sh
#	ether_lose_colon.sh - convert from eg 8:0:b:0:0:40 to 08000b000040

	echo $1 |\
		awk -F: \
		'{printf "%02s%02s%02s%02s%02s%02s\n", $1, $2, $3, $4, $5, $6}'

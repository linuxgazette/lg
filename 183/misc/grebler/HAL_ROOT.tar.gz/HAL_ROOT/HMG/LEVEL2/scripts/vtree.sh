#!/bin/sh

(cd $1; pwd)
find $1 -type d -print | sort -f | \
sed -e "s,^$1,," -e "/^$/d"        \
    -e "s,[^/]*/\([^/]*\)$, \L_____\1," -e "s,[^/]*/, |    ,g"

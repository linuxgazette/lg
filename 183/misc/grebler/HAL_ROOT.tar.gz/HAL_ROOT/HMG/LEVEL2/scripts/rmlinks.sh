#!/bin/sh
#	rmlinks.sh - remove symbolic links

	for i in ./* .??*
	do
		if [ -h $i ]
		then
			rm $i
		fi
	done

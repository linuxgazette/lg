#! /bin/sh
#	stty_std.sh - set tty to standard

# Motivation:

# On abnormal exit from programs that change stty settings eg emacs,
# the terminal may end up in an unknown state. This script resets the
# terminal.

#  Henry Grebler     3 Mar 98  Improve.
#  Henry Grebler    11 Feb 98  First cut.
#=============================================================================#

# Note that ^ must be quoted, otherwise it is the same as | in Bourne shell

	stty erase '^h'
	stty dsusp '^y'
	stty lnext '^v'
	stty intr '^c'
	stty quit '^|'
	stty eof '^d'
	stty start '^q'
	stty stop '^s'
	stty susp '^z'
	stty rprnt '^r'
	stty werase '^w'

	stty -parenb cs8 -ignpar -istrip			#line 1
	stty -ignbrk icrnl					#line 2
	stty ixon						#line 3
	stty icanon echo					#line 4
	stty iexten						#line 5
	stty onlcr						#line 6

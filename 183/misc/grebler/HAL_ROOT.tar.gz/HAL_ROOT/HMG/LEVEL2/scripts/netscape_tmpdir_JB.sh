#! /bin/sh
#	netscape_tmpdir_JB.sh - invoke netscape.sh using a tmp dir for JB.

#  Henry Grebler    19 Mar 00  Need to allow localhost to go through 
#				junkbusters proxy.
#  Henry Grebler    13 Mar 00  Check for junkbusters.
#  Henry Grebler    13 Dec 99  First cut.


tmpdir=/tmp/hmg/netscape_tmp_$$
NH=$tmpdir/.netscape

#----------------------------------------------------------------------#

CheckItOut () {
	if [ -f $x ]
	then
		if [ ! -x $x ]
		then
			cat <<EOF
There exists a netscape ($x) which you can't execute:
`ls -lad $x`
EOF
			return
		fi
		version=`$x -v`
		NETSCAPE=$x
	fi
}

#----------------------------------------------------------------------#

files='plugin-list history.dat cert7.db secmodule.db 
	key3.db registry'

# Note: the dir 'archive' is used for caching
# Note: the dir 'cache' is used for caching. If it does not exist,
# Netscape sends a warning popup.

	if [ ! -d $NH ]
	then
		mkdir -p $NH/archive
		mkdir -p $NH/cache
		cd $HMGHOME/.netscape
		cp $files $NH
	fi

	grep -v javascript.enabled preferences.js > $NH/preferences.js
	echo Enabling javascript

#----------------------------------------------------------------------#
# Test for Junkbuster proxy

# Testing Junkbuster proxy is easier without cache.

	if testForJunkbusterProxy.exp > /dev/null 2>&1
	then
		echo Using Junkbuster proxy
		{
		egrep -v 'network.proxy.http|cache' $NH/preferences.js | \
			sed 's/,localhost//'
		cat <<EOF
user_pref("network.proxy.http", "localhost");
user_pref("network.proxy.http_port", 8000);
user_pref("browser.cache.check_doc_frequency", 2);
user_pref("browser.cache.directory", "$NH/cache/");
user_pref("browser.cache.memory_cache_size", 0);
user_pref("browser.sarcache.directory", "$NH/archive/");
EOF
		} > $NH/tmp
		rm $NH/preferences.js
		mv $NH/tmp $NH/preferences.js
	else
		cat <<EOF
Not using Junkbuster proxy. Press Return to proceed.
EOF
		read ans
	fi

#----------------------------------------------------------------------#

# The version of all contenders will be displayed. The latest
# available will be activated.

contenders='
/opt/netscape/netscape
/usr/lib/netscape/netscape-navigator
'

	cat <<EOF
Netscapes available:
------------------------------------------------------------------------
EOF
	for x in $contenders
	do
		CheckItOut
	done
	export NETSCAPE
	cat <<EOF
------------------------------------------------------------------------

Going with the last of these.
EOF

	HOME=$tmpdir; export HOME

	cd $tmpdir
	netscape.sh

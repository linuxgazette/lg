#! /bin/sh
#	update_amd.sh - update mlocate database for Jen's machine

	if [ `whoami` != root ]
	then
		cat <<EOF
You really need to be root to run updatedb
EOF
		exit 1
	fi

	if [ ! -d /mnt/amdC/WINDOWS ]
	then
		cat <<EOF
Could not find /mnt/amdC/WINDOWS which suggests that Jenny's machine
is not turned on.

Fix it and try again.
EOF

		exit 1
	fi

DB=/var/lib/mlocate/amd.db

	echo Updating $DB

	(
	set -x
	/usr/bin/updatedb --database-root /mnt/amdC --output $DB
	)

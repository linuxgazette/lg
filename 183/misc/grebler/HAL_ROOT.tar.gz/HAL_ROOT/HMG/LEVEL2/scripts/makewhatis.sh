#! /bin/sh
#	makewhatis.sh - makewhatis for hmg

# I'm at my wits' end. I can neither work out how makewhatis is
# supposed to work or how I can fix it. So this is to make makewhatis
# do what I want it to do, viz what 'catman -w' does on a Sun.


	if [ $# -eq 0 ]
	then
		cat <<EOF
Read the code. This may not be for you.

EOF

		exit
	fi
	last=`eval echo '$'$#`
	echo makewhatis -o $last/whatis "$@"
	makewhatis -o $last/whatis "$@"

#!/bin/sh
#	xrenamewindow.sh - rename the current xterm window

#  16 Feb 10  Henry Grebler    Use printf instead of echo.
#=============================================================================#

	if [ "$1" = "-icon" ]
	then
		arg=1
		shift
	else
		arg=0
	fi
	printf '\033]'$arg';'$1'\007\c'
	exit

#----------------------------------------------------------------------#


	PATH=/usr/5bin:$PATH
	if [ "$1" = "-icon" ]
	then
		arg=1
		shift
	else
		arg=0
	fi

	if [ "`uname`" = Linux ]
	then
		echo='echo -e'
	else
		echo=echo
	fi
	$echo '\033]'$arg';'$1'\007\c'

#!/bin/sh
#	expold.sh - display files (oldest first) then offer to move each
#			file to the expire directory

#	=======================================================================
#	Function to get a response from the keyboard
#	=======================================================================

answer_yes(){
	read ans
	ans=`echo $ans | cut -c1 | tr Y y`
	test "$ans" = "y"
return;}	#	Returns true if answer was yes

#	=======================================================================
#	Main line of script
#	=======================================================================

	for file in `ls -tr`
	do
		ls -la $file
		more -10 $file
		echo -n "Expire this file? [n]"
		if answer_yes; then mv $* $HOME/expire; fi
	done

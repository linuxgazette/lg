:
#	expire.sh - move a file to the expire directory

	mv $* $HOME/expire

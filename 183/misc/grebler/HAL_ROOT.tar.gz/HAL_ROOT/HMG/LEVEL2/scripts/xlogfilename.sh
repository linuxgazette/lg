#!/bin/sh
#	xlogfilename.sh - set the log file name

	PATH=/usr/5bin:$PATH

	echo '\033]46;'$1'\007\c'
	echo "Log file name set to '$1'"

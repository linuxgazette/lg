#!/bin/sh
#	scat.sh - sleep and cat.

ReadALine () {
	read line || exit
	echo $line
}


        while [ true ]
        do
                ReadALine
		ReadALine
		ReadALine
		ReadALine
		sleep 1
	done

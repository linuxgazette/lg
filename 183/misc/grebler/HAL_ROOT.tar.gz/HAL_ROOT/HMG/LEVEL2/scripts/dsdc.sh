#!/bin/sh
#	dsdc.sh - list today's files

#  Henry Grebler     9 Jan 97  Allow multiple args.
#  Henry Grebler     3 Nov 94  First cut.

	if ${DEBUG-false} ;then set -xv; fi
	PATH=/usr/5bin:/bin:$PATH

	tmp=/tmp/tmp_dsdc
	date=`date +%m%d0000`
	touch $date $tmp

	p1=$1
	if [ "$p1" = "" ]
	then
		p1=.
	else
		shift
	fi

	set -x
	nice find $p1 "$@" -mount -newer $tmp -print

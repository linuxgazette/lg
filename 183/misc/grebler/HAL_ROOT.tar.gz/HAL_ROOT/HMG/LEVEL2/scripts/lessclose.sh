#! /bin/sh
#	lessclose.sh - input postprocessor for less

	rm $2

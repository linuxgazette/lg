#! /bin/sh
#	strip_uuencode.sh - eliminate uuencode stuff from eg mail

	mv $1 $1.jic
	nawk -f - $1.jic > $1 <<EOF
/^begin /	{
	print
	state=1
}
/^begin /,/^ $/	{next}

state==1	{
	print "<snip>"
	state=0
}
	{print}
EOF

#! /bin/sh
#	ctwatch.sh - use Brian's ctdump as a sort of watch

	cat <<EOF
ctwatch Revision 0.0

Categorically NOT y2k compliant!!!
EOF

	p1=$1
	if [ "$p1" = "" ]
	then
		echo "filename: \c"
		read p1
		if [ "$p1" = "" ]; then exit; fi
	fi

	ctdump -A $p1 | grep -v '[rw] 199[7-9]' | grep -v '^$'

#!/bin/sh
#	ps_who_owns_it.sh - provide a list of parent process ids for a pid


	echo Usage: $0 pid


DoLine () {
	while :
	do
		line=`line`
		if [ $? = 1 ]; then break; fi
		this_pid=`echo "$line" | cut -c9-14`
		if [ "$this_pid" -eq $pid ]
		then
			echo "$line"
			pid=`echo "$line" | cut -c16-20`
			if [ $pid -eq 1 ]; then break ;fi
			Parents
			break
		fi
	done

}

Parents () {
	ps=`ps -axwl`
	lines_we_want=`echo "$ps" | grep $pid | grep -v grep`
	echo "$lines_we_want" | DoLine 
	
}


	if [ $# -eq 0 ]
	then
		exit 1
	fi

	ps -lw | head -1

	for pid in $*
	do
		Parents
	done

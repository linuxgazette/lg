#!/bin/sh
#^^^^^^^^ - BEWARE!!! - this is ignored by 'at'!
#	alarm2.sh - called by alarm to actually send the message

        if ${DEBUG-false} ;then set -xv; fi
        PATH=/usr/5bin:$PATH

	Bell=`echo '\007\c'`
	message="Wake Up"
	if [ "$1" != "" ]; then message=$*; fi

	ttys=`finger | grep henry |cut -c 31-34 | paste -s -d\  -`
	for i in $ttys
	do
		tty=tty$i
		if [ $i = co ]; then tty=console;fi
#		write henryg $tty <<YYY		#write won't work from a phantom
		cat >/dev/$tty <<YYY
$Bell
$message
YYY
	done
	exit

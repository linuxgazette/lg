#!/bin/sh
#	dsd.sh - directory size date

#  Henry Grebler    30 Jul 96  Fix if for nonSun platforms.
#  Henry Grebler     7 Jun 95  Set stty cs8 for SunOS4 (more seems to set it
#				cs7).
#  Henry Grebler     1 Mar 94  Add /usr/ucb to PATH for optim1.
#  Henry Grebler     1 Mar 94  only do the cut for SUNOS4. Change .sh.


#	Usage:    

#23feb93	ls -la $* | grep -v '~$' | more
#12apr93	ls -lA $* | grep -v '~$' | more


	PATH=/bin:/usr/bin:/usr/ucb


	if [ `uname` = SunOS ]
	then
		if [ `uname -r | cut -d. -f1` -lt 5 ]
		then
			platform=sunos4
		fi
	fi

	if [ "$platform" = sunos4 ]
	then
		F=Ag
		ls -l$F $* | grep -v '~$' | cut -c1-28,34- | more
		stty cs8
	else
		F=A
		ls -l$F $* | grep -v '~$' | more
	fi

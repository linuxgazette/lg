#!/bin/sh
#	ps_who_owns_it.sh - provide a list of parent process ids for a pid

#  Henry Grebler    17 Jan 99  Work on Linux.
#  Henry Grebler    30 Nov 95  Work on SunOS4.
#  Henry Grebler    30 Nov 95  Accept no args.
#  Henry Grebler    15 Nov 95  Use /bin/ps.
#  Henry Grebler     4 Aug 95  First cut.

	cat <<XXX
Usage: $0 [pid]

If pid is not specified, it defaults to the pid of $0.
XXX


#       =======================================================================
#       Functions
#       =======================================================================

DoLine () {
	while :
	do
		if [ $uname = Linux ]
		then
			read line
		else
			line=`line`
		fi
		if [ $? -ne 0 ]; then break; fi
		this_pid=`echo "$line" | awk '{print $2}'`
		if [ "$this_pid" -eq $pid ]
		then
			echo "$line"
			pid=`echo "$line" | awk '{print $'$P_PID'}'`
			if [ $? = 1 ]; then exit; fi
			if [ $pid -eq 1 ]; then break ;fi
			Parents
			break
		fi
		if [ $? = 1 ]; then exit; fi
	done

}

Parents () {
	lines_we_want=`echo "$ps" | grep $pid | grep -v grep`
	echo "$lines_we_want" | DoLine 
	
}


#       =======================================================================
#       Main line of script
#       =======================================================================

	PATH=/usr/5bin:/bin:$PATH

	if [ $# -eq 0 ]
	then
		set $$
	fi

	uname=`uname`
	if [ $uname = Linux ]
	then

# PPID   PID  PGID   SID TTY TPGID  STAT   UID   TIME COMMAND
#    1   186   186   186 v01   193  S      101   0:00 -bash

		ps="`ps ajxw`"
		P_PID=1
	else
		ps="`ps -ef`"
		P-PID=3
	fi

	echo "$ps" | head -1

	for pid in $*
	do
		Parents
	done

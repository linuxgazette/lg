#!/bin/sh
#	doasroot.sh - do a command as root

	if [ "$DEBUG" != "" ]; then set -xv; fi
#	su root -c $*
#	su henryg -c $*
	su root <<XXX
$*
XXX

#! /bin/sh
#	expr.sh - do expr 1 better

# 1.	Allow x as an alternative for * for multiply.


	expr=`echo $* | tr 'x' '*' | tr -d ',$'`
	awk 'BEGIN {print '"$expr"'}' < /dev/null

#! /bin/sh
#	test_cable_access.sh - see what's up

#  Henry Grebler    27 Dec 03  Gradually sort it out.
#  Henry Grebler    20 Dec 03  First cut(from ping_internet.sh).
# -------------------------------------------------------------------- #

# -------------------------------------------------------------------- #
#	To do
# -------------------------------------------------------------------- #

# Re-order hosts and notes to go across rather than down ie

#     hostname	ip address	use-flag	flag
#	optim1	203.18.86.65	

#	use-flag	1 use hostname
#			2 use ip address

#	flag		N name server

# -------------------------------------------------------------------- #

hosts='fw 211.28.173.1 211.28.180.1
	198.142.0.51 203.2.75.132
	203.9.190.17 203.9.190.18
	optushome.com.au
	203.18.86.3
	203.18.86.7
	mail.optimation.com.au
	www.optimation.com.au
	www.cr-x.com
	203.18.86.8
	203.18.86.14
	mira.net
	proxy.mira.net
	'
#	dialup.mira.net
notes='tsf100:Optus Gateway:Optus Gateway
	:name server 1 (dns.meb.optusnet.com.au)
	:name server 2 (dns.syd.optusnet.com.au)
	:name server 3 (eplet.mira.net)
	:name server 4 (werple.mira.net)
	::mail.optimation.com.au:OSE support server
	::::www.optimation.com.au
	:vpn-eth1:Mira
	:Mira proxy:
	'
#	primary gateway by name

timeout=1

#       =======================================================================
#       Functions
#       =======================================================================

Usage () {
	cat <<EOF
Usage:	$0 [-v] [-t <timout>]

	Normally does things quietly. With -v, pings are displayed.

	-t	Use specified timeout (default $timeout)
EOF
	exit 1
}

SetTimeout () {
	shift
	if [ "$1" = "" ]
	then
		echo '-t requires an arg'
		Usage
	fi
	timeout=$1
       if [ "`uname`" = Linux ]
       then
               timeout=
       fi

}

Loud () {
	if $verbose
	then
		result=`$vping $host 56 1`
		echo '--------------------------------------------------------'
		echo $result | fgrep ' 0% ' > /dev/null 2>&1
		status=$?
	else
		result=`$qping $host $timeout`
		status=$?
	fi
}

CheckNameServer () {
	if [ "$result" = ok ]
	then
		if echo $note | grep 'name server' > /dev/null 2>&1
		then
			have_name_server=true
#			echo This is a name server
		fi
	fi
}

CheckDomainName () {
	is_domain_name=false

# a domain name starts with an alpha, is followed by anything and has
# at least one . in it.

	if echo $host | grep '^[a-z].*\.' > /dev/null 2>&1
	then
		is_domain_name=true
#		echo This is a domain name
	fi
	
}

#       =======================================================================
#       Main line of script
#       =======================================================================

	right_bracket=']'

	cat <<EOF
[`basename $0` rev$Revision: 1.3 $right_bracket
EOF

	verbose=false

	while test $# -gt 0
	do
		case "$1" in
		     -t)	SetTimeout;;
		     -v)	verbose=true;;
		      *)	Usage;;
		esac
		shift
	done


	if $verbose
	then
		xxx='\n'
	else
		xxx=
	fi

	qping=ping
	vping=ping
	case "`uname`" in
		SunOS)	vping='ping -s';;
		HP-UX)	vping='ping';;
		Linux)	vping='ping -c 1';
			qping='ping -c 1';
			timeout=;;
		*)
			vping='ping'
			cat <<EOF
I haven't been specifically programmed for your platform.
I'll guess a ping command.
EOF
			;;
	esac

	have_name_server=false
	i=1
	for host in $hosts
	do
		jj='$'$i
#		eval note="\`echo $notes | awk -F: '{print $jj}'\`"
		note="`echo $notes | awk -F: '{print '$jj'}'`"
		if [ "$note" = "" ]
		then
			comment=
		else
			comment=" ($note)"
		fi
		CheckDomainName
		if [ $have_name_server = false -a $is_domain_name = true ]
		then
			cat <<EOF
Bypassing ping on $host$comment because there are no name servers.
EOF
			continue
		else
			printf  "Trying $host$comment ... $xxx"
		fi
		Loud
		if $verbose
		then
			:
		else
			if [ $status -eq 0 ]
			then
				result=ok
			else
				result=bad
			fi
		fi
		echo "$result"
		CheckNameServer
		i=`expr $i + 1`
	done

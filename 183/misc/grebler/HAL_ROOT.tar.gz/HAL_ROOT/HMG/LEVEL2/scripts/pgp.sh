#!/bin/sh
#	pgp.sh - run pgp after setting up what it needs

#	PGPPATH=/opt/pd/pgp-23a
	PGPPATH=/work/home/henryg/pgp
	export PGPPATH

	pgp "$@"


#!/bin/sh
#	logit.sh - log, timestamp, nice, run a command in background

#	default log name is <first arg>.log

	logname=`basename $1 .sh`.log

	echo Logging to $logname
	{

	echo '----------------------------------------------Start'
	echo '+++++++++++++         '`date`

	echo "$*"
	/bin/nice "$*"

	echo '+++++++++++++         '`date`
	echo '----------------------------------------------End'

	} >> $logname 2>&1 &


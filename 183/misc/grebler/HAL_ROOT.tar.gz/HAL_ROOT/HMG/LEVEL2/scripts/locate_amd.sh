#! /bin/sh
#	locate_amd.sh - find files by name on Jenny's machine


DB=/var/lib/mlocate/amd.db

	locate --database $DB "$@"

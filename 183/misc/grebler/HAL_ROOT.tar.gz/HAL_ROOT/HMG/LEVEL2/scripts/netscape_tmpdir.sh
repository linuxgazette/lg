#! /bin/sh
#	netscape_tmpdir.sh - invoke netscape.sh using a tmp dir

#  Henry Grebler    19 Mar 00  Need to allow localhost to go through 
#				junkbusters proxy.
#  Henry Grebler    13 Mar 00  Check for junkbusters.
#  Henry Grebler    13 Dec 99  First cut.


tmpdir=/tmp/hmg/netscape_tmp_$$
NH=$tmpdir/.netscape

#----------------------------------------------------------------------#

CheckItOut () {
	if [ -f $x ]
	then
		if [ ! -x $x ]
		then
			cat <<EOF
There exists a netscape ($x) which you can't execute:
`ls -lad $x`
EOF
			return
		fi
		version=`$x -v`
		NETSCAPE=$x
	fi
}

#----------------------------------------------------------------------#

files='plugin-list history.dat cert7.db secmodule.db 
	key3.db registry'

# Note: the dir 'archive' is used for caching

	if [ ! -d $NH ]
	then
		mkdir -p $NH/archive
		cd $HMGHOME/.netscape
		cp $files $NH
	fi

	grep -v javascript.enabled preferences.js > $NH/preferences.js
	echo Enabling javascript

#----------------------------------------------------------------------#
# Test for Junkbuster proxy

	if testForJunkbusterProxy.exp > /dev/null 2>&1
	then
		echo Using Junkbuster proxy
		{
		grep -v network.proxy.http $NH/preferences.js | \
			sed 's/,localhost//'
		cat <<EOF
user_pref("network.proxy.http", "localhost");
user_pref("network.proxy.http_port", 8000);
EOF
		} > $NH/tmp
		rm $NH/preferences.js
		mv $NH/tmp $NH/preferences.js
	else
		cat <<EOF
Not using Junkbuster proxy. Press Return to proceed.
EOF
		read ans
	fi

#----------------------------------------------------------------------#

# The version of all contenders will be displayed. The latest
# available will be activated.

contenders='
/opt/netscape/netscape
/usr/lib/netscape/netscape-navigator
'

	cat <<EOF
Netscapes available:
------------------------------------------------------------------------
EOF
	for x in $contenders
	do
		CheckItOut
	done
	export NETSCAPE
	cat <<EOF
------------------------------------------------------------------------

Going with the last of these.
EOF

	HOME=$tmpdir; export HOME

	cd $tmpdir
	netscape.sh

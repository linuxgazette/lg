#! /bin/sh
#	lessopen.sh - input preprocessor for less

#  Henry Grebler     7 Jan 98  Handle some man pages.
#  Henry Grebler    29 Oct 97  Add some more extensions for gzip.
#  Henry Grebler    16 Dec 96  First cut.
#=============================================================================#

tmp=/tmp/less.$$

	case "$1" in
	*.Z | *.z | *.gz | *.GZ)
		gzip -dc $1   >$tmp  2>/dev/null
		;;
	*.[1-9].bz2)
		/usr/bin/bunzip2 -dc $1 | nroff -man >$tmp  2>/dev/null
		;;
	*.bz2)	/usr/bin/bunzip2 -dc $1   >$tmp  2>/dev/null
		;;
	*.[1-9])
		if file $1 | grep roff > /dev/null 2>&1
		then
			nroff -man $1 > $tmp
# Dunno why this doesn't work
#			export LESS=-si
		fi
		;;
	esac

	if [ -s $tmp ]; then
		echo $tmp
	else
		rm -f $tmp
	fi

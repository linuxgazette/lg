#!/usr/local/bin/bash
#	makelog.bash - do a make with log (to make.log)

#	Note that bash is used because there is a problem with rm and
#	redirected shell stderr. If my environment changes, so must this.
#	Note also that makelog.sh should still exist.


AskTheQuestion () {

	cat <<XXX

You are on a Solaris 2 machine. However, you are not in the OBJ_SunOS_5
subdirectory. So, probably, you want to change directory or change
machines.

Press RETURN to proceed anyway. ^C to abort.

XXX
	read ans
}

	set -e

if [ `uname` = SunOS ]
then
    if [ `uname -r | cut -f1 -d.` -ge 5 ]
    then
        pwd=`pwd`
	basename=`basename $pwd`
	if [ "$basename" != OBJ_SunOS_5 ]
	then
		AskTheQuestion
	fi
    fi
fi

	{
	echo '--------------------------------------'
	date
	echo "$0 $*"
	uname -a
	} >> make.log 2>&1

	{

	nice make $* >>make.log 2>&1
	if [ $? -ne 0 ]
	then
		/usr/5bin/echo "\007\c"
		sleep 1
	fi
	/usr/5bin/echo '\007\c'
	} &

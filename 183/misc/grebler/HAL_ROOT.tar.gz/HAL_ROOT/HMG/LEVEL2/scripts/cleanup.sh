#!/bin/sh
#	cleanup.sh - remove all backup files (*~ .*~)

#   2 Jun 05  Henry Grebler    Use printf rather than echo. Change default to
#				yes.
#   9 Jul 93  Henry Grebler    First cut.
#=============================================================================#

	PATH=/usr/5bin:$PATH

	matches=`find . '(' -name \.\*~ -o -name \*~ ')' -print`
	if [ "$matches" = "" ]
	then
		echo No files to cleanup.
		exit
	fi
	for i in $matches
	do
		echo $i
	done
	echo 'Use n, N or ^C for no'
	printf 'The above files will be deleted. Ok? [y] '
	read ans
	case "$ans" in
		n*|N*)		echo "Operation abandoned"
				exit
				;;
	esac
	rm $matches
	echo Done

exit
#  9 Jul 93 V2	Call find once (instead of 4 times).
#		DOn't do anything if no matches.

#	    V1	First cut.
	PATH=/usr/5bin:$PATH

	find . -name \.\*~ -print | more
	find . -name \*~ -print | more
	echo 'The above files will be deleted. Ok? [n] \c'
	read ans
	if [ "$ans" != "y" ]
	then
		echo "Operation abandoned"
		exit
	fi
	find . -name \.\*~ -print -exec rm {} \;
	find . -name \*~ -print -exec rm {} \;
	echo Done


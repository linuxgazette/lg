#! /bin/sh
#	sol	- make the old one work under FC5

# Motivation

# With each new rev of sol it gets worse!

# I want to run the one from FC2 (for honours the one from optim2)
# under FC5 because the one on FC5 is awful.

	export GUILE_LOAD_PATH=/FC2/usr/share/guile/1.6:/FC2/usr/share/guile
	LD_LIBRARY_PATH=/lib:/usr/lib:/FC2/usr/lib; export LD_LIBRARY_PATH

	cd /home/henryg/projects/COMPUTERS/Install/FC5/FC2_interface
	/FC2/usr/bin/sol &

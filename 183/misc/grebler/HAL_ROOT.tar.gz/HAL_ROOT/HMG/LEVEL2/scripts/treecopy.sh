#! /bin/sh
#	treecopy.sh - like Prime's tree copy (trecpy)

#  Henry Grebler    10 Nov 05  Handle spaces in name.
#  Henry Grebler     5 Mar 03  Error check.
#  Henry Grebler    20 Jun 02  Use the best tar we can find.
#  Henry Grebler     9 May 01  Preserve permissions.
#  Henry Grebler    17 Jul 00  Fix 'Failed to make directory 
#				"/archive/home/henryg/Mail/joke"' ie 
#				intermediate directories absent.
#  Henry Grebler     4 Nov 98  Fix 'treecopy.sh 1997 1998'.
#  Henry Grebler     7 Sep 98  Handle trailing slash on fromdir.
#  Henry Grebler    30 Jun 98  Improve: document; add -Merge; make assumptions.
#  Henry Grebler    16 Mar 98  Remember where we were.
#  Henry Grebler     3 Mar 98  First cut.
#=============================================================================#

Comments () {
	cat > /dev/null <<EOF

I am concerned that I may be going around in circles. Perhaps I am not
consistent in the meaning I apply to different situations. So I
propose to record all cases I have catered for here as and when
problems arise.

4 November 1998

	cd ~/hmg/tax_stuff
	treecopy.sh 1997 1998

The directory 1997 exists. I want a new directory here (. =
~/hmg/tax_stuff) called 1998. Seems pretty obvious to me, but I get

1998/1997: does not exist

When I try 'treecopy.sh -M 1997 1998' I still get this message.

According to my notes under Usage below, I ought to be able to achieve
my desires either with:

	. 1998 does not exist and treecopy.sh 1997 1998
	. 1998 exists and treecopy.sh -M 1997 1998

EOF

}
#=============================================================================#

	set -e
	cat <<EOF
Usage: `basename $0` [-Merge] fromdir todir

todir will be created if it does not exist.
If todir exists, the default is to assume you want a subdirectory of
todir with the same name as fromdir (like 'cp sourcefile(s) target_dir').
If you want to merge, use -Merge.

EOF

Illarg () {
	echo Illegal arg
	exit 2
}

	merge=
	while test $# -gt 0
	do
		case "$1" in
		     -[mM]*)	merge=true;;
		     -*)	Illarg;;
		      *)	break;;
		esac
		shift
	done

	if [ $# -lt 2 ]
	then
		echo Insufficient args
		exit 1
	fi

	if [ $# -ne 2 ]
	then
		echo Not coded for more than one source
		exit 1
	fi

	eval to=\$$#
	if [ -f "$to" ]
	then
		echo "Destination '('$to')' exists as a FILE"
		exit 1
	fi

	p1=`echo $1 | sed 's./$..'`	# In case of trailing /
	tod=$to/`basename "$p1"`

	if [ ! -d "$to" ]
	then
		echo "Creating target directory '$to'"
		mkdir -p "$to"
		tod="$to"
	elif [ "$merge" = true ]
	then
		cat <<EOF
Target directory ($to) exists, merge flag given, merging.

EOF
		tod="$to"
	elif [ -f "$tod" ]
	then
		cat <<EOF
Target directory ($to) exists, merge flag not given, calculated
target subdirectory ($tod) exists as a FILE.
EOF
		exit 3
	elif [ -d "$tod" ]
	then
		cat <<EOF
Target directory ($to) exists, merge flag not given, calculated
target subdirectory ($tod) exists (and is a directory). You must use
`basename $0` -Merge $1 $tod
to do this.
EOF
		exit 4
	else
		cat <<EOF
Target directory ($to) exists, merge flag not given.
So, creating target subdirectory '$tod'.

EOF
		mkdir "$tod"
	fi

	here=`pwd`

	cd "$1"
	from=`pwd`

	cd $here	# In case $to is a relative path
	cd "$tod"

	if [ "`ls -l`" != "total 0" ]
	then
		cat <<EOF
Target directory `/bin/pwd` is not empty. Are you sure you want to proceed?

^C if not.
EOF
		read ans
	fi


        if [ "$GNUTAR" != "" ]
        then
                TAR=$GNUTAR
        elif [ -f /usr/local/bin/tar ]
        then
                TAR=/usr/local/bin/tar
        else
                TAR=tar
                type tar
        fi

	echo Using $TAR for tar.

        /bin/echo "Copying $from to `pwd` ... \c"
        (cd "$from"; $TAR -cf - .) | $TAR -xpf -
	echo done.

#!/bin/sh
#	chmod_g-o.sh - chmod copying rx bits from group to other

#  Henry Grebler    14 May 97  Handle s in x position (rws). Do -f
#				differently.
#  Henry Grebler    14 May 97  Improve usage.
#  Henry Grebler    12 Feb 96  First cut.

Usage () {
	cat <<XXX
Usage:	$0 [-f] file [file...]
		-f	force ie o= rather than o+

	chmod copying rx bits from group to other
XXX
	exit 1

}

ErrorUnknown () {
	echo "I don't know how to handle bits = '$bits'"
	exit
}

	if [ $# -eq 0 -o \( $# -eq 1 -a "$1" = "-f" \) ]
	then
		Usage
	fi

	if [ "$1" = "-f" ]
	then
		shift
		op='='
	else
		op='+'
	fi

	for file in $*
	do
		bits=`ls -lad $file | cut -c5,7 | tr -d '-'`
		if [ "$bits" = "" -a "$op" = "+" ]; then continue; fi
		    case $bits in
			rx | x | r)	;;
			s)		bits=x;;
			rs)		bits=rx;;
			*)		ErrorUnknown;;
		    esac
#		ls -lad $file
#		echo chmod o+$bits $file
		chmod o$op$bits $file
	done

#! /bin/sh
#	ndd_list_all.sh -  list all ndd values

	tab=`/usr/bin/echo '\011\c'`

	cmds=`ndd /dev/tcp '?' | awk '{print $1}' | tail +2`	# ignore the ?
	lines=`echo "$cmds" | wc -l`
	lines=`expr $lines - 5`
	cmds=`echo "$cmds" | head -$lines`
#	echo "$cmds"; exit

	for cmd in $cmds
	do
#		set -xv
		echo "$cmd$tab`ndd /dev/tcp $cmd`"
	done

	cmds=`ndd /dev/ip '?' | awk '{print $1}' | tail +2`    # ignore the ?

	for cmd in $cmds
	do
#		set -xv
		echo "$cmd$tab`ndd /dev/ip $cmd`"
	done

#! /bin/sh
#	antiwordl.sh - pipe antiword output through less
#		     - for use with MH

	antiword "$@" | less

#! /bin/sh
#	ls_amd.sh - Get a full listing of Jen's machine


	ls -laR --time-style=long-iso /mnt/amdC > /var/lib/mlocate/mnt_amdC.ls

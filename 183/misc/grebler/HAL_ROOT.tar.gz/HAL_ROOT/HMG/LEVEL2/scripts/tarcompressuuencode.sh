#!/bin/sh
#	tarcompressuuencode.sh - Packaged tar-compress-uuencode.

#  Henry Grebler    31 Jan 99  Let nice be found in path (sh does not honour
#				bash functions).
#  Henry Grebler     2 Mar 98  -t has precedence over .
#  Henry Grebler     2 Mar 98  Make the default quiet.
#  Henry Grebler    16 Feb 98  Add des encryption.
#  Henry Grebler    13 Feb 98  Add DOS file naming. Ditch trailing / on 
#				dirname.
#  Henry Grebler    28 Apr 97  Add documentation.
#  Henry Grebler    10 Sep 96  nice the tar.
#  Henry Grebler    14 Nov 95  Add -l.
#  Henry Grebler    12 Sep 94  Add gzip, dot. Expand help. Improve arg 
#				handling.


        if ${DEBUG-false} ;then set -xv; fi

#       =======================================================================
#       Functions
#       =======================================================================

Usage () {
	cat <<XXX
Usage: `basename $0` [-h] [+u] [-g] [-l] [-t tarfile] [-D] 
		[-d [-k key]] -v files | dirs

	-h	follow links (tar -h)
	+u	don't uuencode
	-g	use gzip (default compress)
	-l	leave output in /tmp
	-t	give compressedtarfile a name (full ie nothing appended)
		(default first or only filename or dirname with .tar.Z
		or .tar.gz appended)
	-D	use DOS-compatible filename
	-d	use des -D encryption [using key if -k is specified]
		(assumes gzip)
	-k	use key supplied
	-v	verbose

eg	tcu -g -t /tmp/t27.tar.gz optimation

	tcu -d	means use des, prompt for key
	tcu -k <key> can be used as a shorthand for
	tcu -d -k <key>

XXX
	exit
}

FixName () {
	fname=$1
	if [ "$dos_compat" = "" ]
	then
		return
	fi

	fname=`echo $fname | tr '.' '_'`	# translate unacceptable chars

# Note that echo add nl so the count is 1 higher

	if [ `echo $fname | wc -c` -gt 9 ]
	then
		fname=`echo $fname | cut -c1-7`_
		echo "Filename truncated to '$fname'"
	fi
}

#       =======================================================================
#       Main line of script
#       =======================================================================

#	Variables

#	H		h or <null> tar option
#	uuencode	yes or no
#	comp		compress or gzip
#	ext		Z or gz
#	ctf		compressed-tarfilename
#	ouf		output filename
#	p1		parameter 1
#	leave_in_tmp	flag. true => leave output in /tmp
#	dos_compat	true => use DOS-compatible filename
#	dsuffix		DOS-compatible suffix:	taz or tgz
#	verbose		verbose = v

	if [ $# -eq 0 ]
	then
		Usage
	fi

	H=
	uuencode=yes
	comp=compress
	ext=Z
	dsuffix=taz
	p1=
	leave_in_tmp=
	dos_compat=
	use_des=
	verbose=

	while true ; do
		case $1 in
		  -h)	H=h;;
		  +u)	uuencode=no;;
		  -g)	comp=gzip
			ext=gz;
			dsuffix=tgz;;
		  -l)	leave_in_tmp=true;;
		  -t)	shift
			ctf=$1;;
		  -D)	dos_compat=true;;
		  -d)	use_des=true
			dsuffix=tgd
			comp='gzip | des -E'
			;;
		  -k*)	use_des=true
			dsuffix=tgd
#			key="$2"
			comp='gzip | des -E -k '"'$2'"
			shift
			;;
		 -v)	verbose=v;;
		  -*)	Usage;;
		   *)	p1=$1
			break;;
		esac
		shift
	done

	if [ "$p1" = "" ]
	then
		Usage
	fi

# Strip trailing / (from bash TAB)
	set `echo $* | sed 's./ . .g;s./$..'`
#	echo "Args are '$*'";exit

	if [ "$dos_compat" = true ]
	then
		suffix=$dsuffix
	else
		suffix=tar.$ext
	fi

	move=no
	if [ "$ctf" = "" ]
	then
		if [ "$p1" = . ]
		then
			cwd=`pwd`
			dir=`basename $cwd`
			FixName $dir
			ctf=/tmp/$fname.$suffix
			move=yes
		elif [ "$leave_in_tmp" = true ]
		then
			FixName $1
			ctf=/tmp/$fname.$suffix
		else
			FixName $1
			ctf=$fname.$suffix
		fi
	else
		echo "$ctf" | grep  / > /dev/null
		status=$?
		if [ "$p1" = . -a  "$status" -eq 1 ]
		then
# saving current directory, and there is no slash in compressed-tarfilename
			ctf=/tmp/$ctf
			move=yes
		fi
	fi

	tar='nice tar'

	if [ $uuencode = yes ]
	then
#		set -xv
		ouf=$ctf.uu
		cmd="$tar -c${verbose}${H}f - $* | $comp | uuencode `basename $ctf`"
		eval $cmd > $ctf.uu
	else
		ouf=$ctf
		echo Not uuencoding
		$tar -c${verbose}${H}f - $* | $comp > $ctf
	fi
	if [ $move = yes ]
	then
		mv $ouf .
	fi

	echo Done.
	exit

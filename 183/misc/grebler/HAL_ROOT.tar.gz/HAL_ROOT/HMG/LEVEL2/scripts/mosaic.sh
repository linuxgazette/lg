#! /bin/sh
#	mosaic.sh - start Mosaic

#  Henry Grebler    25 Nov 98  Look first for platform-specific.
#  Henry Grebler    20 Nov 98  Add debugging. Look in several places.
#  Henry Grebler    18 Nov 98  Run the local version.
#  Henry Grebler    17 Nov 98  Add some options. 
#  Henry Grebler     5 Nov 98  First cut.
#=============================================================================#

	while test $# -gt 0
	do
		case "$1" in
		     -d)	cmd=echo;;
		     -dd)	set -xv;;
		     -h)	Usage;;
		esac
		shift
	done


	http_proxy='werribee:1027'
	export http_proxy

# -dil = delayImageLoads

	rev=`uname -r | cut -c2-`
MOSAIC_SRC_DIR=/opt2/pd/src/mosaic/Mosaic_2.7b5/Mosaic-src/src
	native_mosaic=$MOSAIC_SRC_DIR/Mosaic_2${rev}
possible_mosaics="
	$native_mosaic
	/opt2/pd/src/mosaic/Mosaic_2.7b5/Mosaic-src/src/Mosaic
	/opt2/pd/src/mosaic/Mosaic-solaris-24-2.7b5
"
	for mosaic in $possible_mosaics
	do
		if [ -x $mosaic ]
		then
			found=true
			break
		fi
	done

	if `$found`
	then
		:
	else
		cat <<EOF
None of the mosaics I know about was available.

Possible mosaics:

$possible_mosaics
EOF
		exit
	fi

	command="$mosaic"'
		-home file:///work/admin/www/intranet/index.html
		-dil
		http://optim1/'


	if [ "$mosaic" = "$native_mosaic" ]
	then
		$cmd $command &
	elif [ "`uname -sr`" != 'SunOS 5.5.1' ]
	then
		$cmd rsh -n hotham \
			"DISPLAY=$DISPLAY; export DISPLAY; `echo $command`" &
	else
		$cmd $command &
	fi

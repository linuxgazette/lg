#!/bin/sh
#	rename.sh - rename files

#  Henry Grebler    17 Dec 97  First cut. (I had the impression I had done
#				something like this before, but I couldn't
#				find it.)
#=============================================================================#


# This script will not do the rename. It will simply suggest the commands
# to invoke.

cmd=mv		# currently shis is a rename. Later, who knows?


main () {
	cat <<XXX
Usage:	$0 <from> <to>

	where <from> is filename pattern to match

	<from> is of the form <string1>*<string2>
	<to>   is of the form <string3>=<string4>

either of <string1> or <string2> may be null
either of <string3> or both of <string4> may be null

XXX

	if [ $# -ne 2 ]
	then
		cat <<EOF
Wrong number of parameters.
EOF
		exit
	fi

	if echo "$1" | fgrep '*' > /dev/null 2>&1
	then
		:
	else
		echo '<from> must have an asterisk'
	fi

	if echo "$21" | fgrep '=' > /dev/null 2>&1
	then
		:
	else
		echo '<to> must have an equal sign'
	fi

	
	awk_script=`cat <<'EOF'
{printf "'%s' '*' '%s'", $1, $2}
EOF
`
	eval Arg1 `echo "$1" | awk -F'*' "$awk_script"`
	eval Arg2 `echo "$2" | awk -F'=' "$awk_script"`

	for file in $1
	do
		echo $file | 
			sed 's|'"$from1"'\(.*\)'"$from3"'| mv '"$file $to1"'\1'"$to3"'|'
	done

}

Arg1 () {
#	disp_args "$@"
	from1="$1"
	from2="$2"
	from3="$3"
}

Arg2 () {
#	disp_args "$@"
	to1="$1"
	to2="$2"
	to3="$3"
}

	main "$@"
	exit



#sed 's/\(.*\)A\(.*\)/\1B\2/'

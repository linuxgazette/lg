#! /bin/sh
#	rs_henryg.sh - rsync henryg for burning to CD

tmp=/tmp/rs_henryg.tmp
exclude=$tmp.exclude
	cat > $exclude <<EOF
.mozilla
tmp
projects
Mail
EOF

	rsync -urlptog --exclude-from=$exclude /home/henryg /p8/cd_cutting


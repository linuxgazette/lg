#!/bin/sh
#	xterm.sh - fire up an xterm

#  Henry Grebler    27 Jul 06  Implement -s for smaller windows (actually 
#				font large).
#  Henry Grebler    11 Apr 05  Implement -h to hop over to another host (VPN).
#  Henry Grebler     9 Nov 00  Avoid another irritating messages on startup.
#  Henry Grebler    21 Aug 00  Avoid irritating messages on startup.
#  Henry Grebler     1 Jul 99  At least on linux, force erase=^h.
#  Henry Grebler    11 Feb 99  Allow more than one t27_
#  Henry Grebler    29 Sep 98  Allow no arg.
#  Henry Grebler    12 Apr 98  Avoid unwanted message.
#  Henry Grebler    17 Oct 96  Permit other args.
#  Henry Grebler    24 Jul 96  Fix so -r can be used with title which has
#				spaces.
#  Henry Grebler    28 Jul 95  Increase number of scroll lines from
#				default (book says 64 but I found it seems
#				to be about 100) to 400.
#  Henry Grebler    24 Jun 95  Fix last mod to handle spaces in title.
#  Henry Grebler    17 Feb 95  Add -r <hostname>. Clean up.
#  Henry Grebler    28 Jul 94  Add various goodies.

#1mar93	KBTERM=xterm-connect
KBTERM=xterm_sun4

tmp=/tmp/xterm.sh.$$

#       =======================================================================
#       Functions
#       =======================================================================

invoke_xterm () {

	TITLE=${1:-"Henry's CONNECT"}; export TITLE
	if [ "$1" != "" ]
	then
		icon_title="$1"; export icon_title
		shift
	fi

	if [ "$font_string" != "" ]
	then
		:
	elif [ "`xlsfonts t27_ 2> /dev/null | head -1`" = t27_ ]
	then
		font=t27
		font_string="-fn ${font}_ -fb ${font}B_"
	else
		font_string="-fn 9x15 -fb 9x15bold"
	fi

	SCTERM=xterm-connect

	t27x1='xterm -sf -sl 400 -g 80x26+100+240 '
	t27T=" -T $TITLE"
	t27e="-e t27"



	export T27 DT27 KBTERM SCTERM xterm

	if [ `uname` = Linux ]
	then
		stty_opt="-tm 'erase ^h'"
	fi
	xterm="$t27x1 $font_string -sb"
	eval exec $xterm $stty_opt -T "'$TITLE'" -n "'$icon_title'" $* \
		2>$tmp.stderr &
	CheckIt &
}

CheckIt () {
	sleep 1
	result=`cat $tmp.stderr`
	rm $tmp.stderr
	if [ "$result" = "" ]
	then
		return
	fi

silly="Warning: locale not supported by C library, locale unchanged
input method doesn't support my preedit type"

stupid='Warning: locale not supported by C library, locale unchanged'

	if [ "$result" = "$silly" ]
	then
		return
	fi
	if [ "$result" = "$stupid" ]
	then
		return
	fi


	echo "'$result'"
}

#       =======================================================================
#       Main line of script
#       =======================================================================

################################################
# For some reason this didn't work.

# 27 Jul 06 - I can no longer remember why this was interesting, but
# the reason it doesn't wok is because rsh needs a password. If I
# really want this hopping stuff to work, I should use ssh for the
# first hop. (And given the direction OSE is going, also for the
# second hop.)

	if [ "$1" = "-h" ]
	then
		host1="$2"
		shift; shift
	fi

################################################

	if [ "$1" = "-s" ]
	then
		font_string="-fn 9x15 -fb 9x15bold"
		shift
	fi

	if [ "$1" = "-r" ]
	then
		host2="$2"
		shift; shift
		if [ "$host1" = "" ]
		then
			host=$host2
			cmd=
		else
			cmd="rsh $host2"
			host=$host1
		fi
		if [ $# -gt 0 ]
		then
			title="$*"
		else
			title="$host2"
		fi
		invoke_xterm "$title" -e rsh $host $cmd
	else
		invoke_xterm "$@"
	fi		

exit

#	----------------------------------------------------------------
#	Documentation
#	----------------------------------------------------------------

#	Fonts:

#	6x10	Small
#	8x13	Medium
#	9x15	Large

#	6x13	t27pc_
#		t27_

#	Sometimes -rv (reversevideo) is useful

#	----------------------------------------------------------------
#	Old stuff
#	----------------------------------------------------------------

TITLE="CONNECT"; export TITLE

T27="$t27x1 $t27f -T \"$TITLE\" -n \"$icon_title\" $t27e"
DT27="$t27x1 $t27f -T \"DEBUG $TITLE\" -l -lf t27.log $t27e"

if [ "$DEBUG" != "1" ]
then
	eval $T27 &
else
	eval $DT27 &
fi


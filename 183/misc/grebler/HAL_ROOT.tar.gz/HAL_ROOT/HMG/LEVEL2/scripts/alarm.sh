#!/bin/sh
#	alarm.sh - set an alarm

	SHELL=/bin/sh; export SHELL	# See 'at' BUGS
	if [ $1 ]
	then
		when=$1
		shift
		at $when <<XXX
$HOME/scripts/alarm2.sh $*
XXX
		exit
	fi
	echo Usage: alarm.sh time [message]
	exit


		at $when $HOME/scripts/alarm2.sh $* 1>$HOME/scripts/alarm.log 2>&1
		cat $HOME/scripts/alarm.log

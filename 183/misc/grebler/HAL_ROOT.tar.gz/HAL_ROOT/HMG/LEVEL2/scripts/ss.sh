#!/bin/sh
#	ss.sh - invoke ss with good function keys

#  Henry Grebler     1 May 98  Handle <undef>.
#  Henry Grebler    28 May 96  First cut.
#=============================================================================#


Foundit () {
	echo args now = "$@"
	if [ "$2" != "=" ]
	then
		echo error args = "$@"
		exit 1
	fi
	dsusp="$3"
}

Process () {
	while true
	do
		if [ "$1" = dsusp ]
		then
			Foundit "$@"
			return
		else
			shift
		fi
	done
}

	Process  `/usr/5bin/stty -a | grep dsusp`
	stty dsusp "^-"
		

	TERM=xterm-sun
	TERMINFO=$HOME/ss/ss_terminfo
	export TERM TERMINFO
	ss $*

	echo "Restoring dsusp to '$dsusp'"
	if [ "$dsusp" != '<undef>;' ]
	then
		stty dsusp $dsusp
	fi

#!/bin/bash
#	diff.sh - invoke diff. If only one arg, compare with ~

#  27 Feb 07  Henry Grebler    
#  12 Jan 06  Henry Grebler    Add SpecialDiff: ignores RCS lines.
#  22 Jun 03  Henry Grebler    First cut.
#=============================================================================#


# SpecialDiff ignores RCS lines like $Source: /home/henryg/scripts/RCS/diff.sh,v $

SpecialDiff () {
	shift
	arg1=$1
	arg2=$2
	[ -d $1 ] && arg1="$1/`basename $2`"
	[ -d $2 ] && arg2="$2/`basename $1`"
	
#	set -x
	diff <(fgrep -v '$Source' $arg1) <(fgrep -v '$Source' $arg2)
	exit
}



	[ "$1" = '--RCS' ] && SpecialDiff $*

	if [ $# -eq 2 ]
	then
		diff $*
		exit
	fi

# More than 2 args is ok if some of the args are options

	if [ $# -gt 2 ]
	then
#		echo "Too many args"

		diff $*
		exit
	fi



# One arg

	if [ -f $1~ ]
	then
		diff $1~ $1
		exit
	fi




	bn=`basename $1`
	dn=`dirname $1`
	diff $dn/#$bn~ $1


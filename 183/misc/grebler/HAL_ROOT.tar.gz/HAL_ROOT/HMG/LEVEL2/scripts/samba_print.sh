#!/bin/sh
#	samba_print.sh - prepare a text file for the laser ...
#				attached to Jenny's PC

#	18May08	AMD died; use tsf500.
#	 3Aug06	Avoid passwd
#	11Dec04	Add to usage
#	28Nov04	First cut from laser.sh


#	Usage:	samba_print [-l] [filename... ]

#		sends a text file to the laser (adds CR before LF).

	printer=`basename $0 .sh`

esc=`printf '\033'`

# ESC &l1O	landscape
	case "$1" in
		-l*)	land="${esc}&l1O";shift;;
	esac



	{
# ESC E		Resets the printer
# ESC &k4S	Pitch = Elite 12
	printf "${esc}E${land}${esc}&k4S"
	$HOME/scripts/laserpipe.sh $*
	} | smbclient //TSF500/HP -N -c 'print -'

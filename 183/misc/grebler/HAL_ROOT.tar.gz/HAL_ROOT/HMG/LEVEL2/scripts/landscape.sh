#!/bin/sh
#	landscape.sh - print sideways

#	 6Nov00	Make it work under Linux and make i 12-pitch.
#	20Dec98	Modify echo for Linux.
#	16Jul98	Fix so it works with the reworked laserpipe.sh.
#	21May96	Rework so that landscape encapsulates laserpipe.
#	16Sep95	Don't take up a line at start. Display usage.
#	03Jul95	Don't print - be a pipe
#	(Take advantage of fact that laser or laser4m is default printer)
#	26Oct92	First cut

	if [ `uname` = Linux ]
	then
		enable -n echo
	else
		PATH=/usr/5bin:$PATH
	fi
esc=`echo '\\033'`

	echo "Usage: $0 "'[filename] | lpr' >&2

# ESC E		Resets the printer
# ESC &l1O	landscape
# ESC &k4S	Pitch = Elite 12
	printf "${esc}E${esc}&l1O${esc}&k4S"
	$HOME/scripts/laserpipe.sh $*

#! /bin/sh
#	disp_args.sh - display args

	echo There are $# args

	if [ $# -ge 15 ]
	then
		echo The 15th arg is ${15}
	fi

	i=0
	echo "Arg $i: '$0'"
	for arg
	do
		i=`expr $i + 1`
		echo "Arg $i: '$arg'"
	done

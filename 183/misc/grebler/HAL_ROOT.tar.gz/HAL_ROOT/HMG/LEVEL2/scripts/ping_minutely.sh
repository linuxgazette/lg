#! /bin/sh
#	ping_minutely.sh - ping once a minute

# Joel Goode from Microplex suggested that this happen

tgt='198.142.142.3'
interval=60			# seconds

file=/tmp/ping_minutely.log

# stamp_count is a convenient way of not having to count pings.
# The  ping generates lines like:

#	64 bytes from 198.142.142.3: icmp_seq=0. time=223. ms

# stamp_count is the number of these before a date time stamp

stamp_count=10

stamp_interval=`expr $stamp_count \* $interval`


# Stamp the log

	cat >> $file <<EOF
========================================================================
EOF

	date >> $file

# Start the ping

do_ping () {
	echo ping pid: $$ >> $file
	/usr/sbin/ping -s -I $interval $tgt >> $file
}
	do_ping &

	echo ping launched...

# Stamp the log from time to time

log_stamper () {
	sleep 5
	echo log_stamper pid: $$ >> $file
	sleep 25	# get it out of sync with the pings
	while true
	do
		sleep $stamp_interval
		date >> $file
	done
}

	log_stamper &

	echo log-stamper launched.
	echo Done.

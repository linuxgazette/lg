#!/bin/sh
if [ "$1" = "" ]; then
   awk '{ for(i=1;i<=NF;i++) sum+=$i; } END {print sum}'
else
   echo $*|awk '{ for(i=1;i<=NF;i++) sum+=$i; } END {print sum}'
fi

#! /bin/sh
#	netscape.sh - invoke netscape at Optimation

# Here is one way to record in each window which rev and which host
# -xrm 'Netscape.Navigator.findDialog_popup.title:   "Netscape461-hotham: Find"'

#  Henry Grebler    28 Dec 99  Clean up. Adjust for home.
#  Henry Grebler    18 Nov 99  Allow start in copied tmp dir.
#  Henry Grebler    22 Oct 99  Provide a way to identify host, rev, parent.
#  Henry Grebler    17 Aug 99  Don't allow root to run. Allow ways to
#				keep javascript.
#  Henry Grebler     9 Aug 99  Display PLATFORM_HOME if non-null.
#  Henry Grebler    29 Jul 99  Deal with libBrokenLocale bizzo.
#  Henry Grebler    27 Jul 99  Work on redhat Linux.
#  Henry Grebler    12 Apr 99  Added libresolv.so.2, so try again.
#  Henry Grebler    23 Mar 99  Warn about problematic combos.
#  Henry Grebler    16 Dec 98  Work with updated 
#				/usr/local/bin_scripts/netscape.
#  Henry Grebler    24 Sep 98  Use separate .netscape for different platforms.
#  Henry Grebler    23 Jun 98  Default to Netscape 4.
#  Henry Grebler    30 Jun 97  First cut.
#=============================================================================#

SetTSF () {
	platform=redhat6_0
	url='file:///home/henryg/help/OSElynx_home.html'
	LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/sw/nonpd/rvplayer5.0
	export LD_LIBRARY_PATH
}


CheckPlatform () {
	if [ "$platform" = "" ]
	then
		case `uname -n` in
			tsf*)	SetTSF
				return
				;;
		esac	
		cat <<EOF
platform command did not work!!!
EOF
		set -xv
		echo $PATH
		type -a platform
		exit
	fi

}

#       =======================================================================
#       Main line of script
#       =======================================================================

	if ${DEBUG-false} ;then set -xv; fi


#
# Don't allow root to run Netscape
#
	uid=`id | cut -d= -f2 | cut -d'(' -f1`
	if [ $uid = 0 ]
	then
	        echo SECURITY VIOLATION: do NOT run netscape as root >&2
        	exit 13
	fi

	if [ $# -eq 0 ]
	then
		NETSCAPE_VERSION=${NETSCAPE_VERSION-NEW}
		export NETSCAPE_VERSION
	fi

resources='Netscape*defaultBackground: LightGoldenrod1'
url='file:///work/admin/www/intranet/index.html'

	platform=`platform`
	CheckPlatform
	dollar='$'
	if [ -d $HOME/NETSCAPE ]
	then
		if [ -d $HOME/NETSCAPE/$platform ]
		then
			if [ -d $HOME/NETSCAPE/$platform/.netscape ]
			then
				cat <<EOF
Found a special .netscape for this platform ($platform)
EOF
				PLATFORM_HOME=$HOME/NETSCAPE/$platform
			else
				cat <<EOF
$HOME/NETSCAPE/$platform exists but is not populated with a .netscape.
Using the standard ${dollar}HOME ($HOME).
EOF
			fi
		fi
	fi


#-----------------------------------------------------------------------
#	WARNING - the libBrokenLocale bizzo can stuff things up for
#		'platform' (/usr/local/bin_scripts/platform). So make
#		sure it comes just before starting Netscape.
#-----------------------------------------------------------------------


	if [ `uname` = Linux ]
	then
		param_sep=
		LD_PRELOAD=/lib/libBrokenLocale.so.1
		export LD_PRELOAD
		netscape=/usr/lib/netscape/netscape-navigator
	else
		param_sep='--'
		netscape=netscape
	fi

#-----------------------------------------------------------------------


#	set -xv
	if [ "$PLATFORM_HOME" != "" ]
	then
		set -x
		HOME=$PLATFORM_HOME
		export HOME
		set +x
	fi
	if ${DEBUG-false} ;then
		netscape='sh -xv /usr/local/bin_scripts/netscape'
		exit
	fi

#-----------------------------------------------------------------------

	if [ "$NETSCAPE" != "" ]
	then
		netscape="$NETSCAPE"
		param_sep=
	fi

#	set -xv
	if fgrep '"javascript.enabled", false' \
				$HOME/.netscape/preferences.js > /dev/null
	then
		:
	else
		echo Note that javascript is enabled.
		xxx="`echo $netscape | awk '{print $NF}'`"
		yyy="`type $xxx | awk '{print $NF}'`"
		if [ "$yyy" = /usr/local/bin_scripts/netscape ]
		then
			cat <<EOF
However, it's gonna get turned off by
/usr/local/bin_scripts/netscape if you keep going. If you want to avoid
this happening, press ^C. Then set NETSCAPE and try again.
EOF
			read ans
		fi
	fi

#-----------------------------------------------------------------------


plugindirs="/sw/downloads/`platform` /sw/nonpd"

	for plugindir in $plugindirs
	do
		if [ -d $plugindir ]
		then
			break
		fi
	done
	if [ -d $plugindir ]
	then
		if echo $LD_LIBRARY_PATH | fgrep "$plugindir" > /dev/null
		then
			:
		else
			cat <<EOF
Have you set up LD_LIBRARY_PATH for plugins?
The directory $plugindir exists,
but is absent from LD_LIBRARY_PATH
($LD_LIBRARY_PATH).
EOF
		fi
	fi

#-----------------------------------------------------------------------
# Netscape Identification

	host=`uname -n | cut -d. -f1`
	version_line=`$netscape -version 2>&1`
	version=`echo "$version_line" | \
		sed 's@Netscape \(.*\)/.* Netscape Communications Corp@\1@'`

	if [ "$version" = "" ]
	then
		cat <<EOF 
Hmm... we are unable to determine the version of Netscape. Not good.
Fix $0.
EOF
	fi

	RE='"'
	NID="${RE}Netscape-${version}-${host}-$$: Find${RE}"

# Next time, try
# resources2="`cat <<EOF
#
#EOF
#`"
	resources2="Netscape.Navigator.findDialog_popup.title:   $NID"

#resources='Netscape*defaultBackground: LightGoldenrod1'

#All_resources="$resources
#$resources2
#"

#LightGoldenrod1 = FFEC8B
#255 236 139             LightGoldenrod1
#*defaultBackground:                     #C0C0C0

#All_resources="Netscape.Navigator.defaultBackground: #FFEC8B
#Netscape.Navigator.findDialog_popup.title:   $NID"

#All_resources="\
#Netscape.Navigator.findDialog_popup.title:   krej
#Netscape.Navigator.findDialog_popup.title:   $NID
#Netscape.Navigator.findDialog_popup.title:   jerk
#"
`
	cat <<EOF
This is the resources string:
------------------------------------------------------------------------
((($All_resources)))
------------------------------------------------------------------------

EOF

	echo Press Return to start Netscape
	read ans
	set -x
#	$netscape $* $param_sep -xrm "$resources" -xrm "$resources2" \

	$netscape $* $param_sep -xrm "$All_resources" \
		-no-about-splash -dont-save-geometry-prefs \
		-geometry 797x836+228+17 \
		"$url" &

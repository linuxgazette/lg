#! /bin/sh
#	log_args_save_stdin.sh - capture args and save stdin

logit () {
	cat <<EOF
------------------------------------------------------------------------
EOF
	date
	echo There are $# args

	if [ $# -ge 15 ]
	then
		echo The 15th arg is ${15}
	fi

	i=0
	echo "Arg $i: '$0'"
	for arg
	do
		i=`expr $i + 1`
		echo "Arg $i: '$arg'"
	done
}

	logit "$@" >> /tmp/log_args.log
	printenv >> /tmp/log_env.log
	(
		echo '--------------------------Start'
		cat
		echo '--------------------------End'
	) >> /tmp/save_stdin

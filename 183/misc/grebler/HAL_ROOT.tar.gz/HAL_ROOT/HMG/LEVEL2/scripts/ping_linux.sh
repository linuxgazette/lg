#! /bin/sh

hosts='redhat caldera suse snowy'
#	dialup.mira.net
notes='::::'

#	primary gateway by name
timeout=1

#       =======================================================================
#       Functions
#       =======================================================================

Usage () {
	cat <<EOF
Usage:	$0 [-v] [-t <timout>]

	Normally does things quietly. With -v, pings are displayed.

	-t	Use specified timeout (default $timeout)
EOF
	exit 1
}

SetTimeout () {
	shift
	if [ "$1" = "" ]
	then
		echo '-t requires an arg'
		Usage
	fi
	timeout=$1
	if [ "`uname`" = Linux ]
	then
		timeout=
	fi
}

Loud () {
	if $verbose
	then
		result=`$vping $host 64 1`
		echo '--------------------------------------------------------'
		echo $result | fgrep ' 0% ' > /dev/null 2>&1
		status=$?
	else
		result=`$qping $host $timeout`
		status=$?
	fi
}

CheckNameServer () {
	if [ "$result" = ok ]
	then
		if echo $note | grep 'name server' > /dev/null 2>&1
		then
			have_name_server=true
#			echo This is a name server
		fi
	fi
}

CheckDomainName () {
	is_domain_name=false

# a domain name starts with an alpha, is followed by anything and has
# at least one . in it.

	if echo $host | grep '^[a-z].*\.' > /dev/null 2>&1
	then
		is_domain_name=true
#		echo This is a domain name
	fi


#	if echo $host | fgrep . > /dev/null 2>&1
#	then
#		if echo $host | grep '^[1-9]' > /dev/null 2>&1
#		is_domain_name=false
#	else
#		is_domain_name=false
#	fi
	
}

#       =======================================================================
#       Main line of script
#       =======================================================================

	right_bracket=']'

	cat <<EOF
[`basename $0` rev$Revision: 1.10 $right_bracket
EOF

	verbose=false

	while test $# -gt 0
	do
		case "$1" in
		     -t)	SetTimeout;;
		     -v)	verbose=true;;
		      *)	Usage;;
		esac
		shift
	done


	if $verbose
	then
		xxx=
	else
		xxx='\c'
	fi

	qping=ping
	vping=ping
	case "`uname`" in
		SunOS)	vping='ping -s';;
		HP-UX)	vping='ping';;
		Linux)	vping='ping -s 64 -c 1';
			qping='ping -s 64 -c 1';
			timeout=;;
		*)
			vping='ping'
			cat <<EOF
I haven't been specifically programmed for your platform.
I'll guess a ping command.
EOF
			;;
	esac

	have_name_server=false
	i=1
	for host in $hosts
	do
		jj='$'$i
#		eval note="\`echo $notes | awk -F: '{print $jj}'\`"
		note="`echo $notes | awk -F: '{print '$jj'}'`"
		if [ "$note" = "" ]
		then
			comment=
		else
			comment=" ($note)"
		fi
		CheckDomainName
		if [ $have_name_server = false -a $is_domain_name = true ]
		then
			cat <<EOF
Bypassing ping on $host$comment because there are no name servers.
EOF
			continue
		else
			/bin/echo Trying $host$comment ... $xxx
		fi
		Loud
		if $verbose
		then
			:
		else
			if [ $status -eq 0 ]
			then
				result=ok
			else
				result=bad
			fi
		fi
		echo "$result"
		CheckNameServer
		i=`expr $i + 1`
	done

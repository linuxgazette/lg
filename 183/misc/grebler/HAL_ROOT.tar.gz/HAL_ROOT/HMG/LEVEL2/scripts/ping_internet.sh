#! /bin/sh
#	ping_internet.sh - see what's up

#  Henry Grebler    15 Jun 02  Add some new nodes.
#  Henry Grebler    18 Nov 98  Update for Mira.
#  Henry Grebler     6 Feb 98  Add test for name servers. Bypass pinging of
#				domain names if no name server.
#  Henry Grebler     2 Feb 98  Cleanup. Add mail machines.
#  Henry Grebler    29 Jan 98  Microplex changed. Major rewrite of this script.
#  Henry Grebler     3 Nov 97  Work on HP-UX.
#  Henry Grebler     1 Oct 97  Do most things quietly. Provide -v for noise.
#  Henry Grebler    30 Jun 97  If our nameserver is down, we cannot use it
#				to determine the IP address of 
#				melax1.mpx.com.au! - so use his IP address.
#  Henry Grebler    30 Jun 97  DMO strikes again: falls -> phillack.
#  Henry Grebler     9 May 97  First cut.
# -------------------------------------------------------------------- #

# -------------------------------------------------------------------- #
#	To do
# -------------------------------------------------------------------- #

# Re-order hosts and notes to go across rather than down ie

#     hostname	ip address	use-flag	flag
#	optim1	203.18.86.65	

#	use-flag	1 use hostname
#			2 use ip address

#	flag		N name server

# -------------------------------------------------------------------- #

#	optim1			203.18.86.65
#	falls			203.18.86.70
#	erica			203.18.86.3
#	gwinear			203.18.86.1
#	mel2.gw.mpx.net.au	198.142.142.3 (machine on other side of modem)
#	?			198.142.142.231 (alternate machine on other 
#						side of modem)
#	melax1.mpx.com.au	203.10.67.2 (previous machine on other 
#						side of modem)
#	mpx.com.au		203.2.75.7
#	relay.mpx.com.au	203.2.75.94 (relay2-kyoko.mpx.com.au - mail)
#	new-kyoko.mpx.com.au	203.2.75.38 (mail machine)


hosts='cisco3640 optim1 phillack erica walhalla gwinear 
	203.9.190.17 203.9.190.18
	mira.net
	proxy.mira.net
	'
#	dialup.mira.net
notes=':::::::
	name server 1:name server 2:
	Mira:
	Mira proxy:
	'
#	primary gateway by name

timeout=1

#       =======================================================================
#       Functions
#       =======================================================================

Usage () {
	cat <<EOF
Usage:	$0 [-v] [-t <timout>]

	Normally does things quietly. With -v, pings are displayed.

	-t	Use specified timeout (default $timeout)
EOF
	exit 1
}

SetTimeout () {
	shift
	if [ "$1" = "" ]
	then
		echo '-t requires an arg'
		Usage
	fi
	timeout=$1
       if [ "`uname`" = Linux ]
       then
               timeout=
       fi

}

Loud () {
	if $verbose
	then
		result=`$vping $host 64 1`
		echo '--------------------------------------------------------'
		echo $result | fgrep ' 0% ' > /dev/null 2>&1
		status=$?
	else
		result=`$qping $host $timeout`
		status=$?
	fi
}

CheckNameServer () {
	if [ "$result" = ok ]
	then
		if echo $note | grep 'name server' > /dev/null 2>&1
		then
			have_name_server=true
#			echo This is a name server
		fi
	fi
}

CheckDomainName () {
	is_domain_name=false

# a domain name starts with an alpha, is followed by anything and has
# at least one . in it.

	if echo $host | grep '^[a-z].*\.' > /dev/null 2>&1
	then
		is_domain_name=true
#		echo This is a domain name
	fi


#	if echo $host | fgrep . > /dev/null 2>&1
#	then
#		if echo $host | grep '^[1-9]' > /dev/null 2>&1
#		is_domain_name=false
#	else
#		is_domain_name=false
#	fi
	
}

#       =======================================================================
#       Main line of script
#       =======================================================================

	right_bracket=']'

	cat <<EOF
[`basename $0` rev$Revision: 1.11 $right_bracket
EOF

	verbose=false

	while test $# -gt 0
	do
		case "$1" in
		     -t)	SetTimeout;;
		     -v)	verbose=true;;
		      *)	Usage;;
		esac
		shift
	done


	if $verbose
	then
		xxx='\n'
	else
		xxx=
	fi

	qping=ping
	vping=ping
	case "`uname`" in
		SunOS)	vping='ping -s';;
		HP-UX)	vping='ping';;
		Linux)	vping='ping -s 64 -c 1';
			qping='ping -s 64 -c 1';
			timeout=;;
		*)
			vping='ping'
			cat <<EOF
I haven't been specifically programmed for your platform.
I'll guess a ping command.
EOF
			;;
	esac

	have_name_server=false
	i=1
	for host in $hosts
	do
		jj='$'$i
#		eval note="\`echo $notes | awk -F: '{print $jj}'\`"
		note="`echo $notes | awk -F: '{print '$jj'}'`"
		if [ "$note" = "" ]
		then
			comment=
		else
			comment=" ($note)"
		fi
		CheckDomainName
		if [ $have_name_server = false -a $is_domain_name = true ]
		then
			cat <<EOF
Bypassing ping on $host$comment because there are no name servers.
EOF
			continue
		else
			printf  "Trying $host$comment ... $xxx"
		fi
		Loud
		if $verbose
		then
			:
		else
			if [ $status -eq 0 ]
			then
				result=ok
			else
				result=bad
			fi
		fi
		echo "$result"
		CheckNameServer
		i=`expr $i + 1`
	done

#!/bin/sh
#	scat.sh - sleep and cat.

ReadALine () {
	read line || exit
	echo $line
}
	if [ $# -eq 0 ]
	then
		Sleep=sleep
	else
		Sleep=:
	fi


        while [ true ]
        do
                ReadALine
		ReadALine
		ReadALine
		ReadALine
		$Sleep 1
	done <<EOF
xxxxxxx0x0xxxxxxyxxxxxybinybash
haqxxxx0x0xShuxdxwn xhz sysxzmxyxmpxyusxyqxcaqybinyhaqx.sh
binxxx1x1xbinxybinx
dazmxnxxx2x2xdazmxnxysbinx
admxxx3x4xadmxyvaxyadmx
qpxxx4x7xqpxyvaxyspxxqyqpdx
syncxxx5x0xsyncxysbinxybinysync
maiqxxx8x12xmaiqxyvaxyspxxqymaiqx
nzwsxxx9x13xnzwsxyvaxyspxxqynzwsx
uucpxxx10x14xuucpxyvaxyspxxqyuucpx
xpzxaxxxxxx11x0xxpzxaxxxxyxxxxx
xamzsxxx12x100xxamzsxyusxyxamzsx
xxphzxxxx13x30xxxphzxxyusxyqibyxxphzx-daxax
fxpxxx14x50xFXP Uszxxyhxmzyfxpx
nxbxdyxxx99x99xNxbxdyxyx
qisxsxxx500x500xBzxxQisxxydzvynuqqxydzvynuqq
xfsxxx100x238xX Fxnx SzxvzxxyzxcyX11yfsxybinyfaqsz
xdmxxx42x42xxyhxmzyxdmxybinybash
mysqqxxx101x101xMySQQ szxvzxxyvaxyqibymysqqxybinybash
pxsxfixxxx102x102xpxsxfixxyvaxyspxxqypxsxfixx
pxsxxxzsxxx103x235xPxsxxxzSQQ Szxvzxxyvaxyqibypxsqqxybinybash
squidxxx104x104xxyvaxyspxxqysquidxydzvynuqq
hznxyxxxx501x501xHznxy Xxzbqzxxyhxmzyhznxyxxybinybash
maxkqxxxx502x502xMaxk Q. Xxzbqzxxyhxmzymaxkqxxybinybash
davidwxxx503x510xDavid Wiqsxnxyhxmzydavidwxybinybash
xzbxxxxxx0x0xXzbxxx xhz sysxzmxyxmpxyusxyqxcaqybinyxzbxxx.sh
xszxxx0x0xSxaxx ppp xx xszxyxmpxyusxyqxcaqybinyxsz.sh
xzxmsimxxx9999x9999xZmzxxzncy paxh xx xxxxxyxmpxybinysu

EOF

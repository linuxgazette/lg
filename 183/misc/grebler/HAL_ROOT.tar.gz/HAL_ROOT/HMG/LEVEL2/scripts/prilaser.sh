#!/bin/sh
#	prilaser.sh - print a file to laser

# To do:	word wrap
#		accept input from pipe (stdin).
#		expr subscr does not work with SYSV - sort out.

# History
#  1May96	Handle multiple files.
# 14Feb96	Set path for echo. 
# 15Dec95	Use fold so long lines aren't lost. Remove unused code.
# 13Oct95	Use expand so that tabs don't screw things up on '-o10'.
# 23May95	Force 12-pitch.
# 19May95	Use default printer by default or the one specified.
# 27Mar95	Actually print (rather than creating file *.laser_ready.
# 27Mar95	Use 5bin for -o.
#  6Mar95	Prev version moved to prilaser.sh.1
#		This version checks that there are no lines wider than 80
#		It does not fold. Altogether 61 lines per page are printed.
#		Of the original document, 56 lines per page are printed
#		(pri adds 5 lines of header).


#       =======================================================================
#       Functions
#       =======================================================================

do_one_file () {

	lines=`wc -l < $file`
	pages=`expr $lines / 56 + 1`

	echo document is $lines lines long '('== $pages pages ')'

	namelength=`echo $file | wc -c`
	blanks='                                         '
	pad=`expr substr "$blanks" $namelength 44`
#	echo "...$pad..."
	header="$file $pad"

	(
	PATH=/usr/5bin:/bin:$PATH

	echo '\033&k10H\c'
	expand $file | fold -s -80 | pr -o10 -f -h "$header"
	) | unix2dos | $lp

}

#       =======================================================================
#       Main line of script
#       =======================================================================

	if ${DEBUG-false} ;then set -xv; fi
	lp=lp
	if ${DEBUG_LP-false} ;then lp=cat; fi

	p1="$*"
	if [ "$p1" = "" ]
	then
		(PATH=/usr/5bin:/bin:$PATH; echo "filename: \c")
		read p1
		if [ "$p1" = "" ]; then exit; fi
	else
		shift
	fi

	for file in $p1
	do
		do_one_file
	done

	exit

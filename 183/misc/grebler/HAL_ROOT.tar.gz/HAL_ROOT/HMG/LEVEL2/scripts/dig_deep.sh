#! /bin/sh
#	dig_deep.sh - dig a little deeper

#  Henry Grebler    14 Aug 98  Usually don't do reverse lookup.
#  Henry Grebler    14 Aug 98  First cut.
#=============================================================================#

#name_servers='203.2.75.2'
name_servers='203.2.75.2 203.2.75.12 192.189.54.33 192.9.9.3 203.8.183.1'
# 192.189.54.17 192.189.54.5 192.189.54.85
notes='kyoko.mpx.com.au:poodle.mpx.com.au:warrane.connect.com.au
	:ns.Sun.COM:yalumba.connect.com.au'
#ns_name_1=

Usage () {
	if [ "$1" != "" ]
	then
		echo $*
	fi
	cat <<EOF
Usage: `basename $0` [-r] domain

	-r	do reverse lookups on name servers

EOF
	exit
}

do_reverse_lookup () {
	ns_x_response=`dig -x $ns`
	ns_reverse=`echo "$ns_x_response" |head -6 | tail -1 | \
			cut -c4- | cut -d',' -f1`
	ns_name=`echo "$ns_x_response" | \
			grep "^${ns_reverse}" | \
			awk '{print $NF}'`
}

#       =======================================================================
#       Main line of script
#       =======================================================================

	case "$1" in
		-r)	reverse=true
			shift
			;;
		-*)	Usage "Unknown switch"
			;;
		*)	break;;
	esac


	p1=$1
	if [ "$p1" = "" ]
	then
		echo "domain name: \c"
		read p1
		if [ "$p1" = "" ]; then exit; fi
	fi

	PATH=$PATH:/opt2/pd/src/dig.2.0

	i=1
	for ns in $name_servers
	do
		if [ "$reverse" = true ]
		then
			do_reverse_lookup
		else
			jj='$'$i
			ns_name="`echo $notes | awk -F: '{print '$jj'}'`"
		fi
		echo "------------	$ns	------------	${ns_name}"
		dig @$ns $p1 any | grep "^${p1}\." | grep "	[MA][X	]"
		i=`expr $i + 1`

		continue

		echo name server: $ns_name
		cat <<EOF
------------------------------------------------------------------------
EOF
		dig @$ns $p1 any | grep "^$p1 *894"
		cat <<EOF
------------------------------------------------------------------------
EOF

	done

#! /bin/sh
#	find.sh - find with a more reasonable time

tmp=/tmp/tmp_find_$$.tmp

Usage () {
	cat <<EOF
find.sh [-dt MMDD[hhmm[YY]] <find_args>
EOF
	exit
}

GetDate () {
	if [ "$1" = "" ]
	then
		Usage
	fi
		
	n=`expr $1 : [0-9]*`
	if [ $n -ne 4 -a $n -ne 8 -a $n -ne 10 ]; then Usage; fi
	if [ $n -eq 4 ]
	then
		date=${1}0000
	else
		date=${1}
	fi
	set -x
	/bin/touch $date $tmp
	set +x
	new=true	
}

	new=false
	path_arg=
	while test $# -gt 0
	do
		case $1 in
			-dt)	shift; GetDate $1;shift;;
			-*)	break;;
			*)	path_arg="$path_arg $1";shift;;
		esac
	done

	set -x
	if eval $new
	then
		find $path_arg -newer $tmp "$@"
		rm $tmp
	else
		find $path_arg "$@"
	fi

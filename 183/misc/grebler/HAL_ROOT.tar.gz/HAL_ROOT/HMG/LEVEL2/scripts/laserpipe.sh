#!/bin/sh
#	laserpipe.sh - prepare a text file for the laser(s)

#	20Dec98	Modify echo for Linux.
#	21Sep98	Fix order of args to awk.
#	16Jul98	Don't set some things here so that landscape.sh and laser.sh
#		can share laserpipe.sh.
#	10Jun98	Use 12-pitch Elite
#	28Oct96	Handle special chars in input (\f\r, etc)
#	22Mar94	follow each file with formfeed
#	22Nov93	Make into pipe; rearrange.
#		   HMG 19 December 1991

#	Usage:	laser [filename... ] [| lpr -Plaser[4m]]

#		sends a text file to stderr (adds CR before LF).

	if [ `uname` = Linux ]
	then
		enable -n echo
	else
		PATH1="$PATH"
		PATH=/usr/5bin:$PATH
	fi
esc=`echo '\\033'`

AddCR(){
	awk '{print "        " $0 "\r"}' -
	printf "\f${esc}E"
}
	input="$*"
	if [ "$input" = "" ]
	then
		AddCR
		exit
	fi
	for file in $input
	do
		AddCR < $file
	done

#!/bin/sh
#	fixtime.sh - update the hardware clock


	cat <<EOF
This script updates the hardware clock from the time on optim1.
This won't fix this machine's time as far as Linux is concerned, but,
next reboot, the time should be fairly accurate.

This script is not a replacement for /etc/rc0.d/K10ntpdate (=
/etc/init.d/ntpdate), but that doesn't seem to be doing anything.

EOF

	if [ `whoami` != root ]
	then
		cat <<EOF
I don't know that it willwork unless you are root.

EOF
	fi

	cat <<EOF
This is what the hardware clock thinks is the time:

	`hwclock --show`
	`hwclock --show --utc`
EOF

	date_cmd="rsh optim1 date \'+%m/%d/%Y %H:%M:%S\'"
	if [ `whoami` != root ]
	then
		now=`$date_cmd`
		pre=
	else
		now=`su - henryg -c "$date_cmd"`
		pre='su - henryg -c '
	fi
	if [ "$now" != "" ]
	then
		hwclock --set --date="$now" || {
			cat <<EOF
The time did NOT get changed, but it would have been set to:

	$now
EOF
			exit
		}
	else
		cat <<EOF
Couldn't get the time from optim1. Nothing was updated.
EOF
		exit
	fi

	cat <<EOF
optim1's time was:

	$now

Hardware clock now shows:

	`hwclock --show`

optim1 again:

	`$pre "date"`

EOF

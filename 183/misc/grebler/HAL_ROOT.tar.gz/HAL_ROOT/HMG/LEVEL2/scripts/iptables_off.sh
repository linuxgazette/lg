#! /bin/sh
#	iptables_off.sh - really turn it off

#=============================================================================#
# Motivation

# I miss ipfilter. Where is the equivalent of "ipf -F a"?

# This script is supposed to achieve this.

# Part of the problem arise from the fact that iptables is incoherent.
# There is a set of commands to do various things ("iptables ..."),
# but a completely different syntax is used in iptables-save and
# iptables-restore.

# Further, there is asymmetry. On a machine on which no iptables
# commands have been issued, iptables-save produces an empty answer
# (zero lines). But once iptables has been invoked, one cannot get
# back to this state with only iptables commands. This script solves
# this issue as well.

#----------------------------------------------------------------------#
# First clean the basic stuff

	iptables --flush
	iptables --delete-chain

# Then the other tables

	tables=`iptables-save | fgrep '*' | tr -d '*'`

	for table in $tables
	do
		iptables -t $table --flush
		iptables -t $table --delete-chain
	done

# Now unload some of the modules

	modules=`lsmod | grep ip_tables | cut -d '[' -f2 | tr -d ']'`
	[ "$modules" = "" ] || rmmod $modules

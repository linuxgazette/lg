:
#	pri.sh - print a file with its pathname as header
#		 filter out the last form feed coz our lpr adds 1

	tmp=/tmp/tmp.hmg.lpr
	fold -80 $* | pr -f -h `pathname $1` >$tmp
	lc=`wc $tmp | cut -c1-8`
	lc=`echo $lc`
	head -$lc $tmp | lpr
	rm $tmp

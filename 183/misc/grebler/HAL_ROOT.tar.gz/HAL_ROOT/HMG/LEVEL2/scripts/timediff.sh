#! /bin/sh
#	timediff.sh - difference between 2 times (answer in seconds)

#	Usage timediff start_time end_time
#		start_time, end_time in format hh:mm:ss[.nnn]

	nawk -f -  < /dev/null <<EOF
BEGIN	{
	start_time="$1"
	end_time="$2"
	split(start_time,ts,":")
	split(end_time,te,":")
	print ((te[1] - ts[1]) * 60 + te[2] - ts[2]) * 60 + te[3] - ts[3]
}
EOF

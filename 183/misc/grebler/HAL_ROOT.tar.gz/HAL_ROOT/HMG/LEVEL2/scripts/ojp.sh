#! /bin/sh
#	ojp.sh - prepare a text file for printing on the 
#			HP Officejet Pro L7380

Usage () {
        cat <<EOF
Usage: `basename $0` [-l | --landscape] [file...]
EOF
	exit
}

#----------------------------------------------------------------------#

	while test $# -gt 0
	do
		case "$1" in
		     -l | --landscape)	arg="$arg --landscape";;
		      -*)	Usage;;
		      *)	break;;
		esac
		shift
	done

	enscript $arg -p- --header " " --font Courier9 --margins 70::40: \
                $1 | lp

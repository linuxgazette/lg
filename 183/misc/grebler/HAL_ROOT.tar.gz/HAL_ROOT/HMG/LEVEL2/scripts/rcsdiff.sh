#!/bin/sh
#	rcsdiff.sh - do an rcsdiff, but only indicate different files

cat <<XXX
Usage:	rcsdiff.sh <filespec>	eg rcsdiff.sh *.c

The following files differ:

XXX

#	echo '<<<'$*'>>>'
	p1=$*
	if [ "$p1" = "" ]
	then
		echo -n "filespec: "
		read p1
		if [ "$p1" = "" ]; then exit; fi
	fi
	for i in $p1
	do
		`rcsdiff $i > /dev/null 2>&1`
		case $? in
			1)	echo $i;;
			2)	echo '[not in RCS]     '$i;;
		esac
	done

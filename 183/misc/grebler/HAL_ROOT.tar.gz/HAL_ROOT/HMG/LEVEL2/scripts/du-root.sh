#!/bin/sh
#	du-root.sh - industrial-strength du for the root partition

#  Henry Grebler    10 Nov 08  First cut (from du-forte.sh).
#=============================================================================#

	cat <<EOF
This script performs 
	du -csk /*
for directories (not files) on the root partition only.
EOF

	options=sk

	candidates=`find / -mount -maxdepth 1 -mindepth 1 -type d`
	root_df=`df /`

	for dir in $candidates
	do
		if [ "$root_df" = "`df $dir`" ]
		then
			du -$options $dir
		else
			echo Skipping non-root $dir
		fi
	done | tee /dev/tty | \
		awk '
########	Start of awk script	#####################################
$2 != "/proc"	{sum=sum + $1}
END		{print "Total (excludes /proc)", sum}
########	End of awk script	#####################################
'

#!/bin/sh
#	lns.sh - make symbolic links

# History:
 
# 5Jan95 Fix previous fix. We need to check twice. Once for possibility that
#	   link to directory is being overwritten; 2nd if construct is
#		lns <spec> <dir> 
#	   where <dir> is a real directory eg . (current directory).
# 6Oct94 Fix if overwriting link to directory

#	usage: lns from to

        if ${DEBUG-false} ;then set -xv; fi
	PATH=/usr/5bin:$PATH

#       =======================================================================
#       Functions
#       =======================================================================

get_answer(){
        read ans
        ans=`echo $ans | cut -c1 | tr Y y`
        if (test "$ans" != "" -a "$ans" != "y") then
                exit
        fi
        return
}                       #       Only returns on satisfactory answer

LinksAndFiles () {
	if [ -h "$target" ]
	then
#	If it is not a file, but it is a symbolic link, then presumably
#	it doesn't point to anywhere useful.
		rm $target
	elif [ -f "$target" ]
	then
		ls -lad $target
		echo 'delete this entry? [y] \c'
		get_answer
		rm $target
	fi

}

#       =======================================================================
#       Main line of script
#       =======================================================================

#	echo '$1='$1'... $2='$2'...'
#	echo '$#='$#

	if [ $# -gt 2 ]
	then
		echo Too many args
		exit
	fi


	target=$2
	if [ "$target" = "" ]
	then
		target=.
	fi

	LinksAndFiles

	if [ -d "$target" ]
	then
		file=`basename $1`
		target=$target/$file
		LinksAndFiles
	fi

	ln -s $1 $target

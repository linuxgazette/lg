#!/bin/sh
#	du-forte.sh - industrial-strength du

#  Henry Grebler    16 Jun 97  Calculate sum.
#  Henry Grebler    11 Sep 96  Improve (df archive didn't work).
#  Henry Grebler     4 Mar 96  First cut.

# For the moment, only looks at local files

	options=dskr
	case "`uname -sr`" in
		"SunOS 4"*)	options=s;;
		"SunOS 5"*)	options=dskr;;
		"Linux "*)	options=skx;;
		*)		cat <<EOF
This may not work because the options are not coded for this machine.
But don't let that stop you trying.
EOF
				;;
	esac


	for i
	do
		if [ -d $i ]
		then
			x=`cd $i; df . | cut -c1-12 | grep ':'`
		else
			x=
		fi
		if [ "$x" = "" ]
		then
			du -$options $i
		else
			echo Skipping non-local $i
		fi
	done | \
	awk '
########	Start of awk script	#####################################
		{print}
$2 != "/proc"	{sum=sum + $1}
END		{print "Total (excludes /proc)", sum}
########	End of awk script	#####################################
'

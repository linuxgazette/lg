#! /bin/sh
#	browser_newlines.sh

# When filling long answers in browsers, they don't want newlines
# exceptat the end of paragraphs. When using emacs, this is awful.

# So do what you want in emacs, then run this over the answer.


	tr '\012' '~' < $1 | sed 's/~~/``/g' | tr '~' ' ' | tr '`' '\012'

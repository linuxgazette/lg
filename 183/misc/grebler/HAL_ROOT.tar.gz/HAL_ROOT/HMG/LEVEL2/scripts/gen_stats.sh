#! /bin/sh
#	gen_stats.sh - Generate statistics from log and dbg.

#  Henry Grebler    23 Jul 98  Create a dummy results dir to make 
#				generate_stats happy.
#  Henry Grebler    27 Apr 98  Stop on error to avoid consequentials. Look
#				for generate_stats in PATH. It seems
#				that name of csv changed to log.csv.
#  Henry Grebler    26 Jan 98  Improve result-finding algorithm.
#  Henry Grebler    26 Jan 98  Guard against a previous failure.
#  Henry Grebler    23 Jan 98  Ditch statsu.log.
#  Henry Grebler    16 Jan 98  First cut.
#=============================================================================#


# Note - this script was originally designed to handle 2 log files:
# one called log and the other called dbg. I have since tried to
# improve it so that it handles the normal case normally.


#### NEXT TIME!!! Make a function of the common stuff and call it once
#### or twice.



	if [ -h log ]
	then
		cat <<EOF
There is a soft link called 'log'. Perhaps a previous run was aborted.
Fix it and try again.
EOF
			exit 1
	fi
	if [ ! -f log ]
	then
		cat <<EOF
There is no file called 'log'. My brilliant creator was not able to
design logic to handle this contingency. You had better sort it out
yourself.
EOF
		exit
	fi

	if [ -d results ]; then :
	elif [ -d ../results ]; then :
	elif [ -d ../../results ]; then :
	else
		echo Making a dummy results dir to keep generate_stats happy.
		MAKE_RESULTS=true
		mkdir results
	fi

# ------------------------------------------------------------------------
	here=`pwd`
	cd $here
	log_dir=`pwd`

# ------------------------------------------------------------------------
	if [ -f dbg ]
	then
		mv log log.keep
		tmp_dir=/tmp/gen_stats.$$
		mkdir $tmp_dir
		tmp="$tmp_dir/watch"

		ln -s dbg log
	
		cat > $tmp <<EOF
#! /bin/sh
echo "Not doing 'watch -list' for dbg"
EOF

		chmod u+x $tmp

		PATH=$tmp_dir:$PATH
		export PATH
		
#		/opt/optimation/termsim/tools/generate_stats -f $log_dir
		generate_stats -f $log_dir
	
		if [ ! -f log.csv ]
		then
			cat <<XXX
I don't think it worked because there is no file log.csv here. Exiting.
XXX
			exit
		fi
		rm log.csv
	
		rm sessions
		mv stats stats.dbg
		rm statsu
		mv summary summary.dbg
	
		rm log
		rm -rf $tmp_dir

		echo
		ln -s log.keep log
	fi
# ------------------------------------------------------------------------

#	set -e	# doesn't work because last command in generate_stats
#		# can be a failing grep
#	/opt/optimation/termsim/tools/generate_stats -f $log_dir

	(set -x; generate_stats -f $log_dir)

	if [ -f log.csv ]
	then
		rm log.csv
	elif [ -f csv ]
	then
		rm csv
	else
		cat <<XXX
I don't think it worked because there is no file log.csv and no 
file csv here. Exiting.
XXX
		exit
	fi

	if [ -f dbg ]
	then
		mv stats stats.log
		mv summary summary.log

		rm log
		mv log.keep log
	fi

	if [ "$MAKE_RESULTS" = true ]
	then
		echo Removing dummy results dir.
		rmdir results
	fi

#!/bin/sh
#	optus.sh - usage for cable quota


	last=`tail -16 /home/henryg/help/help_optus`
	usage=`echo "$last" | grep usage | tail -1`
	mb=`echo "$usage" | sed 's/usage=\([1-9][0-9]*\)MB/\1/'`
	printf "MB used = %d\n" $mb
	dom=`date +%d`
	days=`expr $dom - 1`
	[ $days -lt 1 ] && days=1
	used_rate=`echo "scale = 1; $mb / $days" | bc`
	printf "used MB/day = %7.1f\n" $used_rate
	doy=`date +%j`
	year=`date --date='today + 31 days' +%Y`
	month=`date +%m`
	month=`expr $month + 1`
	[ $month -eq 13 ] && month=1
	month=`printf "%02d" $month`
	doy_fonm=`date --date="$year${month}01" +%j`
	days_left=`expr $doy_fonm - $doy`
	[ $days_left -lt 0 ] && days_left=`expr $days_left + 365`
	left_rate=`echo "scale = 1; (1000 - $mb) / $days_left" | bc`
	printf "remaining MB/day = %7.1f\n" $left_rate

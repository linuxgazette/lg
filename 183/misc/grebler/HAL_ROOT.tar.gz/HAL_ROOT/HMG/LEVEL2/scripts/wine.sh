#!/bin/sh
#	wine.sh - invoke wine

PATH=/sw/pd/src/wine/wine-011106/bin:$PATH
LD_LIBRARY_PATH=/sw/pd/lib:/sw/pd/src/wine/wine-011106/lib:$LD_LIBRARY_PATH

	wine "$@"

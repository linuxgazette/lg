#! /bin/sh
#	xsysstats.sh - hmg's personalised wrapper for xsysstats

Main () {
	if [ $# -eq 0 ]
	then
		DoLocal "$@"
	else
		DoRemote "$@"
	fi
}

#----------------------------------------------------------------------#
DoLocal () {
		hostname=`hostname | cut -d . -f 1`

# Add 66 to Y (-geometry 100xY) for each new parameter
# ... and 1 to -split

	xsysstats -background white -baseline blue -title "$hostname" \
		-split 1x10 -geometry 100x660+0+300 \
		-type cpu	-color GoldenRod \
		-type load1	-color DarkGreen \
		-type disk	-color GoldenRod \
		-type pagei	-color DarkGreen \
		-type context	-color GoldenRod \
		-type swap	-color DarkGreen \
		-type interrupts -color GoldenRod \
		-type packets	-color DarkGreen \
		-type collisions -color GoldenRod \
		-type errors	-color DarkGreen \
		&
}

#----------------------------------------------------------------------#
DoRemote () {
	hostname=$1
	host=$hostname

	xsysstats -background white -baseline blue -title "$hostname" \
		-split 1x10 -geometry 100x660+0+300 \
		-type cpu@$host		-color GoldenRod \
		-type load1@$host	-color DarkGreen \
		-type disk@$host	-color GoldenRod \
		-type pagei@$host	-color DarkGreen \
		-type context@$host	-color GoldenRod \
		-type swap@$host	-color DarkGreen \
		-type interrupts@$host	-color GoldenRod \
		-type packets@$host	-color DarkGreen \
		-type collisions@$host	-color GoldenRod \
		-type errors@$host	-color DarkGreen \
		&
}

#----------------------------------------------------------------------#
	Main "$@"
	exit

#----------------------------------------------------------------------#
Original:


xsysstats -background white -baseline blue -title "Remote status of localhost" -split 7x1 -geometry 840x120-0+0 -type cpu@localhost -color DarkRed -type load1@localhost -color DarkOrange -type disk@localhost -color DarkGreen -type packets@localhost -color GoldenRod -type swap@localhost -color black -type pagei@localhost -color purple -type interrupts@localhost -color brown


:
#	hed.sh - like head but the arg refers to distance from end


	if (test $# -eq 1) then
		n=1
	else
		n=$1
		shift
	fi
	len=`wc $1 | cut -c1-8`	
	len=`expr $len - $n`
	head -$len $1

exit

HED(1)                  USER COMMANDS                    HED(1)



NAME
     hed -  display the first part of a file

SYNOPSIS
     hed [ n ] [ filename...]

DESCRIPTION
     hed copies filename to the standard output ending  n lines
     from the end of file.   If no file is named, the standard input
     is used.  The  default  value  of  n  is  1 line.



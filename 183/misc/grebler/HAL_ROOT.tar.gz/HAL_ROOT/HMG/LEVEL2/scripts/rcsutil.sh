#!/bin/sh
#	rcsutil.sh - miscellaneous info about RCS files

#  Henry Grebler    26 Jun 96  Permit -? (= -help). Catch -x where option x is
#				not defined.
#  Henry Grebler    19 Jun 96  First cut.
########################################################################


	MyName=`basename $0`
	Myrev='$Revision: 1.2 $'


#       =======================================================================
#       Functions
#       =======================================================================

Usage () {
	cat <<XXX
$MyName revision: $Myrev

Usage:	$MyName [-help ]
	$MyName [-latest] [-symbolic <symbolic>] filename
	$MyName -equiv <symbolic> <new_symbolic> filename

	options may be abbreviated to their minimum unique strings

	-help		this message
	-latest		display latest revision (ie head) [default]
	-previous	display previous revision (ie "head - 1")
	-symbolic	display the revision which corresponds to the 
			symbolic name supplied
	-equiv		associate the new_symbolic name with the same rev
			with which symbolic name (which MUST exist) is
			associated

	filename	can be a working file or RCS file

XXX
	exit $error
}

CalculateRev () {
	rev=`rlog -h $filename | sed -n 's/^head:[   ]*//p'`
}

CalculatePrev () {
	CalculateRev
	trev=`echo $rev | cut -f2 -d.`
	trev=`expr $trev - 1`
	prev=`echo $rev | cut -f1 -d.`.$trev
}

DisplayLatest () {
	CalculateRev
	echo $rev
}

DisplayPrevious () {
	CalculatePrev
	echo $prev
}


DisplaySymbolic () {
	symbolic_names=`rlog $filename | grep "^$TAB"`
	required_symbol=`echo "$symbolic_names" | grep $SYMBOL`
	status=$?
	if [ $status -eq 0 ]
	then
		echo `echo $required_symbol | cut -f2 -d:`
		return
	fi
	if [ $status -eq 1 ]
	then
		echo "'$SYMBOL' not found"
		exit 1
	fi
	if [ $status -eq 2 ]
	then
		echo grep error
		exit 2
	fi
}

ParseSymbolic () {
	if [ $# -lt 3 ]
	then
		echo "Insufficient args with '$1'"
		Usage
	fi
	symbolic=true
	SYMBOL=$2
	dosomething=true
}

CheckRequest () {
	if [ $dosomething = false ]
	then
		latest=true
	fi
	if [ $# -ne 1 ]
	then
		echo Too many filenames
		Usage
	fi
	filename=$1
}

Equiv () {
	if [ $# -ne 4 ]
	then
		Usage
	fi

	rev=`$0 -symbolic $2 $4`
	status=$?
	if [ $status -eq 1 ]
	then
		echo "Symbolic name '$2' not found in file '$4'"
		echo
		Usage
	fi
	if [ $status -ne 0 ]
	then
		echo "An error occurred attempting '$0 -symbolic $2 $4'"
		exit 4
	fi

	if [ "$rev" = "" ]
	then
		echo "'$0 -symbolic $2 $4' returned a null rev"
		exit 5
	fi

	rcs -q -N${3}:$rev $4
	exit
}

#       =======================================================================
#       Main line of script
#       =======================================================================

	
	error=3
	TAB='	'
	dosomething=false
	latest=false
	previous=false
	symbolic=false

	while test $# -gt 0
	do
		case $1 in
		     -e*)	Equiv "$@";;
		     -? | -h*)	error=; Usage;;
		     -l*)	latest=true; dosomething=true;;
		     -p*)	previous=true; dosomething=true;;
		     -s*)	ParseSymbolic "$@"; shift;;
		     -*)	Usage;;
		      *)	CheckRequest "$@";;
		esac
		shift
	done

	if [ $latest = true ]
	then
		DisplayLatest
	fi

	if [ $previous = true ]
	then
		DisplayPrevious
	fi

	if [ $symbolic = true ]
	then
		DisplaySymbolic
	fi

	exit


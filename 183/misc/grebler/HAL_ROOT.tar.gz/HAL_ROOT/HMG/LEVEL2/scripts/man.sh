#! /bin/bash
#	man.sh - attempt to get "man -a" like Solaris



Classify () {
	case $file in
		*gz)	cmd='gzip -dc';;
		*bz2)	cmd='bzip2 -dc';;
		*)	cmd=cat;;
	esac
}

# 	set -xv
	if [ "$DEBUG" == "" ]
	then
		echo=
		eval=eval
	else
		echo=echo
		eval=
	fi
	MAN=/usr/bin/man
	files=`$MAN -aw $*`
	for file in $files
	do
		Classify
		arg="$arg <($cmd $file | nroff -man)"
	done

	$eval $echo less -is $arg
	echo "I'm trying a new man for Linux"

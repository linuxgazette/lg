#!/bin/sh
#	set_gnutar.sh - set value to be assigned to gnutar alias

#  Henry Grebler    18 Sep 96  The wrong things were being found.
#  Henry Grebler     3 Jun 96  If no tar in /usr/local/bin, use any tar.
#  Henry Grebler    21 Apr 95  First cut.


#	GNUTAR=`ls /usr/local/bin/tar`

	if [ -x /usr/local/bin/tar ]
	then
		GNUTAR=/usr/local/bin/tar
	else
		GNUTAR=tar
	fi
	echo $GNUTAR

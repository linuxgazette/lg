#!/bin/sh
#	GO.sh - invoke HAL from the HAL_ROOT

	dir=`dirname $0`                # directory this file is run from
	cd $dir
	dir=`pwd`

	HOME=`pwd`/HAL_HOME
	export HOME
	cd $HOME
	exec bash --login

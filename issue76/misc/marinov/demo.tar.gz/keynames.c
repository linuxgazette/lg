/*

File: keynames.c
Project: W, Layer2 -- DOS32 application (DJGPP) and WIN32 console application
Started: 27th October, 1998
Descrition:
  Keyboard names definitions.

*/

#include "global.h"
#include "kbd.h"

/*
Key names (scan code as index)
*/
const char *KeyNames[] =
{
  "Esc", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "BckSpc",
  "Tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "Return",
  "Ctrl", "A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "'", "`",
  "Shift", "\\", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "Shift", "PrSc",
  "Alt", "Space", "CapsLock",
  "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10",
  "NumLock", "ScrollLock", "Home", "Up", "PgUp", "Gray-",
  "Left", "Pad5", "Right", "Gray+",
  "End", "Down", "PgDn", "Ins", "Del"
};

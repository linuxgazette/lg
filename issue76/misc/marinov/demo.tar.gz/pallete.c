/*

File: pallete.h
Project: W, Layer2 -- DOS32 application (DJGPP) and WIN32 console application
Started: 9th November, 1998
Descrition:
  Collor pallete.
  Borland pallete, Borland conservative pallete, Dark pallete,
  BW pallete, Classic termina pallete.

*/

#include "global.h"
#include "pallete.h"

BYTE BorlandPallete[MAX_PALLETE] =
{
  0x70, 0x4f,  /* coStatus, coError */
  0x4f, 0x4e,  /* coTabs, coReadOnly */
  0x71,        /* coRecStored */
  0x70, 0x74,  /* coStatusTxt, coStatusShortCut */
  0x1f, 0x1e,  /* coEOF, coEdText */
  0x70, 0x1b,  /* coEdNumber, coEdComment */
  0x17, 0x1f,  /* coEdComment, coEdReserved */
  0x1a, 0x1f,  /* coEdRegister, coEdInstruction */
  0x1b, 0x1a,  /* coEdString, coEdPreproc */
  0x1f, 0x1a,  /* coEdOper, coEdSFR */
  0x12,        /* coEdPair */
  0x0f, 0x0f,  /* coSmallEOF, coSmallEdText */
  0x70, 0x0f,  /* coSmallEdBlock, coSmallEdNumber */
  0x0f, 0x0f,  /* coSmallEditEdComment, coSmallEditEdReserved */
  0x0f, 0x0f,  /* coSmallEditEdRegister, coSmallEditEdInstruction */
  0x0f, 0x0f,  /* coSmallEditEdString, coSmallEditEdPreproc */
  0x0f, 0x0f,  /* coSmallEditEdOper, coSmallEditEdSFR */
  0x0f,        /* coSmallEditEdPair */
  0x0a,        /* coEnterLn */
  0x20, 0x0b,  /* coUnchanged, coEnterLnPrompt */
  0x02,	       /* coEnterLnBrace */
  0x70, 0x70,  /* coUMenuFrame, coUMenuItems */
  0x20, 0x70,  /* coUMenuSelected, coUMenuTitle */
  0x30, 0x30,  /* coHelpFrame, coHelpItems */
  0x3e, 0x30,  /* coHelpSelected, coHelpTitle */
#if 0
  0x3f,        /* coHelpText (infordr) */
  0x30,        /* coHelpLink (infordr) */
  0x3e,        /* coHelpHighlightLink (infordr) */
  0x37,        /* coHelpHighlightMenu (infordr) */
  0x17,        /* coHelpTextSelected (infordr) */
#endif
  0x07,        /* coHelpText (infordr) */
  0x0f,        /* coHelpLink (infordr) */
  0x30,        /* coHelpHighlightLink (infordr) */
  0x02,        /* coHelpHighlightMenu (infordr) */
  0x70,        /* coHelpTextSelected (infordr) */
  0x70, 0x74,  /* coMenu, coMenuShortCut */
  0x20, 0x24,  /* coMenuSelected, coMenuSeShortCut */
  0x78, 0x70,  /* coMenuDisabled, coMenuFrame */
  0x08,        /* coMenuSeDisabl */
  0x3f, 0x30,  /* coCtxHlpMenu, coCtxHlpMenuShortCut */
  0x0e, 0x07,  /* coCtxHlpMenuSelected, coCtxHlpMenuSeShortCt */
  0x37, 0x30,  /* coCtxHlpMenuDisabled, coCtxHlpMenuFrame */
  0x3e,        /* coCtxHlpMenuSeDisabl */
  0x02, 0x0a   /* coTerm1, coTerm2 */
};

BYTE *CPallete = BorlandPallete;        /* Current pallete */


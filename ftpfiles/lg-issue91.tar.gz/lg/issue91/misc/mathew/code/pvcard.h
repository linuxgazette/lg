/* Pixel View Card Model Name. */
#define PVCLPP_COMBO 0

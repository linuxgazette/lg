select sql_contact_insert();
select sql_contact_update(1,1,'Company ABC','Dummy1','','Account','nobody@nowhere.com','','','','','','San Jose','CA','95135','USA');

select sql_contact_insert();
select sql_contact_update(2,1,'Company ABC','Dummy2','','Account','nobody2@nowhere.com','','','','','','Columbus','OH','43221','USA');


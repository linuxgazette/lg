select sql_students_insert();
select sql_students_update(1,1,1);

select sql_students_insert();
select sql_students_update(2,2,1);

select sql_students_insert();
select sql_students_update(3,1,2);

select sql_students_insert();
select sql_students_update(4,2,2);













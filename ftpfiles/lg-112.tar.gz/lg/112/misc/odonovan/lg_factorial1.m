function answer = lg_factorial1( n )

    answer = 1;
    
    for i = 2:n
        answer = answer * i;
    endfor

endfunction

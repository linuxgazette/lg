from libdesklets.controls import Interface, Permission

class Intp(Interface):
    ntp_time = Permission.READ

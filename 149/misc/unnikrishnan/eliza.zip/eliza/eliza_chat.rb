 require 'rubygems'  
 require 'xmpp4r-simple'  
 require 'eliza'

 username = gmailusername  
 password = gmailpassword
 
 puts "connecting to jabber server"  
 im = Jabber::Simple.new(username+'@gmail.com',password)  
 puts "connected."  
   
 while (true) do  
         im.received_messages do |msg|  
                 puts "==================================================================="  
                 puts msg.body  
                 puts "-------------------------------------------------------------------"  
                 im.deliver(msg.from.node+"@gmail.com",eliza(msg.body))
         end  
	sleep(1)
 end  

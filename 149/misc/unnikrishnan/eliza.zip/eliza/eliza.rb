require 'net/http'

def eliza(str)
    response = Net::HTTP.post_form(URI.parse("http://www-ai.ijs.si/eliza-cgi-bin/eliza_script"),{'Entry1'=>str})
    return response.body.split("</strong>\n").last.split("\n").first
end

 require 'rubygems'  
 require 'xmpp4r-simple'  
 require 'read_dict'


 $dictionary = read_dictionary
 
 def lookup(word)
    if $dictionary.has_key?(word)
      return $dictionary[word]
    else
      return "Sorry #{word} is not it our dictionary :("
    end
 end

 username = 'kunjimathi'  
 password = 'kernel56'  
   
 puts "connecting to jabber server.."  
 jabber = Jabber::Simple.new(username+'@gmail.com',password)  
 puts "connected."  


   
 while (true) do  
         jabber.received_messages do |msg|  
                 puts "=================================================="
                 exit if msg.body.downcase.strip == 'exit'  
                 puts msg.body  
                 puts "--------------------------------------------------"
                 word =  msg.body  
                 jabber.deliver(msg.from.node+"@gmail.com",lookup(word.downcase))  
         end
	sleep(1)  
 end  

def read_dictionary
    dict = {}
    open("French.txt").each_line do |line|
      x = line.chomp.split("\t")
      dict[x[0]] = x[1]
    end
    return dict
end



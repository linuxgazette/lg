/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
#include "auto.h";

//============== constructor and destructor ====================================

void Form4::init()
{//--- code to execute just before visual components are displayed.
 theLines.clear();
 xnum =1;
 pt =0;
 cnt=0;
 remember =0; 
 avgT1 = 0;
 avgT2 = 0;
 avgT3 = 0;
 avgL = 0;
 thermo_peak =0;
 thermo_trough =400;
 light_peak =0;
 light_trough =400;
 textLabel->hide();
 textBrowser->hide();
 invalidLabel->hide();
}

void Form4::destroy()
{//--- code to execute when form closed but before visual components are destroyed.
}

//============================================================
// Load Grid
//============================================================

//------paintGrid()-----------------------------------------------------------------------------------------------
//
//PURPOSE - paints a grid on to the widgit 

void Form4::paintGrid()//---------------------------------------------------------------------------------------
{
  int xlines = 0; 
  int ylines = 0; 

  //-----Create QPainter grid-----------		 
  QPainter grid( pixmapTemp );
  QPen p1(Qt::black, 0, Qt::SolidLine ) ;
  QPen p2(Qt::lightGray, 0, Qt::SolidLine ) ;
  QPen p3(Qt::red, 0, Qt::SolidLine );
  QPen p4(Qt::blue, 0, Qt::SolidLine);
  QPen thermo(Qt::red, 1, Qt::DashLine ) ;
  QPen lux(Qt::black, 1, Qt::DashLine ) ;
  //---- scaling--------
  grid.translate(30, 460);
  
  //-----temperature scale-----------
  grid.setPen(p3); 
  grid.drawText(-25, 10, "(0,0)", -1) ;
  grid.drawText(-20, -47, "5", -1) ;
  grid.drawText(-20, -97, "10", -1) ;
  grid.drawText(-20, -147, "15", -1) ;
  grid.drawText(-20, -197, "20", -1) ;
  grid.drawText(-20, -247, "25", -1) ;
  grid.drawText(-20, -297, "30", -1) ;
  grid.drawText(-20, -347, "35", -1) ;
  grid.drawText(-20, -397, "40", -1) ;
  grid.drawText(-20, -447, "45", -1) ;
  //-----LUX scale-----------
  grid.setPen(p1); 
  grid.drawText(607, -3, "0", -1) ;
  grid.drawText(607, -47, "450", -1) ;
  grid.drawText(607, -97, "900", -1) ;
  grid.drawText(607, -147, "1350", -1) ;
  grid.drawText(607, -197, "1800", -1) ;
  grid.drawText(607, -247, "2250", -1) ;
  grid.drawText(607, -297, "2700", -1) ;
  grid.drawText(607, -347, "3150", -1) ;
  grid.drawText(607, -397, "3600", -1) ;
  grid.drawText(607, -447, "4050", -1) ;

  //-------time scale---------------------
  grid.setPen(p4); 
  if(xnum==1)
  {
  grid.drawText(37, 15, "4", -1) ;
  grid.drawText(77, 15, "8", -1) ;
  grid.drawText(114, 15, "12", -1) ;
  grid.drawText(154, 15, "16", -1) ;
  grid.drawText(194, 15, "20", -1) ;
  grid.drawText(234, 15, "24", -1) ;
  grid.drawText(274, 15, "28", -1) ;
  grid.drawText(314, 15, "32", -1) ;
  grid.drawText(354, 15, "36", -1) ;
  grid.drawText(394, 15, "40", -1) ;
  grid.drawText(434, 15, "44", -1) ;
  grid.drawText(474, 15, "48", -1) ;
  grid.drawText(514, 15, "52", -1) ;
  grid.drawText(554, 15, "56", -1) ;
  grid.drawText(594, 15, "60", -1) ;
}

  if(xnum==2)
  {  grid.drawText( 282, 15, "1st Hour", -1) ;  
  grid.drawText( 577, 15, "2nd Hour", -1) ;
  }

  if(xnum==5)
  {  grid.drawText( 108, 15, "1st Hour", -1) ;  
  grid.drawText( 227, 15, "2nd Hour", -1) ;
  grid.drawText( 346, 15, "3nd Hour", -1) ;
  grid.drawText( 462, 15, "4st Hour", -1) ;  
  grid.drawText( 577, 15, "5nd Hour", -1) ;
  }
  //----------Coloured Labels---------------  
  grid.setPen(Qt::red);
  grid.drawText(-20, 40, "TempC Vs Time : ", -1) ;
  grid.setPen(Qt::red);
  grid.drawText(120, 40, "-- Temp 1 ", -1) ;
  grid.setPen(Qt::blue);
  grid.drawText(210, 40, "-- Temp 2 ", -1) ;
  grid.setPen(Qt::green);
  grid.drawText(300, 40, "-- Temp 3 ", -1) ;
  grid.setPen(Qt::black);
  grid.drawText(390, 40, ". . . Light ", -1) ;
  grid.setPen(Qt::black);
  grid.drawText(500, 40, "LUX Vs Time: ", -1) ;
  grid.scale(1,-1);
  
  grid.setPen( p1 );
  grid.drawRect( 0,0, 600,460 );
  grid.setPen( p2 );
  
  //------ x axises-----------
  for( int n=45; n >0; n--)
  {	xlines = xlines + 10;  
	grid.drawLine( 0,xlines, 600,xlines ); 	
  }
  
  //------ y axises------------
  for( int m=(60*xnum); m >0; m--)
  {	ylines = ylines + (10/xnum);
	grid.drawLine(ylines,0, ylines,460 ); 	
  }   
  //--------blue line dividers---------------------------- 
   grid.setPen(p4); 
    if(xnum==2)
  grid.drawLine(300, 0, 300, 460 ); 	

  if(xnum==5)
  {  grid.drawLine(120, 0, 120, 460 ); 
     grid.drawLine(241, 0, 241, 460 ); 
     grid.drawLine(361, 0, 361, 460 ); 
     grid.drawLine(482, 0, 482, 460 );
 }
}


//============================================================
// Load Graphics
//============================================================

//------Read_a_file()-----------------------------------------------------------------------------------------------
//
//PURPOSE - simply opens a load file dialog

void Form4::read_a_file()//--------------------------------------------------------------------------------------- 
{ //--- show open file dialog.--------------------------------------------------
  QString filename = QFileDialog::getOpenFileName(
	  QString::null, "Text (*.txt);;All| (*)", this,
	  "file open", "Open File" );
  if ( ! filename.isEmpty())
  {load( filename ); //------------call the function---------------------------
  pixmapTemp->repaint(1);
  textBrowser->clear(); 
  paintGrid(); 
  loadGraph();
  }
   else
  { loadLabel->setPaletteForegroundColor(Qt::red ) ;
    loadLabel->setText(QString( "Open file abandoned..."));
   }
}

//------ load( const QString& filename ) ----------------------------------------------------------------------------
//
//PURPOSE - loads the stored text files

void Form4::load( const QString& filename ) //-------------------------------------------------------------------
{  
  QFile file( filename );
  if ( file.open( IO_ReadOnly ) ) 
  { loadLabel->setPaletteForegroundColor(Qt::blue ) ;
    loadLabel->setText(QString( "File loaded...\n%1").arg( filename ));
	QTextStream stream( &file );
	QString line;
	while ( ! stream.eof() )
	{   line = stream.readLine();
	  textBrowser->append(line) ; //-----------------------displays on the textbrowser------------------
	  theLines += line;  //-----a QString which saves the text file
	}
	file.close();
  }
  else
  { loadLabel->setPaletteForegroundColor(Qt::red ) ;
    loadLabel->setText(QString( "File loaded Failed... %1").arg( filename ));  
    paintGrid();
   } 
}
//------ btFileLoad_clicked() ---------------------------------------------------------------------------------------
//
//PURPOSE - simply used by the load button
void Form4::btFileLoad_clicked() //-----------------------------------------------------------------------------
{   
  read_a_file() ;
}

//------ loadGraph() -----------------------------------------------------------------------------------------------
//
//PURPOSE - loads the stored text files

void Form4::loadGraph()//---------------------------------------------------------------------------------------
{
  int T1[60], T2[60], T3[60], L[60];  
  QString file; 
  QStringList theSections, thePoints;
  invalidLabel->hide();
  if(theLines[7].length()<7) //----------------checks to see if the file is invalid 
 {
  file = theLines.join(" ");//---------------------theLIne is a QString, file is one long string
  
  //---------splits up the points into ints----------------------------------------------------------
  theSections = QStringList::split("#", file); //-----------------breaks up the file in the 4 sections
  thePoints.clear();
  thePoints = QStringList::split(">", theSections[1]); //----looks at the lines in section1
  textBrowser->append("Current loaded graph:\n Temperature Sensor 1:  ");
  for (int n=0; n<60; n++) // ----------------------------------------converts all the strings in to integers
  {	T1[n] = atoi(thePoints[n +1]);
	textBrowser->append("value " + QString::number(n) +" = "+ QString::number(T1[n]));
  }
  //---------Displays in the Form---------------------------------------
  thePoints.clear();
  thePoints = QStringList::split(".", theSections[0]);
  
  //--------display the details of the file-------------------------------
  int prev_hour, prev_minute;
  prev_hour = atoi(thePoints[8]) - 1;
  prev_minute = atoi(thePoints[10]) -1;
 if(prev_hour ==-1)
   prev_hour = 23;
 if(prev_minute ==-1)
   prev_minute = 59;

  if(QString::compare( thePoints[0], "Minute_Output" ))//-------- QString::compare( thePoints[0], "Hour_Output" ) )
  {
	if(!QString::compare( thePoints[0], "Hour_Output" ))
	 {
	   fileLoaded->setPaletteForegroundColor(Qt::green) ;//-----Qcolor
	  fileLoaded->setText(QString(thePoints[0]) + ":           The Date:  "+ QString::number(atoi(thePoints[6]))+"/"+ QString::number(atoi(thePoints[4])) +"/"+ QString(thePoints[2])  +"\nStart Time: "+ QString::number(prev_hour) +":"+ QString::number(atoi(thePoints[10])) +"           Finished Time: "+ QString::number(atoi(thePoints[8])) +":"+ QString::number(atoi(thePoints[10]))); //-------------------display the location
	 }
	  else
	  {
	  fileLoaded->setPaletteForegroundColor(Qt::red) ;//-------Qcolor
	  fileLoaded->setText("INVALID FILE");
	  }
}
 else
 {   	if(!QString::compare( thePoints[0], "Minute_Output" ))
   fileLoaded->setPaletteForegroundColor(Qt::blue) ;//-----------Qcolor  
   fileLoaded->setText(QString(thePoints[0]) + ":   The Date: "+ QString::number(atoi(thePoints[6]))+"/"+ QString::number(atoi(thePoints[4])) +"/"+ QString(thePoints[2])  +"\nStart Time: "+ QString::number(atoi(thePoints[8])) +":"+ QString::number(prev_minute)+"    Finished Time: "+ QString::number(atoi(thePoints[8])) +":"+ QString::number(atoi(thePoints[10]))); //------------display the location
  }
 //-----------saves original file details--------------------------------------------
  if(cnt == 0 )
 { 
      if(!QString::compare( thePoints[0], "Minute_Output" ))
		start_time = ("The Original Start - Minute Ouput: \nDate: "+ QString::number(atoi(thePoints[6]))+"/"+ QString::number(atoi(thePoints[4])) +"/"+ QString(thePoints[2])  +"\nStart Time: "+ QString::number(atoi(thePoints[8])) +":"+ QString::number(prev_minute));
   
      if(!QString::compare( thePoints[0], "Hour_Output" ))
	start_time = ("Minute Ouput - The Original Start: \nDate: "+ QString::number(atoi(thePoints[6]))+"/"+ QString::number(atoi(thePoints[4])) +"/"+ QString(thePoints[2])  +"\nStart Time: "+QString::number(prev_hour) +":"+ QString::number(atoi(thePoints[10])));
   
 }
  if(cnt >0)
  { original_file_label->setPaletteForegroundColor(Qt::red) ;//-----Qcolor  
	original_file_label->setText(QString(start_time));
  }
  
  thePoints.clear(); 
  thePoints = QStringList::split(">", theSections[2]); 
  textBrowser->append("\nTemperature Sensor 2:\n");
  for (int n=0; n<60; n++) //------------------------------------converts all the strings in to integers
  {	T2[n] = atoi(thePoints[n +1]);
	textBrowser->append("value " + QString::number(n) +" ="+ QString::number(T2[n]));
  }  
  thePoints.clear();
  thePoints = QStringList::split(">", theSections[3]);  
  textBrowser->append("\nTemperature Sensor 3: \n");
  for (int n=0; n<60; n++) // ----------------------------------converts all the strings in to integers
  {	T3[n] = atoi(thePoints[n +1]);
	textBrowser->append("value " + QString::number(n) +" = "+ QString::number(T3[n]));
  }  
  thePoints.clear();
  thePoints = QStringList::split(">", theSections[4]); 
  textBrowser->append("\nLight Sensor: \n");
  for (int n=0; n<60; n++) // -----------------------------------converts all the strings in to integers
  {	L[n] = atoi(thePoints[n +1]);
	textBrowser->append("value " + QString::number(n) +" = "+ QString::number(L[n]));
  }  
  
  //-----------Draws the Points---------------------------------------------------------------------
  QPainter line( pixmapTemp );
  line.translate(30, 460);
  line.scale(1,-1);
    
  if(cnt < xnum) //-------prevents loading more than the grid can handle
 	{//----------------------this is the 4st buffered graph------------------------------
	if(cnt >3)
	{ pt = (600/xnum)*(cnt-4); 
	  for (int w = 1; w<59; w++) //---T1
	  {	pt = pt+(10/xnum);
		line.setPen(Qt::red);//------T1
		line.drawLine(pt, d1[w], (pt+(10/xnum)), d1[w+1] );
		line.setPen(Qt::blue);//----T2
		line.drawLine(pt, d2[w], (pt+(10/xnum)), d2[w+1] );
		line.setPen(Qt::green);//--T3
		line.drawLine(pt, d3[w], (pt+(10/xnum)), d3[w+1] );
		line.setPen(Qt::black);//----L
		line.drawLine(pt, d4[w], (pt+(10/xnum)),d4[w+1] );
	  }
	}	
  
//----------------------this is the 3st buffered graph------------------------------------
	if(cnt >2)
	{ pt = (600/xnum)*(cnt-3); 
	  for (int w = 1; w<59; w++) 
	  {	pt = pt+(10/xnum);
		line.setPen(Qt::red);//-----T1
		line.drawLine(pt, c1[w], (pt+(10/xnum)), c1[w+1] );
		line.setPen(Qt::blue);//---T2
		line.drawLine(pt, c2[w], (pt+(10/xnum)), c2[w+1] );
		line.setPen(Qt::green);//--T3
		line.drawLine(pt, c3[w], (pt+(10/xnum)), c3[w+1] );
		line.setPen(Qt::black);//---L
		line.drawLine(pt, c4[w], (pt+(10/xnum)),c4[w+1] );
	  }
	  for (int x=0; x<60; x++)
	  {
		d1[x] = c1[x];
		d2[x] = c2[x];
		d3[x] = c3[x];
		d4[x] = c4[x];
	  }	
	}	
  //----------------------this is the 2st buffered graph----------------------------------
	if(cnt >1)
	{ pt = (600/xnum)*(cnt-2); 
	  for (int w = 1; w<59; w++) //--T1
	  {	pt = pt+(10/xnum);
		line.setPen(Qt::red);//-----T1
		line.drawLine(pt, b1[w], (pt+(10/xnum)), b1[w+1] );
		line.setPen(Qt::blue);//----T2
		line.drawLine(pt, b2[w], (pt+(10/xnum)), b2[w+1] );
		line.setPen(Qt::green);//----T3
		line.drawLine(pt, b3[w], (pt+(10/xnum)), b3[w+1] );
		line.setPen(Qt::black);//-----L
		line.drawLine(pt, b4[w], (pt+(10/xnum)),b4[w+1] );
	  }
	  for (int x=0; x<60; x++)
	  {
		c1[x] = b1[x];
		c2[x] = b2[x];
		c3[x] = b3[x];
		c4[x] = b4[x];
	  }	
	}	
	 //----------------------this is the 1st buffered graph------------------------------
	if(cnt >0)
	{ pt = (600/xnum)*(cnt-1);
	  for (int w = 1; w<59; w++) //--T1
	  {	pt = pt+(10/xnum);
		line.setPen(Qt::red);//------T1
		line.drawLine(pt, a1[w], (pt+(10/xnum)), a1[w+1] );
		line.setPen(Qt::blue);//----T2
		line.drawLine(pt, a2[w], (pt+(10/xnum)), a2[w+1] );
		line.setPen(Qt::green);//---T3
		line.drawLine(pt, a3[w], (pt+(10/xnum)), a3[w+1] );
		line.setPen(Qt::black);//----L
		line.drawLine(pt, a4[w], (pt+(10/xnum)),a4[w+1] );
	  }
	  for (int x=0; x<60; x++)
	  {
		b1[x] = a1[x];
		b2[x] = a2[x];
		b3[x] = a3[x];
		b4[x] = a4[x];
	  }	
	} //-------------------------this is the new Drawn-----------------------------------
	pt = (600/xnum)*cnt;	
	for (int m = 1; m<59; m++) //---T1
	{	pt = pt+(10/xnum);
	  line.setPen(Qt::red);//-----------T1
	  line.drawLine(pt, T1[m], (pt+(10/xnum)), T1[m+1] );
	  line.setPen(Qt::blue);//---------T2
	  line.drawLine(pt, T2[m], (pt+(10/xnum)), T2[m+1] );
	  line.setPen(Qt::green);//-------T3
	  line.drawLine(pt, T3[m], (pt+(10/xnum)), T3[m+1] );
	  line.setPen(Qt::black);//--------L
	  line.drawLine(pt, L[m], (pt+(10/xnum)), L[m+1] );
	}
	cnt++;
	  for (int x=0; x<60; x++)
	  {
		a1[x] = T1[x];
		a2[x] = T2[x];
		a3[x] = T3[x];
		a4[x] = L[x];
	  }
   } 
  else
  {
  loadLabel->setPaletteForegroundColor(Qt::red ) ;
  loadLabel->setText(QString( "Unable to add anymore files"));

 //----------reset----------------------------------------------------------------
 theLines.clear();
 pt =0;
 cnt=0;
 original_file_label->clear();
 fileLoaded->clear();	 
 //pixmapTemp->repaint(1);
 textBrowser->clear(); 
 //paintGrid(); 
  
  }  

  //----------Calculate the Statistics-----------------------------------------
  for(int x=1; x<59; x++)
  {//----------Finds the average values-------------------------
  avgT1 = avgT1 +T1[x];
  avgT2 = avgT2 +T2[x];
  avgT3 = avgT3 +T3[x]; 
  avgL = avgL +L[x]; 
  //-----------Finds peak value-------------------
  if(T1[x] >thermo_peak) 
	 thermo_peak=T1[x];
  if(T2[x]>thermo_peak)
	thermo_peak = T2[x];
  if(T3[x]>thermo_peak)
	thermo_peak = T3[x];
   if(L[x]>light_peak)
	light_peak = L[x]; 
  //----------Finds trough value------------------
    if(T1[x] <thermo_trough)
	 thermo_trough=T1[x];
  if(T2[x]<thermo_trough)
	thermo_trough = T2[x];
  if(T3[x]<thermo_trough)
	thermo_trough = T3[x];
    if(L[x]<light_trough)
	light_trough = L[x];
  }

  peakLabel->setText("Max Thermo:  "+QString::number(thermo_peak/10)+"."+QString::number(thermo_peak%10));
  troughLabel->setText("Min Thermo:  "+QString::number(thermo_trough/10)+"."+QString::number(thermo_trough%10));  
   peakLightLabel->setText("Max Light:  "+QString::number(light_peak*9));
  troughLightLabel->setText("Min Light:  "+QString::number(light_trough*9));  
  
  LightLabel->setPaletteForegroundColor(Qt::black );
  LightLabel->setText("Light Level: "+QString::number( (avgL*3)/20));

  T1Label->setPaletteForegroundColor(Qt::red ) ;//-------------Thermo 1 average
  T1Label->setText("Thermo 1: "+QString::number( avgT1/600)+"."+QString::number( avgT1%600));

  T2Label->setPaletteForegroundColor(Qt::blue ) ;
  T2Label->setText("Thermo 2: "+QString::number( avgT2/600)+"."+QString::number( avgT2%600));

  T3Label->setPaletteForegroundColor(Qt::green ) ;
  T3Label->setText("Thermo 3: "+QString::number( avgT3/600)+"."+QString::number( avgT3%600));
} 
else
  { fileLoaded->setPaletteForegroundColor(Qt::red) ;//-------------Qcolor
	  fileLoaded->setText("   ");
	  invalidLabel->show();
  }
  theLines.clear();
  thePoints.clear();
  theSections.clear();
}


//============================================================
// Zoom grid
//============================================================

//------one_period(), two_periods, five_periods----------------------------------------------------------
//
//PURPOSE - This selects the number of loaded files on the graph

//--------Grid resized for 1 period---------------------------------
void Form4::one_period() 
{ 
pushButton1->setPaletteForegroundColor(Qt::red ) ;  
pushButton2->setPaletteForegroundColor(Qt::black ) ;  	
pushButton5->setPaletteForegroundColor(Qt::black ) ;  
xnum = 1;
reset();
}
//-----------Grid resized for 2 period------------------------------
void Form4::two_periods() 
{ 
pushButton1->setPaletteForegroundColor(Qt::black ) ;  
pushButton2->setPaletteForegroundColor(Qt::red ) ;  	
pushButton5->setPaletteForegroundColor(Qt::black ) ;  
xnum = 2;
reset();
}
//------------Grid resized for 5 period-----------------------------
void Form4::five_periods() 
{ 
pushButton1->setPaletteForegroundColor(Qt::black ) ;  
pushButton2->setPaletteForegroundColor(Qt::black ) ;  	
pushButton5->setPaletteForegroundColor(Qt::red) ;  
xnum = 5;
reset();
}


//------Reset()-----------------------------------------------------------------------------------------------
//
//PURPOSE - it reset the Graph and all the variable, label and buttons

void Form4::reset() //---------------------------------------------------------------------------------------
{ 
 theLines.clear();
 pt =0;
 cnt=0;
 avgT1 = 0;
 avgT2 = 0;
 avgT3 = 0;
 avgL = 0;
 thermo_peak =0;
 thermo_trough =400;
 light_peak =0;
 light_trough =400;
 start_time = " ";
 original_file_label->clear();
 fileLoaded->clear();	 
 loadLabel->clear();
 pixmapTemp->repaint(1);
 textBrowser->clear(); 
 invalidLabel->hide();
 
 peakLabel->setText("Max Thermo:" );
 troughLabel->setText("Min Thermo:  ");  
 peakLightLabel->setText("Max Light:  ");
 troughLightLabel->setText("Min Light:  ");  
 LightLabel->setText("Light Level: ");
 T1Label->setText("Thermo 1: ");
  T2Label->setText("Thermo 2: ");
  T3Label->setText("Thermo 3: ");
 
 paintGrid(); 
}


//------file_browser_bt()-----------------------------------------------------------------------------------------------
//
//PURPOSE - enable the file browser to be seen

void Form4::file_browser_bt() //-----------------------------------------
{

   if ( remember == 0 )
     {   textLabel->show();
	  textBrowser->show();
         remember = 1 ;
     } 	       
    else 
     {   textLabel->hide();
	  textBrowser->hide();
	remember = 0 ;
     } ;	
}

/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/

//============== constructor and destructor ====================================

void Form2::init()
{//--------- init the fan, light and heat status------------------------------------
  light1 = 1;		//D0 inverted
  light2 = 2;		//D1 inverted
  fan1 = 0;		//D2
  heat1 =0;		//D3
  fan2 = 0;		//D4
  heat2 = 0;		//D5
  fan3 = 0;		//D6
  heat3 = 0;		//D7
  
 //--------init the graphing variables.  ie. preferences, boundaries, calibration etc-----
  thermoPref = 30; 
  lower_boundary = 10;
  lightPref = 2250;
  calibrateValue = 0;
  graphing_flag = 1;
  
  for(int c=0; c<4; c++)
  {  DOUT_calb[c] = 0;
     DOUT_calb_results[c] = 0;
  }
  
  pt=0;
  cnt = 0;  
  pixmapTemp->repaint(1);
  paintGrid();
  minute=0;
  
  for (int n=0; n<60; n++)
  {	HLight[n] = 0;
	HTemp1[n]=0;
	HTemp2[n]=0;
	HTemp3[n]=0;
	theLight[n]=0;
	theTemp1[n]=0;
	theTemp2[n]=0;
	theTemp3[n]=0;
 }
  
  //---------init for other GUI components
  connected_label->hide();
  warning_label->hide();
  on_label->hide();
   my_LCD->hide();
   textBrowser->hide();
   hide = 0 ;
   
  //---------init the out byte for the parallel port
  port_num = 0;
  port_num_c = 3;   
   
 //--- my_timer starts running when the application first starts and keeps going
 //    even when the form is hidden.  It gives a periodic call to the target slot.
   my_timer = new QTimer(this);
   connect( my_timer, SIGNAL(timeout()), SLOT(handle_timer_event()) );  
}

void Form2::destroy()
{

}

//============================================================
// Deconstructs the ADC variables
//============================================================

//----------------- exit_state --------------------------------
//
//PURPOSE - When the exit auto form button is pressed
// 			it wil execute this function.

void Form2::exit_state()
{ ///---turn off all the fans and lights
  outb(0x01, lp_base_addr);		
  outb(0x03, lp_base_addr+2);
  //---stop ADC from running in the background
  if (my_timer->isActive() )
  { 	my_timer->stop() ;
	reset->setText("Resume Scanning") ;
  	scanning_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
	scanning_label->setText(QString( "Not Scanning. Graphing Stopped." ));
  }
}

//============================================================
// Graphical functions
//============================================================

//------paintGrid-----------------------------------------------------------------------------------------------
//
//PURPOSE - paints a grid on to the widgit 

void Form2::paintGrid()
{
  int xlines = 0; 
  int ylines = 0; 

  //---------Create QPainter grid--------------------		 
  QPainter grid( pixmapTemp );
  QPen p1(Qt::black, 0, Qt::SolidLine ) ;
  QPen p2(Qt::lightGray, 0, Qt::SolidLine ) ;
  QPen p3(Qt::red, 0, Qt::SolidLine );
  QPen p4(Qt::blue, 0, Qt::SolidLine);
  QPen thermo(Qt::red, 1, Qt::DashLine ) ;
  QPen lower(Qt::blue, 1, Qt::DashLine ) ;
  QPen lux(Qt::black, 1, Qt::DashLine ) ;
  QPen lux2(Qt::black, 1, Qt::DotLine ) ;
  //---- scaling--------
  grid.translate(30, 460);
  
  //-----------temperature scale---------------
  grid.setPen(p3); 
  grid.drawText(-25, 10, "(0,0)", -1) ;
  grid.drawText(-20, -47, "5", -1) ;
  grid.drawText(-20, -97, "10", -1) ;
  grid.drawText(-20, -147, "15", -1) ;
  grid.drawText(-20, -197, "20", -1) ;
  grid.drawText(-20, -247, "25", -1) ;
  grid.drawText(-20, -297, "30", -1) ;
  grid.drawText(-20, -347, "35", -1) ;
  grid.drawText(-20, -397, "40", -1) ;
  grid.drawText(-20, -447, "45", -1) ;
  //-------------LUX scale-------------------------
  grid.setPen(p1); 
  grid.drawText(607, -3, "0", -1) ;
  grid.drawText(607, -47, "450", -1) ;
  grid.drawText(607, -97, "900", -1) ;
  grid.drawText(607, -147, "1350", -1) ;
  grid.drawText(607, -197, "1800", -1) ;
  grid.drawText(607, -247, "2250", -1) ;
  grid.drawText(607, -297, "2700", -1) ;
  grid.drawText(607, -347, "3150", -1) ;
  grid.drawText(607, -397, "3600", -1) ;
  grid.drawText(607, -447, "4050", -1) ;

  //---------------time scale----------------------
  grid.setPen(p4); 
  grid.drawText(17, 15, "2", -1) ;
  grid.drawText(37, 15, "4", -1) ;
  grid.drawText(57, 15, "6", -1) ;
  grid.drawText(77, 15, "8", -1) ;
  grid.drawText(94, 15, "10", -1) ;
  grid.drawText(114, 15, "12", -1) ;
  grid.drawText(134, 15, "14", -1) ;
  grid.drawText(154, 15, "16", -1) ;
  grid.drawText(174, 15, "18", -1) ;
  grid.drawText(194, 15, "20", -1) ;
  grid.drawText(214, 15, "22", -1) ;
  grid.drawText(234, 15, "24", -1) ;
  grid.drawText(254, 15, "26", -1) ;
  grid.drawText(274, 15, "28", -1) ;
  grid.drawText(294, 15, "30", -1) ;
  grid.drawText(314, 15, "32", -1) ;
  grid.drawText(334, 15, "34", -1) ;
  grid.drawText(354, 15, "36", -1) ;
  grid.drawText(374, 15, "38", -1) ;
  grid.drawText(394, 15, "40", -1) ;
  grid.drawText(414, 15, "42", -1) ;
  grid.drawText(434, 15, "44", -1) ;
  grid.drawText(454, 15, "46", -1) ;
  grid.drawText(474, 15, "48", -1) ;
  grid.drawText(494, 15, "50", -1) ;
  grid.drawText(514, 15, "52", -1) ;
  grid.drawText(534, 15, "54", -1) ;
  grid.drawText(554, 15, "56", -1) ;
  grid.drawText(574, 15, "58", -1) ;
  grid.drawText(594, 15, "60", -1) ;
  //------------Coloured Labels------------------------------  
  grid.setPen(Qt::red);
  grid.drawText(-20, 40, "TempC Vs Time : ", -1) ;
  grid.setPen(Qt::red);
  grid.drawText(120, 40, "-- Temp 1 ", -1) ;
  grid.setPen(Qt::blue);
  grid.drawText(210, 40, "-- Temp 2 ", -1) ;
  grid.setPen(Qt::green);
  grid.drawText(300, 40, "-- Temp 3 ", -1) ;
  grid.setPen(Qt::black);
  grid.drawText(390, 40, ". . . Light ", -1) ;
    grid.setPen(Qt::black);
  grid.drawText(500, 40, "LUX Vs Time : ", -1) ;
  grid.scale(1,-1);
  
  grid.setPen( p1 );
  grid.drawRect( 0,0, 600,460 );
  grid.setPen( p2 );
  
  //---------------- x axises-----------------------
  for( int n=45; n >0; n--)
  {
	xlines = xlines + 10;  
	grid.drawLine( 0,xlines, 600,xlines ); 	
  }
  
  //-------------------- y axises----------------------
  for( int m=59; m >0; m--)
  {
	ylines = ylines + 10;
	grid.drawLine(ylines,0, ylines,460 ); 	
  }  
  //-----------the preferences lines------------------
   grid.setPen( thermo );
   grid.drawLine( -20,(thermoPref*10), 600,(thermoPref*10)); 	
   grid.setPen( lower );
   grid.drawLine( -20,(lower_boundary*10), 600,(lower_boundary*10)); 
  
   grid.setPen( lux2);   
   grid.drawLine( 0,(lightPref/10), 620,(lightPref/10)); 	   
   grid.setPen( lux);
   grid.drawLine( 0,(lightPref/10 - 60), 620,(lightPref/10 - 60)); 	
   
}

//------graphTemp-----------------------------------------------------------------------------------------------
//
//PURPOSE - paints the temperature lines onto the graph 

void Form2::graphTemp()
{ if (cnt == 0)
	paintGrid();
  //----------------Access the pixmapTemp--------------------------------------- 
  QPainter line( pixmapTemp );
  line.translate(40, 460);
  line.scale(1,-1);
  
  //-----------------the types of colours and lines used-----------------------
  QPen T1(Qt::red, 0, Qt::SolidLine ) ;//temp1
  QPen T2(Qt::blue, 0, Qt::SolidLine ) ;//temp2
  QPen T3(Qt::green, 0, Qt::SolidLine ) ;//temp3
  QPen L1(Qt::black, 0, Qt::DotLine ) ;// light
    
//------------------displays the inputs on the browser----------------------------  
  textBrowser->setText(QString( "Light sensor: '" ) + QString::number(DOUT_calb_results[0]/100) + QString(".") + QString::number(DOUT_calb_results[0]%100)  +"\n" + QString( "Temperature Sensor 1: '" ) + QString::number(DOUT_calb_results[1]/100) + QString(".") + QString::number(DOUT_calb_results[1]%100) +"\n" + QString( "Temperature Sensor 2: '" ) + QString::number(DOUT_calb_results[2]/100) + QString(".") + QString::number(DOUT_calb_results[2]%100)  +"\n" + QString( "Temperature Sensor 3: '" ) + QString::number(DOUT_calb_results[3]/100) + QString(".") + QString::number(DOUT_calb_results[3]%100)  +"\n" + QString( "cnt: '" ) + QString::number(cnt) +"\n" + QString( "point: '" ) + QString::number(pt));

  //---------------puts the input in to an array----------------------------------------
  if(cnt == 0) 
  {	theTemp1[0] = DOUT_calb_results[1]/10;
	theTemp1[1] = DOUT_calb_results[1]/10;
	theTemp2[0] = DOUT_calb_results[2]/10;
	theTemp2[1] = DOUT_calb_results[2]/10;
	theTemp3[0] = DOUT_calb_results[3]/10;
	theTemp3[1] = DOUT_calb_results[3]/10;	
	theLight[0] = DOUT_calb_results[0]/10;
	theLight[1] = DOUT_calb_results[0]/10;	
	cnt = cnt++;    
  }
  else
  {	cnt = cnt++;
	theTemp1[cnt] = DOUT_calb_results[1]/10;
	theTemp2[cnt] = DOUT_calb_results[2]/10; 
	theTemp3[cnt] = DOUT_calb_results[3]/10;	
	theLight[cnt] = DOUT_calb_results[0]/10;
  } 
  
 //------------------draws the lines-----------------------------------------------
  line.setPen( T1 );  
  line.drawLine(pt, theTemp1[cnt-1], (pt+10), theTemp1[cnt]); 
  line.setPen( T2 ); 
  line.drawLine(pt, theTemp2[cnt-1], (pt+10), theTemp2[cnt]); 
  line.setPen( T3 );  
  line.drawLine(pt, theTemp3[cnt-1], (pt+10), theTemp3[cnt]); 
  line.setPen( L1 ); 
  line.drawLine(pt, theLight[cnt-1], (pt+10), theLight[cnt] ); 
  pt = pt + 10;
  
//--------------Onces buffers have filled up,, LInes have reached end of graph, Repaint and SAVE----
  if(cnt>=60) 
  { 	pixmapTemp->repaint(1);
	paintGrid();
	cnt=0;
	pt = 0;
	//--------save the values------------------------------------------
	getHour();
	saveMinute();  
  }
}

//------file_browser_bt-----------------------------------------------------------------------------------------------
//
//PURPOSE - enable the file browser to be seen

void Form2::file_browser_bt() //-----------------------------------------
{
   if ( hide == 0 )
     {   my_LCD->show();
	  textBrowser->show();
         hide = 1 ;
	 output_details_but->setText("Hide Details");
     } 	       
    else 
     {   my_LCD->hide();
	  textBrowser->hide();
	  hide = 0 ;
	  output_details_but->setText("Show Details");
     } 	
}

//============================================================
// saving Graphics
//============================================================

//------saveMinute()-----------------------------------------------------------------------------------------------
//
//PURPOSE - saves the 4 int[60] buffers into a file 

void Form2::saveMinute()
{
  QStringList lines;
  QString fileName;
  QString Temp;//1, Temp2, Temp3, Light1;
  QTime time;
  QDate date;
  QString minutePath;
  time = QTime::currentTime();
  date = QDate::currentDate();
  
  //---------------------Creating the output file------------------------------------------------
  Temp.append(".Minute_Output.: -  Year:."  + intToString(date.year()) +". Month:."+ intToString(date.month()) +". Day:."+ intToString(date.day()) +". hour:."+ intToString(time.hour()) +". Minute:."+ intToString( time.minute()) + ".\n");
 
  Temp.append("#1 Minute Temperature Sensor 1 \n"); //------appends T1-------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(theTemp1[n]) + "\n");
  
  Temp.append("#2 Minute Temperature Sensor 2 \n"); //-----appends T2--------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(theTemp2[n]) + "\n"); 
  
  Temp.append("#3 Minute Temperature Sensor 3 \n"); //----appends T3--------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(theTemp3[n]) + "\n");
    
  Temp.append("#4 Minute Light Sensor 1 \n"); //---------------appends L1--------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(theLight[n]) + "\n");
  
  //------------places in the file -------------------------------------------
  lines << Temp;
  
fileName.append("M_"+ intToString(date.year()) +"_"+ intToString(date.month()) +"_"+ intToString(date.day()) +"_"+ intToString(time.hour()) +"_"+ intToString( time.minute()));

  minutePath = minuteLineEdit->text();
 //----------- Save the buffers--------------------------------------------
  QFile file( minutePath + "/" + fileName + ".txt" );
  if ( !file.open( IO_WriteOnly ) ) 
  {	minuteLabel->setPaletteForegroundColor(Qt::red ) ;
	minuteLabel->setText(QString::number(time.hour()) +":"+ QString::number(time.minute()) +QString( " Unable to Save, incorrect Minute Path: "));
  }
  else
  {	minuteLabel->setPaletteForegroundColor(Qt::blue );
	minuteLabel->setText(QString::number(time.hour()) +":"+ QString::number(time.minute()) +QString( " Minute saved to ..."));
	QTextStream stream( &file );
	for ( QStringList::Iterator it = lines.begin(); it != lines.end(); ++it )
	  stream << *it << "\n";
  }
  file.close();
}

//------------getHour()------------------------------------------------------------------------------------
//
//PURPOSE - gets the average of each minute and saves in to a buffer  

void Form2::getHour()
{
  //-------------the Total of theLight[]-----------------------------------------------------------
  if(minute>=60)
	minute = 0;
  int sum = 0;
  for(int x=0; x<60; x++)
    sum = sum + theLight[x]; 
  HLight[minute] = (sum/60);
  //-------------the Total of theTemp1[]--------------------------------------------------------
  sum=0;	  
  for(int x=0; x<60; x++)
    sum = sum + theTemp1[x]; 
  HTemp1[minute] = (sum/60);
  //-------------the Total of theLight[]------------------------------------------------------
  sum=0;	  
  for(int x=0; x<60; x++)
    sum = sum + theTemp2[x]; 
  HTemp2[minute] = (sum/60);  
  //-------------the Total of theLight[]------------------------------------------------------
  sum=0;	  
  for(int x=0; x<60; x++)
    sum = sum + theTemp3[x]; 
  HTemp3[minute] = (sum/60);  
   
    textBrowser->setText(QString( "<Minute = '" ) + QString::number(minute) +"\n" + QString( "HLight[minute] = '" ) + QString::number(HLight[minute]) + "\n" + QString( "HTemp1[minute] = '" ) + QString::number(HTemp1[minute])  +"\n" + QString( "HTemp2[minute] = '" ) + QString::number(HTemp2[minute]) +"\n" + QString( "HTemp3[minute] = '" ) + QString::number(HTemp3[minute]) +"\n" + QString( "theTemp3[4] = '" ) + QString::number(theTemp3[4]));
  
    minute++;
 if(minute==60)
  {  minute = 0;
     saveHour();
  }
}

//------saveHour()-----------------------------------------------------------------------------------------------
//
//PURPOSE - gets the minute buffers and gets the average, and saves the value in to a new hour buffer, it then creates a file called "hours" when the buffer has filled

void Form2::saveHour()
{

  QStringList lines;
  QString fileName;
  QString Temp;
  QTime time;
  QDate date;
  QString hourPath;
  time = QTime::currentTime();
  date = QDate::currentDate();
  
  //-----------Creating the output file-----------------------------------------------------------------
  Temp.append(".Hour_Output.: -  Year:."  + intToString(date.year()) +". Month:."+ intToString(date.month()) +". Day:."+ intToString(date.day()) +". hour:."+ intToString(time.hour()) +". Minute:."+ ".\n");
 
  Temp.append("#1 Hour Temperature Sensor 1 \n"); //---appends T1--------------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(HTemp1[n]) + "\n");
  
  Temp.append("#2 Hour Temperature Sensor 2 \n"); //---appends T2-------------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(HTemp2[n]) + "\n"); 
  
  Temp.append("#3 Hour Temperature Sensor 3 \n"); //---appends T3-------------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(HTemp3[n]) + "\n");
    
  Temp.append("#4 Hour Light Sensor 1 \n"); //--------------appends L1--------------
  for (int n=0; n<60; n++) 
  Temp.append(" >" + intToString(HLight[n]) + "\n");
  
  //-------------places in the file ------------------------------------------
  lines << Temp;
  
fileName.append("H_" + intToString(date.year()) +"_"+ intToString(date.month()) +"_"+ intToString(date.day()) +"_"+ intToString(time.hour()) +"_"+ intToString( time.minute()));

  hourPath = hourLineEdit->text();
 //-------------- Save the buffers-----------------------------------------
  QFile file( hourPath + "/" + fileName + ".txt" );
  if ( !file.open( IO_WriteOnly ) ) 
  {	hourLabel->setPaletteForegroundColor(Qt::red ) ;
	hourLabel->setText(QString::number(time.hour()) +":"+ QString::number(time.minute()) + QString( " Unable to Save, incorrect Hour Path"));
  }
  else
  {	hourLabel->setPaletteForegroundColor(Qt::blue );
	hourLabel->setText(QString::number(time.hour()) +":"+ QString::number(time.minute()) +QString(" Hour saved to ..."));
	QTextStream stream( &file );
	for ( QStringList::Iterator it = lines.begin(); it != lines.end(); ++it )
	  stream << *it << "\n";
  }
  file.close();
}

//--------quickSave()--------------------------------------------------------------------------------------------------
//
//PURPOSE - used to save Hour and Minute Buffers just before exited

void Form2::quickSave()
{
saveHour();
}

//------intToString()-----------------------------------------------------------------------------------------------
//
//PURPOSE - Convert integers in to Strings, and returns a QString

QString Form2::intToString(int x ) 
{ QString result;
  int num[4];
  num[0] = x/1000; //1000
  num[1] = ((x/100) - (num[0]*10));    //0100 
  num[2] = ((x/10) - (num[0]*100 ) - (num[1]*10)); //0010
  num[3] = x - ((num[2]*10) + (num[1]*100) + (num[0]*1000)); //0001
  for (int n=0; n<4; n++)
  {	if (num[n] == 1)
	  result.append("1");	
	if (num[n] == 2)
	  result.append("2");    
	if (num[n] == 3)
	  result.append("3");	
	if (num[n] == 4)
	  result.append("4");
	if (num[n] == 5)
	  result.append("5");	
	if (num[n] == 6)
	  result.append("6");
	if (num[n] == 7)
	  result.append("7");	
	if (num[n] == 8)
	  result.append("8");    
	if (num[n] == 9)
	  result.append("9");	
	if (num[n] == 0)
	  result.append("0");	   
  }  
  return result;
}

//============================================================
//Preferences for Temperature and Light
//============================================================

//------set preferences-----------------------------------------------------------------------------------------------
//
//PURPOSE - to set and display the thermo and Light preferences

void Form2::setPreferences()
{ 
  //--saves the Preferences as integers--------------------------
  thermoPref = (dialThermo->value())*0.45;//----------------upper boundary--------------
  lower_boundary = (dialLowerThermo->value()*0.45);//-------lower_boundary--------
  lightPref = (dialLux->value()*40);
  
  if (thermoPref <= (lower_boundary+1))
     thermoPref = (lower_boundary+1);
  if (lower_boundary >= (thermoPref-1))
	lower_boundary = (thermoPref-1);
 
  LCDThermo->display(thermoPref); //----------------displays on LCDs-----------
  LCDLowerThermo->display(lower_boundary);   
  LCDLux->display(lightPref);
  
//----------draws the preferences-----------------------------------------------------------------
   pixmapTemp->repaint(1);
   paintGrid();
}

//-----------check pref()-----------------------------------------------------------------------
//
//PURPOSE - to read the current state of the light and thermo sensors 

void Form2::check_pref()
{//--------upper boundary for light------------------------
  if(lightPref > DOUT_calb_results[0])
	light1 = 0;
  else
	light1 = 1;
 //--------lower boundary for light-------------------------  
  if(lightPref > (DOUT_calb_results[0] + 600))
  	light2 = 0;
  else
  	light2 = 2;
  //-------upper boundary for thermo sensor 1------------  
  if(thermoPref*100 < DOUT_calb_results[1])
  	fan1 = 4;
  else
	fan1 = 0;
    
  //------lower boundary for thermo sensor 1------------  
  if(lower_boundary*100 > DOUT_calb_results[1])
  	heat1 = 8;
  else
	heat1 = 0;
  //------upper boundary for thermo sensor 2------------  
  if(thermoPref*100 < DOUT_calb_results[2])
  	fan2 = 16;
  else
	fan2 = 0;
    
  //------lower boundary for thermo sensor 2------------  
  if(lower_boundary*100 > DOUT_calb_results[2])
  	heat2 = 32;
  else
	heat2 = 0;  
  //------upper boundary for thermo sensor 3------------  
  if(thermoPref*100 < DOUT_calb_results[3])
  	fan3 = 64;
  else
	fan3 = 0;
    
  //------lower boundary for thermo sensor 3------------  
  if(lower_boundary*100 > DOUT_calb_results[3])
  	heat3 = 128;
  else
	heat3 = 0;
}

//============================================================
//Reading ADC and controlling hardware and calibration
//============================================================

//------get_current_states--------------------------------------------------------------------------------------
//
//PURPOSE - to read the current state of the light and thermo sensors 

void Form2::get_current_states()
{//------------should be running in the background so don't really need this--------
  run_ADC();	
  //-----------adjust the raw ADC readings to the chosen calibration levels------------------
  DOUT_calb_results[0] = DOUT_results[0];
  DOUT_calb_results[1] = DOUT_results[1] + DOUT_calb[1];
  DOUT_calb_results[2] = DOUT_results[2] + DOUT_calb[2];
  DOUT_calb_results[3] = DOUT_results[3] + DOUT_calb[3];
  //-----------check h/w connected status----------------------------------------------------------------
  if(DOUT_results[1] == 0 && DOUT_results[2] == 0 && DOUT_results[3] == 0 ||
	 DOUT_results[1] == 4095 && DOUT_results[2] == 4095 && DOUT_results[3] == 4095)
  {
	if(DOUT_results[1] == 4095 && DOUT_results[2] == 4095 && DOUT_results[3] == 4095)
	{	
	  connected_label->show();
	  warning_label->show();
	  scanning_label->setPaletteForegroundColor(Qt::red) ;//-----Qcolor------------------
	  scanning_label->setText(QString( "Not scanning. Graphing Stopped" ));	  
	  graphing_flag = 0;
	}
  
	if(DOUT_results[1] == 0 && DOUT_results[2] == 0 && DOUT_results[3] == 0)
	{
	  on_label->show();
	  warning_label->show();
	  scanning_label->setPaletteForegroundColor(Qt::red) ;//--------Qcolor----------------
	  scanning_label->setText(QString( "Not Scanning. Graphing Stopped" ));	  
	  graphing_flag = 0;
	}
  }
  else
  {
	connected_label->hide();    
	warning_label->hide();
	on_label->hide();  
	scanning_label->setPaletteForegroundColor(Qt::green) ;//---------Qcolor--------------
	scanning_label->setText(QString( "Scanning. Graphing Results." ));
	graphing_flag = 1;	//-------------enable the graph to be drawn-----------------------------
  }

  //------compare the actual heat and light readings to the preference heat and light level----
  check_pref();
  //------activate appropiate fans or light depending on check_pref()
  set_states();
  //------display graphicially the heat and light readings and the preference levels-----------
  if (graphing_flag == 1)
  graphTemp();
}

//------set_states-----------------------------------------------------------------------------------------------
//
//PURPOSE - to read the states of light, fan1 and fan2 (set by the toogle function)
//	       and set the actual hardware to corresponding state.

void Form2::set_states()
{
  port_num = heat1+fan2+heat2+fan3+heat3;
  port_num_c = light1+light2+fan1;
  
  outb(port_num, lp_base_addr);
  outb(port_num_c, lp_base_addr+2);
  
  //----set the label for light1 status-------------------------------
  if(light1 != 0)
	light1_label->setPaletteForegroundColor(Qt::red);
  else
	light1_label->setPaletteForegroundColor(Qt::green);
  //----set the label for light2 status-------------------------------
  if(light2 != 0)
	light2_label->setPaletteForegroundColor(Qt::red);
  else
	light2_label->setPaletteForegroundColor(Qt::green);  
  //----set the label for fan1 status-------------------------------
  if(fan1 != 0)
	fan1_label->setPaletteForegroundColor(Qt::green);
  else
	fan1_label->setPaletteForegroundColor(Qt::red);    
  //----set the label for heat1 status-------------------------------
  if(heat1 != 0)
	heat1_label->setPaletteForegroundColor(Qt::green);
  else
	heat1_label->setPaletteForegroundColor(Qt::red); 
  //----set the label for fan2 status-------------------------------
  if(fan2 != 0)
	fan2_label->setPaletteForegroundColor(Qt::green);
  else
	fan2_label->setPaletteForegroundColor(Qt::red);    
  //----set the label for heat2 status-------------------------------
  if(heat2 != 0)
	heat2_label->setPaletteForegroundColor(Qt::green);
  else
	heat2_label->setPaletteForegroundColor(Qt::red);   
  //----set the label for fan3 status-------------------------------
  if(fan3 != 0)
	fan3_label->setPaletteForegroundColor(Qt::green);
  else
	fan3_label->setPaletteForegroundColor(Qt::red);    
  //----set the label for heat1 status-------------------------------
  if(heat3 != 0)
	heat3_label->setPaletteForegroundColor(Qt::green);
  else
	heat3_label->setPaletteForegroundColor(Qt::red);   
}

//------calibrate_readings-----------------------------------------------------------------------------------------------
//
//PURPOSE - to take the input from the user and calibrate the sensor according to the 
//---------input number--------------------------------------

void Form2::calibrate_readings()
{ QString value;
  //----------get reading from a box------------------------------
  calibrateValue = atoi(calibrate_input1->text())*100 + atoi(calibrate_input2->text());
  
  if(calibrateValue > 0 && calibrateValue < 4501)
  {
	DOUT_calb[1] = calibrateValue - DOUT_results[1];
	DOUT_calb[2] = calibrateValue - DOUT_results[2];
	DOUT_calb[3] = calibrateValue - DOUT_results[3];
	calibrate_label->setPaletteForegroundColor(Qt::blue) ;//----Qcolor------------------
	calibrate_label->setText(QString("calibrated at ") + (QString(calibrate_input1->text())) + 
						 (QString(".")) + (QString(calibrate_input2->text()))+
						 (QString(" *C")));
  }
  else
  {	calibrate_label->setPaletteForegroundColor(Qt::red) ;
	calibrate_label->setText(QString("INVALID VALUE ")); 

  }
}

//============================================================
// Timer functions
//============================================================

//----------------- handle_timer_event --------------------------------
//
//PURPOSE - This slot gets called whenever the my_timer clicks over.
//-------------------This will to continuously run get_current_state every second
//-------------------the result found will be graphed on the GUI.

void Form2::handle_timer_event()
{
  my_LCD->display( my_LCD->intValue() + 1) ;
  get_current_states();
}

//----------------- start_button_clicked --------------------------------
//
//PURPOSE - This slot gets called whenever the my_timer clicks over.
//-------------------Increment the LCD display for each timer click.

void Form2::start_button_clicked()
{  
  if (my_timer->isActive() )
  { 	my_timer->stop() ;
	reset->setText("Resume Scanning") ;
  	scanning_label->setPaletteForegroundColor(Qt::red) ;//-----Qcolor-------
	scanning_label->setText(QString( "Not Scanning. Graphing Stopped" ));	
  }
  else 
  {	my_timer->start(1000) ;
       reset->setText("Stop Scanning") ;
  	scanning_label->setPaletteForegroundColor(Qt::green) ;//----Qcolor--------
	scanning_label->setText(QString( "Scanning. Graphing Results." ));
	paintGrid();
  }    
}


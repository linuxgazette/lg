//====================ADCdriver.h======================================
#ifndef ADCDRIVER_H
#define ADCDRIVER_H

//==================== PUBLIC FUNCTIONS ==========================
void run_ADC(); 

//================== PUBLIC/EXTERNAL data ========================
#ifndef ADCDRIVER_C
#define PD_PREFIX extern
#else
#define PD_PREFIX
#endif

PD_PREFIX int count;
PD_PREFIX int DOUT_results[4];
PD_PREFIX short lp_base_addr;

#endif

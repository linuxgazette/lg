//================ADCdriver.c================================
#define ADCDRIVER_C
#include "ADCdriver.h"

#include <stdio.h>
#include <unistd.h>
#include <asm/io.h>
#include <time.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <math.h>                                                    

//--------TEST outputs
#define SHOW_DELAY_TIMES if(0)
#define VIEW_SCLK if(0)
#define VIEW_DIN if(0)
#define VIEW_OUTPUT if(0)


//------- Parallel port data.
short lp_base_addr ; // save base addr of pp port.
#define status_offset  1
#define control_offset 2
#define high 1
#define low  0

static char save_data ;    // save of original values.
static char save_control ;
static char image_data ;   // use image as master record of port.
static char image_control ;
int count;
int counter1;
//-------Parallel port pins-------------------------
#define CS1         0x02
#define SCLK1       0x01
#define SCLK1_CS1   0x03
#define DIN1        0x04
#define DIN1_SCLK1  0x05
#define DIN1_SCLK1_CS1 0x07  
#define all_low     0x00

int thermo1_DIN[8];// = {1,0,0,0,1,0,1,0};
int thermo2_DIN[8];// = {1,0,0,1,1,0,1,0};
int thermo3_DIN[8]; //= {1,0,1,0,1,0,1,0};
int light_DIN[8];// =   {1,0,1,1,1,0,1,0};

int DOUT_results[4];

//=================== pp routines ================================

//-------- lp_init() --------------------------------------------
//
// PURPOSE - given lp number 0-2, get lp base address,
//           save registers, disable interrupts.

void lp_init(short lp_num)
 { switch ( lp_num)
    { case 2 : lp_base_addr = 0x3BC ; break ;
      case 1 : lp_base_addr = 0x278 ; break ;
      default: lp_base_addr = 0x378 ; break ;
    }
   image_data    = save_data    = inb( lp_base_addr) ;
   image_control = save_control = inb( lp_base_addr+2) ;
   outb( (image_control &= 0xEF),  lp_base_addr + control_offset) ;
 }

//--------- lp_restore() ----------------------------------------
//
// PURPOSE - restore lp port to previous state.

void lp_restore()
{  outb( save_data,    lp_base_addr) ;
   outb( save_control, lp_base_addr + control_offset) ;
}

//---------check SSTRB pin------------------------------
//PURPOSE - check the SSTRB pin (pin 10 or S6) 

int check_SSTRB_pin()
{
  if ( inb( lp_base_addr+status_offset) & 0x40)
    return(high);
  else return(low);   
}

//---------check DOUT pin------------------------------
//PURPOSE - check the SSTRB pin (pin 11 or S7)

int check_DOUT_pin()
{
  if ( inb( lp_base_addr+status_offset) & 0x80)
    return(low);
  else return(high);
}

//---------two power of-----------------------------
//PURPOSE - to output two to the power of (x) - 2^x

int twopowerof(int x)
{
  int tempPow = 0;
  int value = 1;
    while(x>tempPow)
    {
      value = 2*value;
      tempPow++;
    }
  return(value);
}
           
//---------Clock in 8bits------------------------------
//PURPOSE - clock in the 8 bit command into the ADC.*/
 
void clock_in_8bits(int buffDIN[8])
{  
  for(count=1; count<=8; count++)
  {
    //---falling edge-------------------------
    if(buffDIN[count] == 1) 
      {outb(DIN1, lp_base_addr);         //SCLK-low, DIN-high
       VIEW_DIN printf("-");
      }
    else
      {outb(all_low, lp_base_addr);        //SCLK-low, DIN-low
       VIEW_DIN printf("_");
      }

    //printf("DOUT(%d), SSTRB(%d), count(%d) - just before rising edge \n", check_DOUT_pin(), check_SSTRB_pin(), count);

    VIEW_SCLK printf("_");

    //---rising edge---------------------------
    if(buffDIN[count] == 1)
      {if(count == 8)
        outb(DIN1_SCLK1_CS1, lp_base_addr);   
       else
        outb(DIN1_SCLK1, lp_base_addr);   //SCLK-high, DIN-high
       VIEW_DIN printf("-");
      }
    else
      {if(count == 8)
        outb(SCLK1_CS1, lp_base_addr);   
       else
        outb(SCLK1, lp_base_addr);        //SCLK-high, DIN-low
       VIEW_DIN printf("_");
      }
    VIEW_SCLK printf("%d",count);
  }

  outb(CS1, lp_base_addr);   //last falling edge so CS goes high
  VIEW_OUTPUT printf("\n**starting tconv**\nDOUT(%d), SSTRB(%d) - SSTRB should go low\n", check_DOUT_pin(), check_SSTRB_pin());
  VIEW_OUTPUT printf("DOUT(%d), SSTRB(%d)\n", check_DOUT_pin(), check_SSTRB_pin());

  VIEW_SCLK printf("_|\n");
}

//---------Clock out signal-----------------------------
//PURPOSE - once tconv is finished clock out the 12 bit
//          signal from ADC

int clock_out_signal()
{
  int tempOut[12] = {0,0,0,0,0,0,0,0,0,0,0,0};

  for(count=1; count<=14; count++)
  {
    //-----begin clocking out out byte----
    outb(0, lp_base_addr);  //force pin2 SCLK to low
    VIEW_SCLK printf("_");

    //----rising edge------
    //-----check for zero start bit to see if hardware is plugged in-----
    if(count == 1 && check_DOUT_pin() != 0)
    { //printf("DOUT error: MSB not equal to 0.  ADC probably not connected or a hardware problem\n");
      //exit(1);
    }
    if(count>=2 && count<=13)
    {
      if(check_DOUT_pin() == high)
      tempOut[count-2] = 1;
      else
      tempOut[count-2] = 0;
    
    }                               
    
    VIEW_OUTPUT printf("DOUT(%d), SSTRB(%d), count(%d) - rising edge\n", check_DOUT_pin(), check_SSTRB_pin(), count);
    outb(SCLK1, lp_base_addr); //force pin2 SCLK to high
   
    //check_SSTRB_pin();   
    VIEW_SCLK printf("%d",count);
  }
  outb(0, lp_base_addr);   //force pin2 SCLK to low
  VIEW_SCLK printf("_\n");
  VIEW_OUTPUT printf("output: %d%d%d%d%d%d%d%d%d%d%d%d \n", tempOut[0], tempOut[1], tempOut[2], tempOut[3], tempOut[4]
  , tempOut[5], tempOut[6], tempOut[7], tempOut[8], tempOut[9], tempOut[10], tempOut[11]);

  int dec = 0;
  for(count=0; count<=11; count++)
  {
   // printf("%d\n", tempOut[count]);
    dec = ((tempOut[11-count])*(twopowerof(count)))+dec;
    VIEW_OUTPUT printf("tempOut: %d count: %d\n", tempOut[count], count);
  }
  
  VIEW_OUTPUT printf("DOUT_result: %d\n", dec);
  return(dec);
}

//---------get light sensor reading-----------------------------
//PURPOSE - to clock in light sensor config and then clock out
//          the light sensor reading as a integer.

void get_light_sensor_reading()
{   //--- begin clocking in 8 bit command/
    outb(CS1, lp_base_addr); //force CS (D2) high rest of the pins are low
    VIEW_OUTPUT printf("\n********************************************\n");

    //---starting 8-bit command---
    outb(all_low, lp_base_addr);  //make all pins low


    outb(DIN1, lp_base_addr); //input DIN START(high) bit

    //---input thermo3 sensor---
    VIEW_OUTPUT printf("**light Sensor Active**\n");
    VIEW_OUTPUT printf("DOUT(%d), SSTRB(%d) - start bit entered\n", check_DOUT_pin(), check_SSTRB_pin());

    clock_in_8bits(light_DIN);         //clocking in the 8 bit command

    VIEW_OUTPUT printf("**tconv finished**\n");
    VIEW_OUTPUT printf("**clock in data back in**\n");

    DOUT_results[0] = clock_out_signal();     //clocking out 12 bit signal from ADC
}

//---------get 1st thermistor sensor reading-----------------------
//PURPOSE - to clock in thermistor sensor config and then clock out
//          the thermistor sensor reading as a integer.

void get_thermo1_sensor_reading()
{   //--- begin clocking in 8 bit command/
    outb(CS1, lp_base_addr); //force CS (D2) high rest of the pins are low
    VIEW_OUTPUT printf("\n********************************************\n");

    //---starting 8-bit command---
    outb(all_low, lp_base_addr);  //make all pins low


    outb(DIN1, lp_base_addr); //input DIN START(high) bit

    //---input thermo3 sensor---
    VIEW_OUTPUT printf("**Thermo1 Sensor Active**\n");
    VIEW_OUTPUT printf("DOUT(%d), SSTRB(%d) - start bit entered\n", check_DOUT_pin(), check_SSTRB_pin());

    clock_in_8bits(thermo1_DIN);         //clocking in the 8 bit command

    VIEW_OUTPUT printf("**tconv finished**\n");
    VIEW_OUTPUT printf("**clock in data back in**\n");

    DOUT_results[1] = clock_out_signal();     //clocking out 12 bit signal from ADC
}

//---------get 2nd thermistor sensor reading-----------------------
//PURPOSE - to clock in thermistor sensor config and then clock out
//          the thermistor sensor reading as a integer.

void get_thermo2_sensor_reading()
{   //--- begin clocking in 8 bit command/
    outb(CS1, lp_base_addr); //force CS (D2) high rest of the pins are low
    VIEW_OUTPUT printf("\n********************************************\n");

    //---starting 8-bit command---
    outb(all_low, lp_base_addr);  //make all pins low


    outb(DIN1, lp_base_addr); //input DIN START(high) bit

    //---input thermo3 sensor---
    VIEW_OUTPUT printf("**Thermo2 Sensor Active**\n");
    VIEW_OUTPUT printf("DOUT(%d), SSTRB(%d) - start bit entered\n", check_DOUT_pin(), check_SSTRB_pin());

    clock_in_8bits(thermo2_DIN);         //clocking in the 8 bit command

    VIEW_OUTPUT printf("**tconv finished**\n");
    VIEW_OUTPUT printf("**clock in data back in**\n");

    DOUT_results[2] = clock_out_signal();     //clocking out 12 bit signal from ADC
}
 //---------get 3rd thermistor sensor reading-----------------------
//PURPOSE - to clock in thermistor sensor config and then clock out
//          the thermistor sensor reading as a integer.

void get_thermo3_sensor_reading()
{   //--- begin clocking in 8 bit command/
    outb(CS1, lp_base_addr); //force CS (D2) high rest of the pins are low
    VIEW_OUTPUT printf("\n********************************************\n");
    
    //---starting 8-bit command---
    outb(all_low, lp_base_addr);  //make all pins low

        
    outb(DIN1, lp_base_addr); //input DIN START(high) bit
    
    //---input thermo3 sensor---
    VIEW_OUTPUT printf("**Thermo3 Sensor Active**\n");
    VIEW_OUTPUT printf("DOUT(%d), SSTRB(%d) - start bit entered\n", check_DOUT_pin(), check_SSTRB_pin());

    clock_in_8bits(thermo3_DIN);         //clocking in the 8 bit command

    VIEW_OUTPUT printf("**tconv finished**\n");
    VIEW_OUTPUT printf("**clock in data back in**\n");

    DOUT_results[3] = clock_out_signal();     //clocking out 12 bit signal from ADC
}

//---------DIN init-----------------------------
//PURPOSE - initialise the DIN_config variables for
//          light, thermo1, thermo2, thermo3

void DIN_init()
{
    thermo1_DIN[1] = 1;
    thermo1_DIN[2] = 0;  //SEL2
    thermo1_DIN[3] = 0;  //SEL1
    thermo1_DIN[4] = 0;  //SEL0
    thermo1_DIN[5] = 1;
    thermo1_DIN[6] = 0;
    thermo1_DIN[7] = 1;
    thermo1_DIN[8] = 0;

    thermo2_DIN[1] = 1;
    thermo2_DIN[2] = 0;  //SEL2
    thermo2_DIN[3] = 0;  //SEL1
    thermo2_DIN[4] = 1;  //SEL0
    thermo2_DIN[5] = 1;
    thermo2_DIN[6] = 0;
    thermo2_DIN[7] = 1;
    thermo2_DIN[8] = 0;

    thermo3_DIN[1] = 1;
    thermo3_DIN[2] = 0;  //SEL2
    thermo3_DIN[3] = 1;  //SEL1
    thermo3_DIN[4] = 0;  //SEL0
    thermo3_DIN[5] = 1;
    thermo3_DIN[6] = 0;
    thermo3_DIN[7] = 1;
    thermo3_DIN[8] = 0;

    light_DIN[1] =   1;
    light_DIN[2] =   0;  //SEL2
    light_DIN[3] =   1;  //SEL1
    light_DIN[4] =   1;  //SEL0
    light_DIN[5] =   1;
    light_DIN[6] =   0;
    light_DIN[7] =   1;
    light_DIN[8] =   0;
}

            
//========== main ===============================================
void run_ADC()
{ //====== inits.
    lp_init(0);
    DIN_init();      
  //--- initialize primary time interval PTI timer.
    struct timespec sleep_time ;
    sleep_time.tv_sec = 0 ;
    sleep_time.tv_nsec = 0 ; // 10 ms PTI.

  //--- get the reading from the sensors---
   // while(1)
    //{
      get_light_sensor_reading();
      get_thermo1_sensor_reading();
      get_thermo2_sensor_reading();
      get_thermo3_sensor_reading();

    //  printf("light: %d | thermo1: %d | thermo2: %d | thermo3: %d \n",DOUT[0],
     // DOUT[1], DOUT[2], DOUT[3]);
     //sleep(1);         
    //}
    //---need to output results to the GUI--
                                                      
    lp_restore();
    count = 98;
    

  //  counter1++;
  //  DOUT_results[0] = counter1;
}
/*
void run_ADC()
{ //====== inits.
   DIN_init();
    count = 96;                                            
}*/

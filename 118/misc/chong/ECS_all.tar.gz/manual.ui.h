/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/

//============== constructor and destructor ====================================

void Form3::init()
{ //---init all the status so that hw is off------  
  light1_status = 1;	//D0
    light2_status = 2;	//D1
    fan1_status = 0;		//D2
    heat1_status =0;	//D3
    fan2_status = 0;		//D4
    heat2_status = 0;	//D5
    fan3_status = 0;		//D6
    heat3_status = 0;	//D7
    //---init all schedule flags so that nothing is scheduled------
    for(int c=0; c<4; c++)
    {	   schedule_flag[c]= 0;   
    }
    //---define the two outbyte(status and control) for pport-----
    out_byte = 0;
    out_byte_c =3;
    run_ADC();			//need this to initialise the lp_init
    outb(0x00, lp_base_addr);		//turn off all fans and lights
 
	
    //---init all the gui---------
    connected_label->hide();
    on_label->hide();
    warning_label->hide();    
    light1_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    light1_label->setText(QString( "light1 is off" ));
    light2_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    light2_label->setText(QString( "light1 is off" ));
    fan1_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    fan1_label->setText(QString( "Fan 1 is off " ));
    heat1_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    heat1_label->setText(QString( "Heat 1 is off " ));
    fan2_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    fan2_label->setText(QString( "Fan 2 is off " ));
    heat2_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    heat2_label->setText(QString( "Heat 2 is off " ));
    fan3_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    fan3_label->setText(QString( "Fan 3 is off " ));
    heat3_label->setPaletteForegroundColor(Qt::red) ;//Qcolor
    heat3_label->setText(QString( "Heat 3 is off " ));
 
  //------ my_timer starts running when the application first starts and keeps going
  // ------even when the form is hidden.  It gives a periodic call to the target slot.
   my_timer = new QTimer(this);
   connect( my_timer, SIGNAL(timeout()), SLOT(handle_timer_event()) ); 
   my_timer->start(1000) ;
}

void Form3::destroy()
{//-------- code to execute when form closed but before visual components are destroyed.------
}

void Form3::exit_state()
{
    light1_status = 1;//------D0
    light2_status = 2;//------D1
    fan1_status = 0;	//-------D2
    heat1_status =0;//------D3
    fan2_status = 0;	//------D4
    heat2_status = 0;//----D5
    fan3_status = 0;	//-----D6
    heat3_status = 0;//---D7
    
    set_states();   
    for(int c=0; c<3; c++)
    {
	  schedule_flag[c] = 0;   
    }	
	
    light_schedule_label->setPaletteForegroundColor(Qt::black) ;
    light_schedule_label->setText(QString("Nothing is scheluded"));
    schedule_light1_but->setText("Schedule one Light"); 
    schedule_light2_but->setText("Schedule both Lights"); 
	
    set1_schedule_label->setPaletteForegroundColor(Qt::black) ;
    set1_schedule_label->setText(QString("Nothing is scheluded"));
    schedule_heat1_but->setText("Schedule Heat 1 toogle"); 
    schedule_fan1_but->setText("Schedule Fan 1 toogle"); 

	
    set2_schedule_label->setPaletteForegroundColor(Qt::black) ;
    set2_schedule_label->setText(QString("Nothing is scheluded"));
    schedule_heat2_but->setText("Schedule Heat 2 toogle"); 
    schedule_fan2_but->setText("Schedule Fan 2 toogle"); 

    set3_schedule_label->setPaletteForegroundColor(Qt::black) ;
    set3_schedule_label->setText(QString("Nothing is scheluded"));
    schedule_heat3_but->setText("Schedule Heat 3 toogle"); 
    schedule_fan3_but->setText("Schedule Fan 3 toogle"); 	
}

//============================================================
// Controls the fans and lights 
//============================================================

//------toogle_light1-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the light status to off or on

void Form3::toogle_light1()
{    if(light1_status != 0)
	light1_status = 0;
    else
	light1_status = 1;
    set_states();
}

//------toogle_light2-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the light status to off or on

void Form3::toogle_light2()
{    if(light2_status != 0)
	light2_status = 0;
    else
	light2_status = 2;
    set_states();
}

//------toogle_fan1-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the fan1 status to off or on

void Form3::toogle_fan1()
{    if(fan1_status == 0)
	fan1_status = 4;
    else
	fan1_status = 0;
    set_states();
}

//------toogle_heat1----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the fan1 status to off or on

void Form3::toogle_heat1()
{    if(heat1_status == 0)
	heat1_status = 8;
    else
	heat1_status = 0;
    set_states();
}

//------toogle_fan2-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the fan2 status to off or on

void Form3::toogle_fan2()
{    if(fan2_status == 0)
	fan2_status = 16;
    else
	fan2_status = 0;
    set_states();
}

//------toogle_heat2-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the fan1 status to off or on

void Form3::toogle_heat2()
{    if(heat2_status == 0)
	heat2_status = 32;
    else
	heat2_status = 0;
    set_states();
}

//------toogle_fan3-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the fan2 status to off or on

void Form3::toogle_fan3()
{    if(fan3_status == 0)
	fan3_status = 64;
    else
	fan3_status = 0;
    set_states();
}

//------toogle_heat3-----------------------------------------------------------------------------------------------
//
//PURPOSE - to toogle the fan1 status to off or on

void Form3::toogle_heat3()
{    if(heat3_status == 0)
	heat3_status = 128;
    else
	heat3_status = 0;
    set_states();
}

//------set_states-----------------------------------------------------------------------------------------------
//
//PURPOSE - to read the states of light, fan1 and fan2 (set by the toogle function)
//	       and set the actual hardware to corresponding state.

void Form3::set_states()
{
  out_byte = heat1_status+fan2_status+heat2_status+fan3_status+heat3_status;
  out_byte_c = light1_status+light2_status+fan1_status;
  
  outb(out_byte, lp_base_addr);
  outb(out_byte_c, lp_base_addr+2);
  
  if(light1_status == 0)
  {	light1_label->setPaletteForegroundColor(Qt::green) ;//-----Qcolor
	light1_label->setText(QString( "Light1 is on " ));
  }
  else
  {	light1_label->setPaletteForegroundColor(Qt::red) ;//--------Qcolor
	light1_label->setText(QString( "Light1 is off " ));
  }
  
    if(light2_status == 0)
  {	light2_label->setPaletteForegroundColor(Qt::green) ;//-----Qcolor
	light2_label->setText(QString( "Light1 is on " ));
  }
  else
  {	light2_label->setPaletteForegroundColor(Qt::red) ;//--------Qcolor
	light2_label->setText(QString( "Light1 is off " ));
  }
  
  if(fan1_status != 0)
  {	fan1_label->setPaletteForegroundColor(Qt::green) ;//---Qcolor
	fan1_label->setText(QString( "Fan 1 is on " ));
  }
  else
  {	fan1_label->setPaletteForegroundColor(Qt::red) ;//-------Qcolor
	fan1_label->setText(QString( "Fan 1 is off " ));
  } 
 
  if(heat1_status != 0)
  {	heat1_label->setPaletteForegroundColor(Qt::green) ;//--Qcolor
	heat1_label->setText(QString( "Heat 1 is on " ));
  }
  else
  {	heat1_label->setPaletteForegroundColor(Qt::red) ;//------Qcolor
	heat1_label->setText(QString( "Heat 1 is off " ));
  } 
  
  if(fan2_status != 0)
  {	fan2_label->setPaletteForegroundColor(Qt::green) ;//---Qcolor
	fan2_label->setText(QString( "Fan 2 is on " ));
  }
  else
  {	fan2_label->setPaletteForegroundColor(Qt::red) ;//------Qcolor
	fan2_label->setText(QString( "Fan 2 is off " ));
  }
  
  if(heat2_status != 0)
  {	heat2_label->setPaletteForegroundColor(Qt::green) ;//--Qcolor
	heat2_label->setText(QString( "Heat 3 is on " ));
  }
  else
  {	heat2_label->setPaletteForegroundColor(Qt::red) ;//----Qcolor
	heat2_label->setText(QString( "Heat 3 is off " ));
  } 
  
    if(fan3_status != 0)
  {	fan3_label->setPaletteForegroundColor(Qt::green) ;//--Qcolor
	fan3_label->setText(QString( "Fan 3 is on " ));
  }
  else
  {	fan3_label->setPaletteForegroundColor(Qt::red) ;//-----Qcolor
	fan3_label->setText(QString( "Fan 3 is off " ));
  }
  
  if(heat3_status != 0)
  {	heat3_label->setPaletteForegroundColor(Qt::green) ;//-Qcolor
	heat3_label->setText(QString( "Heat 3 is on " ));
  }
  else
  {	heat3_label->setPaletteForegroundColor(Qt::red) ;//----Qcolor
	heat3_label->setText(QString( "Heat 3 is off " ));
  } 
}

//============================================================
// Timer and scheduling functions  
//============================================================

//----------------- handle_timer_event() --------------------------------
//
//PURPOSE - This slot gets called whenever the my_timer clicks over.
//            Increment the LCD display for each timer click.

void Form3::handle_timer_event()
{
  run_ADC();
  check_hw();
  get_current_time();
}

//----------------- check hw() --------------------------------
//
//PURPOSE - to check the status of the hardware every second.
//            	the h/w can only be in three states: normal, not powered and not connected.

void Form3::check_hw()
{
  //-----------check h/w connected status----------------------------------------------------------------
  if(DOUT_results[1] == 0 && DOUT_results[2] == 0 && DOUT_results[3] == 0 ||
	 DOUT_results[1] == 4095 && DOUT_results[2] == 4095 && DOUT_results[3] == 4095)
  {
	if(DOUT_results[1] == 4095 && DOUT_results[2] == 4095 && DOUT_results[3] == 4095)
	{	
	  connected_label->show();
	  warning_label->show();
	}
  
	if(DOUT_results[1] == 0 && DOUT_results[2] == 0 && DOUT_results[3] == 0)
	{
	  on_label->show();
	  warning_label->show();
	}
  }
  else
  {
	connected_label->hide();  
	on_label->hide();
	warning_label->hide();
  }
}

//------get_current_time-----------------------------------------------------------------------------------------------
//
//PURPOSE - to read the current state of the light and thermo sensors
//			check all the schedule flag to see if any has been set. 
//			when a scheduled time equals to the current then it will toogle the 
//			corresponding h/w

void Form3::get_current_time()
{
  QTime current_time;
  current_time = QTime::currentTime();
  
  time_label->setText(QString::number(current_time.hour()) + QString(":") +
					  QString::number(current_time.minute()) + QString(":") +
					  QString::number(current_time.second()));
  
  //---check light1----------------
  if(schedule_flag[0] == 1 && ((atoi(light_hour->text())) == current_time.hour()) &&
	(atoi(light_min->text())) == current_time.minute() && 
	(atoi(light_sec->text())) == current_time.second())
      {	toogle_light1();
		set_states();
		schedule_light1_but->setText("Schedule one light toogle"); 	
		light_schedule_label->setText(QString("Schedule has expired"));		
       }
  
//----check light 2------------------
  if(schedule_flag[0] == 2 && ((atoi(light_hour->text())) == current_time.hour()) &&
	(atoi(light_min->text())) == current_time.minute() && 
	(atoi(light_sec->text())) == current_time.second())
      {	toogle_light1();
		toogle_light2();
		set_states();
		schedule_light2_but->setText("Schedule both lights toogle"); 	
		light_schedule_label->setText(QString("Schedule has expired"));
       }

  //----check fan 1-----------------
  if(schedule_flag[1] == 1 && ((atoi(set1_hour->text())) == current_time.hour()) &&
	(atoi(set1_min->text())) == current_time.minute() && 
	(atoi(set1_sec->text())) == current_time.second())
      {	toogle_fan1();
		set_states();
		schedule_fan1_but->setText("Schedule Fan 1 toogle"); 
		set1_schedule_label->setPaletteForegroundColor(Qt::black) ;
		set1_schedule_label->setText(QString("Schedule has expired"));
       }
    //----check heat 1-----------------  
  if(schedule_flag[1] == 2 && ((atoi(set1_hour->text())) == current_time.hour()) &&
	(atoi(set1_min->text())) == current_time.minute() && 
	(atoi(set1_sec->text())) == current_time.second())
      {	toogle_heat1();
		set_states();
		schedule_heat1_but->setText("Schedule Heat 1 toogle"); 	
		set1_schedule_label->setPaletteForegroundColor(Qt::black) ;
		set1_schedule_label->setText(QString("Schedule has expired"));
       }

    //----check fan 2-----------------  
  if(schedule_flag[2] == 1 && ((atoi(set2_hour->text())) == current_time.hour()) &&
	(atoi(set2_min->text())) == current_time.minute() && 
	(atoi(set2_sec->text())) == current_time.second())
      {	toogle_fan2();
		set_states();
		schedule_fan2_but->setText("Schedule Fan 2 toogle"); 
		set2_schedule_label->setPaletteForegroundColor(Qt::black) ;
		set2_schedule_label->setText(QString("Schedule has expired"));
       }
    //----check heat 2---------------  
  if(schedule_flag[2] == 2 && ((atoi(set2_hour->text())) == current_time.hour()) &&
	(atoi(set2_min->text())) == current_time.minute() && 
	(atoi(set2_sec->text())) == current_time.second())
      {	toogle_heat2();
		set_states();
		schedule_heat2_but->setText("Schedule Heat 2 toogle"); 	
		set2_schedule_label->setPaletteForegroundColor(Qt::black) ;
		set2_schedule_label->setText(QString("Schedule has expired"));
       }
  
   //----check fan 3-----------------  
  if(schedule_flag[3] == 1 && ((atoi(set3_hour->text())) == current_time.hour()) &&
	(atoi(set3_min->text())) == current_time.minute() && 
	(atoi(set3_sec->text())) == current_time.second())
      {	toogle_fan3();
		set_states();
		schedule_fan3_but->setText("Schedule Fan 3 toogle"); 	
		set3_schedule_label->setPaletteForegroundColor(Qt::black) ;
		set3_schedule_label->setText(QString("Schedule has expired"));
       }
  //----check heat 3----------------  
  if(schedule_flag[3] == 2 && ((atoi(set3_hour->text())) == current_time.hour()) &&
	(atoi(set3_min->text())) == current_time.minute() && 
	(atoi(set3_sec->text())) == current_time.second())
      {	toogle_heat3();
		set_states();
		schedule_heat3_but->setText("Schedule Heat 3 toogle"); 	
		set3_schedule_label->setPaletteForegroundColor(Qt::black) ;
		set3_schedule_label->setText(QString("Schedule has expired"));
       }
}

//----------------- schedule_light1_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag to 1 so that light 1 will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_light1_toogle()
{ if(schedule_flag[0] == 1)
  {	schedule_flag[0] = 0;
	light_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_light1_but->setText("Schedule one light"); 
  }
  else
  {	schedule_flag[0] = 1;
	schedule_light1_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(light_hour->text())), (atoi(light_min->text())), 
	(atoi(light_sec->text()))) == 1)
	{
	light_schedule_label->setText(QString("Light 1 is scheduled for ") +
								  QString(light_hour->text()) + QString(":") +
								  QString(light_min->text()) + QString(":") +
								  QString(light_sec->text())); 	 
       }
	else
	{ light_schedule_label->setText(QString("Invalid time"));	
       }
  }
}

//----------------- schedule_light2_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag to 1 so that both lights will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_light2_toogle()
{ if(schedule_flag[0] == 2)
  {	schedule_flag[0] = 0;
	light_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_light2_but->setText("Schedule both lights"); 
  }
  else
  {	schedule_flag[0] = 2;
	schedule_light2_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(light_hour->text())), (atoi(light_min->text())), 
	(atoi(light_sec->text()))) == 1)
	{
	  light_schedule_label->setText(QString("Light 2 is scheduled for ") +
								  QString(light_hour->text()) + QString(":") +
								  QString(light_min->text()) + QString(":") +
								  QString(light_sec->text())); 	 
	}
	else
	{ light_schedule_label->setText(QString("Invalid time"));
	}
  }
}
 
//----------------- schedule_fan1_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag for fan1 to 1 so that fan1 status will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_fan1_toogle()
{ if(schedule_flag[1] == 1)	//----if schedule flag is equal to 1 it is refering to fan 1-----
  {	schedule_flag[1] = 0;
	set1_schedule_label->setPaletteForegroundColor(Qt::black) ;
	set1_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_fan1_but->setText("Schedule Fan 1 toogle"); 
  }
  else
  {	schedule_flag[1] = 1;
	schedule_fan1_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(set1_hour->text())), (atoi(set1_min->text())), 
	(atoi(set1_sec->text()))) == 1)
	{
	  set1_schedule_label->setPaletteForegroundColor(Qt::red) ;
	  set1_schedule_label->setText(QString("Fan 1 is scheduled for ") +
								  QString(set1_hour->text()) + QString(":") +
								  QString(set1_min->text()) + QString(":") +
								  QString(set1_sec->text())); 	 
       }
	else
	{ set1_schedule_label->setPaletteForegroundColor(Qt::red) ;
	  set1_schedule_label->setText(QString("Invalid time"));	
       }	
  }
}

//----------------- schedule_heat1_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag for fan1 to 1 so that fan1 status will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_heat1_toogle()
{ if(schedule_flag[1] == 2)	//------if schedule flag is equal to 2 it is refering to heat 1---
  {	schedule_flag[1] = 0;
	set1_schedule_label->setPaletteForegroundColor(Qt::black) ;
	set1_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_heat1_but->setText("Schedule Heat 1 toogle"); 
  }
  else
  {	schedule_flag[1] = 2;
	schedule_heat1_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(set1_hour->text())), (atoi(set1_min->text())), 
	(atoi(set1_sec->text()))) == 1)
	{
	set1_schedule_label->setPaletteForegroundColor(Qt::red) ;
	set1_schedule_label->setText(QString("Heat 1 is scheduled for ") +
								  QString(set1_hour->text()) + QString(":") +
								  QString(set1_min->text()) + QString(":") +
								  QString(set1_sec->text())); 	 
       }
	else
	{ set1_schedule_label->setPaletteForegroundColor(Qt::red) ;
	  set1_schedule_label->setText(QString("Invalid time"));	
       }
  }
}

//----------------- schedule_fan2_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag for fan1 to 1 so that fan1 status will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_fan2_toogle()
{ if(schedule_flag[2] == 1)	//if schedule flag is equal to 1 it is refering to fan 1
  {	schedule_flag[2] = 0;
	set2_schedule_label->setPaletteForegroundColor(Qt::black) ;
	set2_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_fan2_but->setText("Schedule Fan 2 toogle"); 
  }
  else
  {	schedule_flag[2] = 1;
	schedule_fan2_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(set2_hour->text())), (atoi(set2_min->text())), 
	(atoi(set2_sec->text()))) == 1)
	{
	  set2_schedule_label->setPaletteForegroundColor(Qt::blue) ;
	  set2_schedule_label->setText(QString("Fan 2 is scheduled for ") +
								  QString(set2_hour->text()) + QString(":") +
								  QString(set2_min->text()) + QString(":") +
								  QString(set2_sec->text())); 	 
	}
	else
	{ set2_schedule_label->setPaletteForegroundColor(Qt::blue) ;
	  set2_schedule_label->setText(QString("Invalid time"));	  
	}
  }
}

//----------------- schedule_heat2_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag for heat2 to 1 so that heat2 status will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_heat2_toogle()
{ if(schedule_flag[2] == 2)	//------if schedule flag is equal to 2 it is refering to heat 1----
  {	schedule_flag[2] = 0;
	set2_schedule_label->setPaletteForegroundColor(Qt::black) ;
	set2_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_heat2_but->setText("Schedule Heat 2 toogle"); 
  }
  else
  {	schedule_flag[2] = 2;
	schedule_heat2_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(set2_hour->text())), (atoi(set2_min->text())), 
	(atoi(set2_sec->text()))) == 1)
	{
	  set2_schedule_label->setPaletteForegroundColor(Qt::blue) ;
	  set2_schedule_label->setText(QString("Heat 2 is scheduled for ") +
								  QString(set2_hour->text()) + QString(":") +
								  QString(set2_min->text()) + QString(":") +
								  QString(set2_sec->text())); 	 
	}
	else
	{ set2_schedule_label->setPaletteForegroundColor(Qt::blue) ;
	  set2_schedule_label->setText(QString("Invalid time"));
	}
  }
}

//-------------------- schedule_fan3_toogle --------------------------------
//
//PURPOSE - will switch the schedule flag for fan3 to 1 so that fan3 status will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_fan3_toogle()
{ if(schedule_flag[3] == 1)	//------if schedule flag is equal to 1 it is refering to fan 1-----
  {	schedule_flag[3] = 0;
	set3_schedule_label->setPaletteForegroundColor(Qt::black) ;
	set3_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_fan3_but->setText("Schedule Fan 3 toogle"); 
  }
  else
  {	schedule_flag[3] = 1;
	schedule_fan3_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(set3_hour->text())), (atoi(set3_min->text())), 
	(atoi(set3_sec->text()))) == 1)
	{
	  set3_schedule_label->setPaletteForegroundColor(Qt::green) ;
	  set3_schedule_label->setText(QString("Fan 3 is scheduled for ") +
								  QString(set3_hour->text()) + QString(":") +
								  QString(set3_min->text()) + QString(":") +
								  QString(set3_sec->text())); 	 
	}
	else
	{ set3_schedule_label->setPaletteForegroundColor(Qt::green) ;
	  set3_schedule_label->setText(QString("Invalid time"));	  
	}
  }
}

//------------------- schedule_heat3_toogle -------------------------------------
//
//PURPOSE - will switch the schedule flag for fan3 to 1 so that fan3 status will toogle
//            	when the current time is equal to scheduled time

void Form3::schedule_heat3_toogle()
{ if(schedule_flag[3] == 2)	//------if schedule flag is equal to 2 it is refering to heat 1----
  {	schedule_flag[3] = 0;
	set3_schedule_label->setPaletteForegroundColor(Qt::black) ;
	set3_schedule_label->setText(QString("Nothing is scheluded"));
	schedule_heat3_but->setText("Schedule Heat 3 toogle"); 
  }
  else
  {	schedule_flag[3] = 2;
	schedule_heat3_but->setText("Unschedule Toogle");
	if(check_time_input((atoi(set3_hour->text())), (atoi(set3_min->text())), (atoi(set3_sec->text()))) == 1)
	{
	  set3_schedule_label->setPaletteForegroundColor(Qt::green) ;
	  set3_schedule_label->setText(QString("Heat 3 is scheduled for ") +
								  QString(set3_hour->text()) + QString(":") +
								  QString(set3_min->text()) + QString(":") +
								  QString(set3_sec->text())); 	 
       } 
	else
	{ set3_schedule_label->setPaletteForegroundColor(Qt::green) ;
	  set3_schedule_label->setText(QString("Invalid time"));
       }
  }
}

int Form3::check_time_input(int hour, int minute, int second)
{
  if(hour<25 && hour>0 && minute<60 && minute>0 && second<60 && second>0)
	return 1;
  else
	return 0;
  
}

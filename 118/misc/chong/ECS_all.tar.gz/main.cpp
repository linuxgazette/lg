#include <qapplication.h>
#include "menu.h"
#include "auto.h"
#include "manual.h"
#include "stats.h"
#include "about.h"
#include <qthread.h>

Form1* pF1 ;
Form2* pF2 ;
Form3* pF3 ;
Form4* pF4 ;
About* pB;

int main( int argc, char ** argv )
{
    QApplication a( argc, argv );
    Form1 w;
    pF1 = &w ;
    Form2 F2 ;
    pF2 = &F2 ;    
    Form3 F3 ;
    pF3 = &F3 ;
    Form4 F4 ;  
    pF4 = &F4 ;
    About B;
    pB = &B;
    
    //myThread threadA;
    
    w.show();
    a.connect( &a, SIGNAL( lastWindowClosed() ), &a, SLOT( quit() ) );
    return a.exec();
}

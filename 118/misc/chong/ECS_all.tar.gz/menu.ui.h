/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/
//--- allows class body to access Form2.

#include "auto.h"
extern Form1* pF2 ; 
#include "manual.h"
extern Form1* pF3 ; 
#include "stats.h"
extern Form1* pF4 ; 

#include "about.h"
extern About* pB ; 

#include <time.h>;
#include <sys/time.h>;

//============== constructor and destructor ====================================

void Form1::init()
{//--- code to execute just before visual components are displayed.
}

void Form1::destroy()
{//--- code to execute when form closed but before visual components are destroyed.
    
}

//============================================================
// Open Forms
//============================================================

//------exit_state()-----------------------------------------------------------------------------------------------
//
//PURPOSE - exits the form
void Form1::exit_state()
{
    outb(0x0, lp_base_addr);
}

//------start_auto_form()-----------------------------------------------------------------------------------------------
//
//PURPOSE - opens the Automatic Form
void Form1::start_auto_form()
{
      pF2->show() ;  
}

//------start_manual_form()-----------------------------------------------------------------------------------------------
//
//PURPOSE - opens the Manual Form
void Form1::start_manual_form()
{
      pF3->show() ;  
}

//------start_stats_form()-----------------------------------------------------------------------------------------------
//
//PURPOSE - opens the statistics Form
void Form1::start_stats_form()
{
      pF4->show() ;   
}

//------start_about_form()-----------------------------------------------------------------------------------------------
//
//PURPOSE - opens the About Form
void Form1::start_about_form()
{
      pB->show() ;   
}

